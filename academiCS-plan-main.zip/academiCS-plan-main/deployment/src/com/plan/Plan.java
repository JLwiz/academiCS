package com.plan;

import com.plan.gui.components.MainController;

import javax.swing.*;

/**
 * Main class for AcademiCS Plan.
 *
 * @author Ernest Tussey
 * @version 1.0
 */
public class Plan
{

  /**
   * {@code main} method. {@code SwingUtilities} invokes the
   * MainController to load the UI.
   *
   * @param args arguments not used
   */
  public static void main(final String[] args)
  {
    MainController controller = new MainController();
    SwingUtilities.invokeLater(controller::load);
  }

}
