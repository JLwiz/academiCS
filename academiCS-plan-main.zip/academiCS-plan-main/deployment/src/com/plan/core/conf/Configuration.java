package com.plan.core.conf;

import java.io.File;

public class Configuration
{
  private static final Configuration INSTANCE = new Configuration();

  private static final String CONFIG_FILE = "plan.cfg";

  private Configuration()
  {

  }

  public static Configuration getInstance()
  {
    return INSTANCE;
  }

  public File getCurrentDirectory()
  {
    return null;
  }

  private void setUpConfiguration()
  {

  }

}
