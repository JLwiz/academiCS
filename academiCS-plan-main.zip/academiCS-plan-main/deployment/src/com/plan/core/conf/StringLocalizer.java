package com.plan.core.conf;

import com.plan.core.io.PlanLogger;

import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.logging.Level;

public class StringLocalizer
{
  private static final StringLocalizer INSTANCE = new StringLocalizer();

  private final ResourceBundle strings;

  public StringLocalizer()
  {
    this.strings = ResourceBundle
        .getBundle("Strings", Locale.getDefault(), StringLocalizer.class.getClassLoader());
  }

  public static StringLocalizer getInstance()
  {
    return INSTANCE;
  }

  public String getString(final String str)
  {
    try
    {
      return this.strings.getString(str);
    }
    catch (MissingResourceException e)
    {
      PlanLogger.getInstance().log(Level.WARNING, "Missing resource for key " + str);
    }
    return str;
  }
}
