package com.plan.core.io;

import javax.swing.filechooser.FileFilter;
import java.io.File;

/**
 * {@code FileTypeFilter} is an instance of {@code FileFilter} to be
 * used by a {@code JFileChooser}.
 *
 * @author Ernest Tussey
 * @version 1.0
 */
public class FileTypeFilter extends FileFilter
{

  public static final String SERIALIZED_DATA = ".ser";
  public static final String PLAN_DATA = ".plan";
  public static final String JSON_DATA = ".json";
  public static final String XML_DATA = ".xml";

  private final String extension;
  private final String description;

  /**
   * d.
   *
   * @param extension   d
   * @param description d
   */
  public FileTypeFilter(final String extension, final String description)
  {
    this.extension = extension;
    this.description = description;
  }

  @Override public boolean accept(final File file)
  {
    if (file.isDirectory())
    {
      return true;
    }
    return file.getName().endsWith(extension);
  }

  @Override public String getDescription()
  {
    return description + String.format(" (*%s)", extension);
  }
}
