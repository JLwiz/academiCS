package com.plan.core.io;

import com.plan.core.models.Course;
import com.plan.core.services.StudentPlanService;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * {@code JSONFileSaver} handles all reading writing of files to JSON.
 *
 * @author Jacob Lewis
 * @version 1.0
 */
public class JSONFileUtility
{

  /**
   * Writes JSON data to a file.
   *
   * @param filePath the file to write data to
   * @param sps      student plan service
   */
  public static void exportJSONData(final String filePath, final StudentPlanService sps)
  {
    String tempFilePath = filePath;
    if (!tempFilePath.endsWith(FileTypeFilter.JSON_DATA))
    {
      tempFilePath += FileTypeFilter.JSON_DATA;
    }
    List<Course> taken = new ArrayList<>();
    List<Course> current = new ArrayList<>();
    List<Course> planned = new ArrayList<>();
    long currentTime = System.currentTimeMillis();
    sps.getPlan().getCourseMap().forEach((t, c) -> {
      if (t.getEndDate() < currentTime)
      {
        taken.addAll(c);
      }
      else if (t.getStartDate() < currentTime && t.getEndDate() > currentTime)
      {
        current.addAll(c);
      }
      else
      {
        planned.addAll(c);
      }
    });

    StringBuilder builder = new StringBuilder();
    builder.append("{\n");
    builder.append(getCourseList("taken", taken, false));
    builder.append(getCourseList("current", current, false));
    builder.append(getCourseList("planned", planned, true));
    builder.append("}\n");

    try
    {
      BufferedWriter writer = new BufferedWriter(new FileWriter(tempFilePath));
      writer.write(builder.toString());
      writer.close();
    }
    catch (IOException e)
    {
      PlanLogger.getInstance().error("Failed to export to Track", e);
    }
  }

  private static String getCourseList(final String title, final List<Course> courses,
      final boolean isLast)
  {
    StringBuilder builder = new StringBuilder();
    builder.append("\t\"");
    builder.append(title).append("\": [\n");
    for (int i = 0; i < courses.size(); i++)
    {
      builder.append(getCourseJSON(courses.get(i), (i + 1) == courses.size()));
      builder.append("\n");
    }
    builder.append("\t]");
    if (isLast)
      builder.append("\n");
    else
      builder.append(",\n");
    return builder.toString();
  }

  private static String getCourseJSON(final Course c, final boolean isLast)
  {
    if (c == null)
      return "";
    return "\t\t{\n\t\t\t" + "  \"courseName\": \"" + c.getTitle() + "\", \n\t\t\t"
        + "  \"courseAbbrievatedName\": \"" + c.getAbbreviatedTitle() + "\",\n\t\t\t"
        + "  \"units\": " + c.getUnits() + ",\n\t\t\t" + "  \"courseType\": " + c.getCourseType()
        .ordinal() + "\n\t\t" + "}" + (isLast ? "" : ",");
  }
}
