package com.plan.core.io;

import com.plan.core.models.*;
import com.plan.core.services.*;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * {@code ModelSerializer} handles all reading writing of serialized model classes.
 *
 * @author Ernest Tussey, Nick Buchan
 * @version 1.1
 */
public class ModelSerializer
{

  private static final String DATA_EXT = ".ser";
  private static final String PLAN_EXT = ".plan";

  /**
   * Imports all data from a file and puts into the correct service.
   * <p>
   * The following indexes are where the data is stored
   * <p> 0 - courses
   * <p> 1 - academic terms
   * <p> 2 - course groups
   * <p> 3 - fields of study
   *
   * @param filePath the file path of the serialized data file
   * @param cs       the course service
   * @param ts       the term service
   * @param cgs      the course group service
   * @param fos      the field of study service
   * @throws IOException            thrown if the reading has an error
   * @throws ClassNotFoundException if the class os not found
   */
  @SuppressWarnings("unchecked") public static void importData(final String filePath,
      final CourseService cs, final TermService ts, final CourseGroupService cgs,
      final FieldOfStudyService fos) throws IOException, ClassNotFoundException
  {
    FileInputStream fileInputStream;
    ObjectInputStream objectInputStream;

    fileInputStream = new FileInputStream(filePath);
    objectInputStream = new ObjectInputStream(fileInputStream);
    List<List<?>> c = (List<List<?>>) objectInputStream.readObject();
    fileInputStream.close();
    objectInputStream.close();

    ((List<Course>) c.get(0)).forEach(cs::create);
    ((List<AcademicTerm>) c.get(1)).forEach(ts::create);
    ((List<CourseGroup>) c.get(2)).forEach(cgs::create);
    ((List<FieldOfStudy>) c.get(3)).forEach(fos::create);
  }

  /**
   * Writes serialized data to a file.
   * <p>
   * The following indexes are where the data is stored
   * <p> 0 - courses
   * <p> 1 - academic terms
   * <p> 2 - course groups
   * <p> 3 - fields of study
   *
   * @param filePath the file to write data to
   * @param cs       the course service
   * @param ts       the term service
   * @param cgs      the course group service
   * @param fos      the field of study service
   */
  public static void exportData(final String filePath, final CourseService cs, final TermService ts,
      final CourseGroupService cgs, final FieldOfStudyService fos)
  {

    var tempFilePath = filePath;
    if (!tempFilePath.endsWith(DATA_EXT))
      tempFilePath += DATA_EXT;
    FileOutputStream fileOutputStream;
    ObjectOutputStream objectOutputStream;
    try
    {
      fileOutputStream = new FileOutputStream(tempFilePath);
      objectOutputStream = new ObjectOutputStream(fileOutputStream);
      List<List<?>> data = new ArrayList<>();
      data.add(new ArrayList<>(cs.getAll()));
      data.add(new ArrayList<>(ts.getAll()));
      data.add(new ArrayList<>(cgs.getAll()));
      data.add(new ArrayList<>(fos.getAll()));

      objectOutputStream.writeObject(data);
      fileOutputStream.close();
      objectOutputStream.close();
    }
    catch (IOException e)
    {
      e.printStackTrace();
      PlanLogger.getInstance().error("Failed to export Plan data", e);
    }
  }

  /**
   * Writes a student plan to a specified path.
   *
   * @param filePath the file path
   * @param service  the student plan service
   */
  public static void saveStudentPlan(final String filePath, final StudentPlanService service)
  {
    var tempFilePath = filePath;
    if (!tempFilePath.endsWith(PLAN_EXT))
      tempFilePath += PLAN_EXT;
    FileOutputStream fileOutputStream;
    ObjectOutputStream objectOutputStream;
    try
    {
      fileOutputStream = new FileOutputStream(tempFilePath);
      objectOutputStream = new ObjectOutputStream(fileOutputStream);
      objectOutputStream.writeObject(service.getPlan());
      fileOutputStream.close();
      objectOutputStream.close();
    }
    catch (IOException e)
    {
      PlanLogger.getInstance().error("Failed to save Student Plan", e);
      e.printStackTrace();
    }
  }

  /**
   * Reads a student plan from the file path.
   *
   * @param filePath the file path to read
   * @return a student plan
   * @throws IOException            thrown if the reading has an error
   * @throws ClassNotFoundException if the class os not found
   */
  public static StudentPlan openStudentPlan(final String filePath)
      throws IOException, ClassNotFoundException
  {
    FileInputStream fileInputStream;
    ObjectInputStream objectInputStream;

    fileInputStream = new FileInputStream(filePath);
    objectInputStream = new ObjectInputStream(fileInputStream);
    return (StudentPlan) objectInputStream.readObject();
  }

}
