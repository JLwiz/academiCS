package com.plan.core.io;

import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class PlanLogger
{
  private static final PlanLogger INSTANCE = new PlanLogger();

  private final Logger logger;
  private String logName;

  private PlanLogger()
  {
    this.logger = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
    this.logger.addHandler(getFileHandler());
  }

  public static PlanLogger getInstance()
  {
    return INSTANCE;
  }

  public void error(final String msg, final Exception exception)
  {
    this.logger.log(Level.SEVERE, msg, exception.getStackTrace());
  }

  public String getLogName()
  {
    return this.logName;
  }

  public void log(final Level level, final String msg)
  {
    this.logger.log(level, msg);
  }

  private FileHandler getFileHandler()
  {
    String name = "plan_log_" + System.currentTimeMillis() + ".txt";
    this.logName = name;
    FileHandler handler = null;
    try
    {
      handler = new FileHandler(name);
      handler.setFormatter(new SimpleFormatter());
    }
    catch (IOException e)
    {
      e.printStackTrace();
    }
    return handler;
  }
}
