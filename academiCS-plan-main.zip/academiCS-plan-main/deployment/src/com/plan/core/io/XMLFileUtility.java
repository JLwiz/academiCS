package com.plan.core.io;

import com.plan.core.conf.StringLocalizer;
import com.plan.core.models.Course;
import com.plan.core.models.CourseType;
import com.plan.core.services.CourseService;
import com.plan.gui.components.reusuable.CourseSelectionList;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.swing.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Vector;

public class XMLFileUtility
{

  /**
   * Handels the import action for the schedule xml.
   *
   * @param filePath
   * @param cs
   * @param fromValues
   * @param csl
   * @throws ParserConfigurationException
   * @throws SAXException
   * @throws IOException
   */
  private static void importXMLData(final String filePath, final CourseService cs,
      final Vector<String> fromValues, CourseSelectionList csl)
      throws ParserConfigurationException, SAXException, IOException
  {
    File file = new File(filePath);
    if (file == null)
      return;

    DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
    DocumentBuilder db = dbf.newDocumentBuilder();
    Document doc = db.parse(file);
    doc.getDocumentElement().normalize();

    NodeList nodeList = doc.getElementsByTagName("Course");
    Collection<Course> coll = cs.getAll();
    List<String> abrvList = new ArrayList<String>();
    List<String> rejected = new ArrayList<String>();
    for (Course course : coll)
    {
      abrvList.add(course.getAbbreviatedTitle());
    }

    List<Course> selectedCourses = new ArrayList<Course>();
    for (int i = 0; i < nodeList.getLength(); i++)
    {
      Node node = nodeList.item(i);
      if (node.getNodeType() == Node.ELEMENT_NODE)
      {
        Element element = (Element) node;
        String courseName = element.getAttribute("name");
        if (coll.size() == 0)
          rejected.add(courseName);
        for (Course course : coll)
        {
          String abbreviatedTitle = course.getAbbreviatedTitle();
          if (abbreviatedTitle.equals(courseName))
          {
            selectedCourses.add(course);
          }
          else
          {
            if (!rejected.contains(courseName) && !abrvList.contains(courseName))
              rejected.add(courseName);
          }
        }

      }
    }
    csl.setSelectedCourses(selectedCourses);
    int opt = 0;
    if (rejected.size() != 0)
      opt = presentDialog(rejected);

    switch (opt)
    {
      case 1:
        List<Course> temp = new ArrayList<Course>();
        int nextId = coll.size();
        for (String str : rejected)
        {
          while (cs.isIDTaken("" + nextId))
            nextId++;
          Course course = new Course("" + nextId, System.currentTimeMillis());
          course.setTitle("Title for " + str);
          course.setAbbreviatedTitle(str);
          course.setDescription("Description for " + str);
          course.setCourseType(CourseType.ELECTIVE);
          cs.create(course);
          temp.add(course);
        }
        csl.setUnselectedCourses(temp);
        csl.setSelectedCourses(temp);
        break;
    }
  }

  /**
   * Presents the dialog frame options for importing schedule.
   *
   * @param rejected
   * @return
   */
  private static int presentDialog(List<String> rejected)
  {
    String str = "Course Records Do Not Exist For:\n";
    for (String temp : rejected)
    {
      String toAdd = String.format("\t\t%s\n", temp);
      str += toAdd;
    }
    String[] options = {"OK", "Autofill and Import"};
    int opt = JOptionPane
        .showOptionDialog(null, str, StringLocalizer.getInstance().getString("Import_Error"),
            JOptionPane.YES_NO_OPTION, JOptionPane.ERROR_MESSAGE, null, options, null);
    return opt;
  }

  /**
   * Should be called by a button to start the import process
   * from the schedule application.
   *
   * @param csl        CourseSelectionList
   * @param service    CourseService
   * @param fromValues Values to be added to a term
   */
  public static void importScheduleXML(final CourseSelectionList csl, CourseService service,
      Vector<String> fromValues)
  {
    if (csl == null)
      return;
    JFileChooser fileChooser = new JFileChooser();
    fileChooser.setDialogTitle(StringLocalizer.getInstance().getString("Import_Schedule"));
    fileChooser.setAcceptAllFileFilterUsed(false);
    fileChooser.setFileFilter(new FileTypeFilter(FileTypeFilter.XML_DATA,
        StringLocalizer.getInstance().getString("XML_Data")));
    if (fileChooser.showOpenDialog(csl.getParent()) == JFileChooser.APPROVE_OPTION)
      ;
    {
      // if (hasDataBeenImported)
      // {
      int opt = JOptionPane.showOptionDialog(csl.getParent(),
          StringLocalizer.getInstance().getString("Data_Override_Dialog"),
          StringLocalizer.getInstance().getString("Data_Conflict"), JOptionPane.YES_NO_OPTION,
          JOptionPane.WARNING_MESSAGE, null, null, null);

      if (opt == JOptionPane.NO_OPTION)
        return;
      // }

      try
      {
        XMLFileUtility
            .importXMLData(fileChooser.getSelectedFile().getPath(), service, fromValues, csl);
        //csl.reloadLists();
      }
      catch (ParserConfigurationException | SAXException | IOException e)
      {
        JOptionPane.showMessageDialog(csl.getParent(),
            StringLocalizer.getInstance().getString("Corrupt_Data_Dialog"),
            StringLocalizer.getInstance().getString("Import_Error"), JOptionPane.ERROR_MESSAGE);
        return;
      }
    }
    //   hasDataBeenImported = true;
  }
}

