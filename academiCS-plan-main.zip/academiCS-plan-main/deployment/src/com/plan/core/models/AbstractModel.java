package com.plan.core.models;

import java.io.Serializable;
import java.util.Objects;

/**
 * {@code AbstractModel} is an abstract class that represents a {@code Serializable}
 * object.
 *
 * @author Ernest Tussey
 * @version 1.0
 */
public abstract class AbstractModel implements Serializable
{

  private final String id;
  private final long createdDate;

  /**
   * Constructs an instance of {@code AbstractModel} provided an
   * id and a timestamp when the user created this model.
   *
   * @param id          the unique identifier
   * @param createdDate the timestamp when the model was created
   *                    in milliseconds
   */
  public AbstractModel(final String id, final long createdDate)
  {
    this.id = id;
    this.createdDate = createdDate;
  }

  /**
   * Overridden {@code equals()} to provide equality
   * evaluation for IDs.
   *
   * @param o the object to compare
   * @return if the objects are equivalent
   */
  @Override public boolean equals(final Object o)
  {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    AbstractModel that = (AbstractModel) o;
    return createdDate == that.createdDate && Objects.equals(id, that.id);
  }

  /**
   * Returns the created at timestamp in milliseconds.
   *
   * @return created at timestamp
   */
  public long getCreatedDate()
  {
    return createdDate;
  }

  /**
   * Returns the models id.
   *
   * @return id as a {@code String}
   */
  public String getId()
  {
    return id;
  }

  @Override public int hashCode()
  {
    return Objects.hash(id, createdDate);
  }
}
