package com.plan.core.models;

import java.util.List;

/**
 * {@code AcademicTerm} represents an term at school.
 *
 * @author Ernest Tussey
 * @version 1.0
 */
public class AcademicTerm extends AbstractModel
{

  private String title;
  private long startDate;
  private long endDate;
  private TermType termType;

  private List<Course> actualCourses;
  private List<Course> intendedCourses;

  /**
   * Constructs an instance of AcademicTerm provided an ID, and created date.
   *
   * @param id          the unique id
   * @param createdDate the createdDate
   */
  public AcademicTerm(final String id, final long createdDate)
  {
    super(id, createdDate);
  }

  /**
   * Returns the actual courses that were offered in a term.
   *
   * @return actual course list
   */
  public List<Course> getActualCourses()
  {
    return actualCourses;
  }

  /**
   * Set the actual courses for this term.
   *
   * @param actualCourses the new list of actual courses
   */
  public void setActualCourses(final List<Course> actualCourses)
  {
    this.actualCourses = actualCourses;
  }

  /**
   * Returns the terms end data in milliseconds.
   *
   * @return term end data in milliseconds
   */
  public long getEndDate()
  {
    return endDate;
  }

  /**
   * Sets the end date of this term.
   *
   * @param endDate the end date in milliseconds
   */
  public void setEndDate(final long endDate)
  {
    this.endDate = endDate;
  }

  /**
   * Returns the courses that are intended to be offered in this term.
   *
   * @return the intended courses for this term
   */
  public List<Course> getIntendedCourses()
  {
    return intendedCourses;
  }

  /**
   * Set the intendedCourses for a term.
   *
   * @param intendedCourses the new list of intended courses for this term
   */
  public void setIntendedCourses(final List<Course> intendedCourses)
  {
    this.intendedCourses = intendedCourses;
  }

  /**
   * Returns the terms start data in milliseconds.
   *
   * @return term start data in milliseconds
   */
  public long getStartDate()
  {
    return startDate;
  }

  /**
   * Sets the start date of this term.
   *
   * @param startDate the start date in milliseconds
   */
  public void setStartDate(final long startDate)
  {
    this.startDate = startDate;
  }

  /**
   * Returns the terms type.
   *
   * @return the term type
   */
  public TermType getTermType()
  {
    return termType;
  }

  /**
   * Sets the term's type.
   *
   * @param termType the term type
   */
  public void setTermType(final TermType termType)
  {
    this.termType = termType;
  }

  /**
   * Returns this terms title.
   *
   * @return this terms title
   */
  public String getTitle()
  {
    return title;
  }

  /**
   * Sets this terms title.
   *
   * @param title the terms title
   */
  public void setTitle(final String title)
  {
    this.title = title;
  }

  @Override public String toString()
  {
    return getTitle();
  }
}
