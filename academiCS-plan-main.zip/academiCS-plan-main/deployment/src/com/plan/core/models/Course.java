package com.plan.core.models;

import java.util.List;

/**
 * {@code Course} represents a course offered at school. It manages it
 * prerequisites and corequisites.
 *
 * @author Ernest Tussey
 * @version 1.0
 * @see CourseGroup
 * @see CourseType
 * @see FieldOfStudy
 */
public class Course extends AbstractModel
{

  private String title;
  private String abbreviatedTitle;
  private String description;

  private int units;
  private CourseType courseType;

  private List<Course> strongPrerequisites;
  private List<Course> altStrongPrerequisites;

  private List<Course> weakPrerequisites;
  private List<Course> altWeakPrerequisites;

  private List<Course> corequisites;
  private List<Course> altCorequisites;

  /**
   * Constructs a new instance of {@code Course}.
   *
   * @param courseCode  the ID of the course is its course catalog code
   * @param createdDate the time this course was created
   */
  public Course(final String courseCode, final long createdDate)
  {
    super(courseCode, createdDate);
  }

  /**
   * Returns the abbreviated title. This is a short identifiable name.
   * (i.e: CS 100).
   * <p>
   * WARNING: this may be null
   *
   * @return the courses abbreviated title.
   */
  public String getAbbreviatedTitle()
  {
    return abbreviatedTitle;
  }

  /**
   * Sets the courses abbreviated title. This is a short identifiable name.
   * (i.e: CS 100).
   *
   * @param abbreviatedTitle the courses abbreviated title
   */
  public void setAbbreviatedTitle(final String abbreviatedTitle)
  {
    this.abbreviatedTitle = abbreviatedTitle;
  }

  /**
   * Returns this course's alternate corequistes. These represent
   * valid substitutions for this course's corequisites. This may be null
   * if none exist.
   * <p>
   * WARNING: this may be null
   *
   * @return the list of alternate corequistes
   */
  public List<Course> getAltCorequisites()
  {
    return altCorequisites;
  }

  /**
   * Sets his course's alternate corequistes.
   *
   * @param altCorequisites the list of alternate corequistes
   */
  public void setAltCorequisites(final List<Course> altCorequisites)
  {
    this.altCorequisites = altCorequisites;
  }

  /**
   * Returns this course's alternate strong prerequisites. These represents
   * valid courses that must come before this course but
   * can substitute for this courses strong prerequisites.
   * This may be null if none exist.
   * <p>
   * WARNING: this may be null
   *
   * @return the list of alternate strong prerequisites
   */
  public List<Course> getAltStrongPrerequisites()
  {
    return altStrongPrerequisites;
  }

  /**
   * Sets this course's alternate strong prerequisites. These represents
   * valid courses that must come before this course but can substitute
   * for this courses strong prerequisites. This may be null if none exist.
   *
   * @param altStrongPrerequisites list of alternate strong prerequisites
   */
  public void setAltStrongPrerequisites(final List<Course> altStrongPrerequisites)
  {
    this.altStrongPrerequisites = altStrongPrerequisites;
  }

  /**
   * Returns this course's alternate weak prerequisites. These represents
   * valid courses that must come before or occur at the same time as this course but
   * can substitute for this courses weak prerequisites.
   * This may be null if none exist.
   * <p>
   * WARNING: this may be null
   *
   * @return the list of alternate weak prerequisites
   */
  public List<Course> getAltWeakPrerequisites()
  {
    return altWeakPrerequisites;
  }

  /**
   * Sets this course's alternate weak prerequisites. These represents
   * valid courses that must come before or occur at the same time as this
   * course but can substitute for this courses weak prerequisites. This
   * may be null if none exist.
   *
   * @param altWeakPrerequisites list of alternate weak prerequisites
   */
  public void setAltWeakPrerequisites(final List<Course> altWeakPrerequisites)
  {
    this.altWeakPrerequisites = altWeakPrerequisites;
  }

  /**
   * Returns this course's corequistes. These represents
   * valid courses that must occur at the same time as this. This
   * may be null if none exist.
   * <p>
   * WARNING: this may be null
   *
   * @return list of corequistes
   */
  public List<Course> getCorequisites()
  {
    return corequisites;
  }

  /**
   * Sets this course's corequistes. These represents
   * valid courses that must occur at the same time as this. This
   * may be null if none exist.
   *
   * @param corequisites list of corequistes
   */
  public void setCorequisites(final List<Course> corequisites)
  {
    this.corequisites = corequisites;
  }

  /**
   * Returns this course's type.
   * <p>
   * WARNING: this may be null
   *
   * @return {@code CourseType}
   */
  public CourseType getCourseType()
  {
    return courseType;
  }

  /**
   * Sets this course's type.
   *
   * @param courseType {@code CourseType}
   */
  public void setCourseType(final CourseType courseType)
  {
    this.courseType = courseType;
  }

  /**
   * Returns the {@code String} description of this course.
   * <p>
   * WARNING: this may be null
   *
   * @return this course's description
   */
  public String getDescription()
  {
    return description;
  }

  /**
   * Set's this courses description.
   *
   * @param description this course's description
   */
  public void setDescription(final String description)
  {
    this.description = description;
  }

  /**
   * Returns this course's strong prerequisites. These represents
   * valid courses that must come before this course. This may be null
   * if none exist.
   * <p>
   * WARNING: this may be null
   *
   * @return the list of strong prerequisites
   */
  public List<Course> getStrongPrerequisites()
  {
    return strongPrerequisites;
  }

  /**
   * Sets this course's strong prerequisites. These represents
   * valid courses that must come before this course. This may be null
   * if none exist.
   *
   * @param strongPrerequisites list of strong prerequisites
   */
  public void setStrongPrerequisites(final List<Course> strongPrerequisites)
  {
    this.strongPrerequisites = strongPrerequisites;
  }

  /**
   * Return's the full title of this course, minus the abbreviated title.
   * <p>  Example:
   * <p>
   * Abbreviated Title: CS 100
   * <p>
   * Title: Fundamentals of Computer Science
   * <p>
   * WARNING: this may be null
   *
   * @return courses actual title
   */
  public String getTitle()
  {
    return title;
  }

  /**
   * Set's this course's title. Notice this is not the abbreviated title.
   * <p>  Example:
   * <p>
   * Abbreviated Title: CS 100
   * <p>
   * Title: Fundamentals of Computer Science
   * <p>
   *
   * @param title this course's title.
   */
  public void setTitle(final String title)
  {
    this.title = title;
  }

  /**
   * Returns this course's units. This may be credits or whatever
   * unit of measurement is used by a school.
   *
   * @return the number of units this courses is worth
   */
  public int getUnits()
  {
    return units;
  }

  /**
   * Set's the units for this course.
   *
   * @param units the number of units for this course
   */
  public void setUnits(final int units)
  {
    this.units = units;
  }

  /**
   * Returns this course's weak prerequisites. These represents
   * valid courses that must come before or occur at the same time as this course.
   * This may be null if none exist.
   * <p>
   * WARNING: this may be null
   *
   * @return the list of weak prerequisites
   */
  public List<Course> getWeakPrerequisites()
  {
    return weakPrerequisites;
  }

  /**
   * Sets this course's weak prerequisites. These represents
   * valid courses that must come before or occur at the same time as this
   * course. This may be null if none exist.
   *
   * @param weakPrerequisites list of weak prerequisites
   */
  public void setWeakPrerequisites(final List<Course> weakPrerequisites)
  {
    this.weakPrerequisites = weakPrerequisites;
  }

  @Override public String toString()
  {
    return getAbbreviatedTitle();
  }
}
