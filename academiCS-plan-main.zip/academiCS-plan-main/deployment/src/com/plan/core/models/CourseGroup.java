package com.plan.core.models;

import java.util.List;

/**
 * {@code CourseGroup} groups courses of the same {@code CourseType}.
 * This provides validation for a {@code FieldOfStudy} where students may only
 * need to select a certain number of courses from one group.
 *
 * @author Ernest Tussey
 * @version 1.0
 * @see Course
 * @see CourseType
 * @see FieldOfStudy
 */
public class CourseGroup extends AbstractModel
{

  private String title;
  private List<Course> courses;
  private int requiredCourses;

  /**
   * Construct's an instance of {@code CourseGroup}.
   *
   * @param id          the {@code String} ID from this model
   * @param createdDate the time this model was created in milliseconds
   */
  public CourseGroup(final String id, final long createdDate)
  {
    super(id, createdDate);
  }

  /**
   * Returns this {@code List} of courses in this group.
   *
   * @return {@code List} of courses in this group
   */
  public List<Course> getCourses()
  {
    return courses;
  }

  /**
   * Sets the {@code List} of courses in this group.
   *
   * @param courses {@code List} of courses in this group
   */
  public void setCourses(final List<Course> courses)
  {
    this.courses = courses;
  }

  /**
   * The number of courses in this group that are required for a
   * {@code FieldOfStudy}. Where {@code requiredCourses} greater than
   * zero and less than this number of courses in this group.
   *
   * @return the number of required courses
   */
  public int getRequiredCourses()
  {
    return requiredCourses;
  }

  /**
   * Sets the number of courses in this group that are required for a
   * {@code FieldOfStudy}. Where {@code requiredCourses} greater than
   * zero and less than this number of courses in this group.
   *
   * @param requiredCourses number of required courses
   */
  public void setRequiredCourses(final int requiredCourses)
  {
    this.requiredCourses = requiredCourses;
  }

  /**
   * Returns the user identifiable title for this group.
   * <p>
   * Notice: this is not the ID (see {@code getID()} for that).
   *
   * @return {@code String} title of the group
   */
  public String getTitle()
  {
    return title;
  }

  /**
   * Sets the user identifiable title for this group.
   *
   * @param title {@code String} title of the group
   */
  public void setTitle(final String title)
  {
    this.title = title;
  }

  @Override public String toString()
  {
    return getTitle();
  }

}
