package com.plan.core.models;

/**
 * {@code CourseType} is used for the grouping of course's and provides users with
 * more information about a {@code Course}.
 *
 * @author Ernest Tussey
 * @version 1.0
 * @see Course
 * @see CourseGroup
 * @see StudyType
 * @see TermType
 */
public enum CourseType
{
  REQUIRED(0), ELECTIVE(1), GENERAL_EDUCATION(2);

  private static final String ERROR_PREFIX = "Unexpected value: ";
  private final int value;

  /**
   * Constructs an instance of {@code CourseType} provided an integer
   * value.
   *
   * @param v the integer value
   */
  CourseType(final int v)
  {
    this.value = v;
  }

  /**
   * Utility method for retrieving a course type when stored as an integer.
   *
   * @param v the integer value of the course type
   * @return returns the course type
   * @throws IllegalStateException if the value does not represent any valid course type
   */
  public static CourseType of(final int v)
  {
    switch (v)
    {
      case 0:
        return REQUIRED;
      case 1:
        return ELECTIVE;
      case 2:
        return GENERAL_EDUCATION;
      default:
        throw new IllegalStateException(ERROR_PREFIX + v);
    }
  }

  @Override public String toString()
  {
    switch (value)
    {
      case 0:
        return "Required";
      case 1:
        return "Elective";
      case 2:
        return "General Education";
      default:
        throw new IllegalStateException(ERROR_PREFIX + value);
    }
  }
}
