package com.plan.core.models;

import java.util.List;

/**
 * {@code FieldOfStudy} represents any field that can be study
 * (e.g: Major, Minor, etc).
 *
 * @author Ernest Tussey
 * @version 1.0
 */
public class FieldOfStudy extends AbstractModel
{

  private String name;
  private StudyType studyType;
  private List<CourseGroup> courseGroups;

  /**
   * Construct's an instance of {@code FieldOfStudy}.
   *
   * @param id          the {@code String} ID from this model
   * @param createdDate the time this model was created in milliseconds
   */
  public FieldOfStudy(final String id, final long createdDate)
  {
    super(id, createdDate);
  }

  /**
   * Returns the list of course groups that make up this field.
   * <p>
   * WARNING: may be null
   *
   * @return {@code List} of course groups
   */
  public List<CourseGroup> getCourseGroups()
  {
    return courseGroups;
  }

  /**
   * Sets the list of course groups.
   *
   * @param courseGroups set's the course groups that make up this field
   */
  public void setCourseGroups(final List<CourseGroup> courseGroups)
  {
    this.courseGroups = courseGroups;
  }

  /**
   * Returns the user identifiable name for this field.
   * <p>
   * Notice: this is not the ID (see {@code getID()} for that).
   *
   * @return {@code String} name of the field
   */
  public String getName()
  {
    return name;
  }

  /**
   * Sets the user identifiable name for this field.
   *
   * @param name {@code String} name of the field
   */
  public void setName(final String name)
  {
    this.name = name;
  }

  /**
   * Returns this field's study type.
   * <p>
   * WARNING: this may be null
   *
   * @return {@code StudyType}
   */
  public StudyType getStudyType()
  {
    return studyType;
  }

  /**
   * Sets this field's study type.
   *
   * @param studyType {@code StudyType}
   */
  public void setStudyType(final StudyType studyType)
  {
    this.studyType = studyType;
  }

  @Override public String toString()
  {
    return getName();
  }
}
