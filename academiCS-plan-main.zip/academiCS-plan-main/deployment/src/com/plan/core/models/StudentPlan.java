package com.plan.core.models;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * {@code StudentPlan} models a plan for a <b>single</b> {@code FieldOfStudy}.
 * This plan maps {@code Courses} to {@code AcademicTerms}.
 *
 * @author Ernest Tussey
 * @version 1.0
 */
public class StudentPlan extends AbstractModel
{

  private final Map<AcademicTerm, List<Course>> courseMap;
  private String planName;
  private FieldOfStudy fieldOfStudy;

  /**
   * Construct's an instance of {@code StudentPlan}.
   *
   * @param id          the {@code String} ID from this model
   * @param createdDate the time this model was created in milliseconds
   */
  public StudentPlan(final String id, final long createdDate)
  {
    super(id, createdDate);
    courseMap = new HashMap<>();
  }

  /**
   * Returns the {@code Map} of {@code Courses} to {@code AcademicTerms}.
   * <p>
   * WARNING: may be null
   *
   * @return {@code Map} of {@code Courses} to {@code AcademicTerms}
   */
  public Map<AcademicTerm, List<Course>> getCourseMap()
  {
    return courseMap;
  }

  /**
   * Returns the {@code FieldOfStudy} for this plan.
   *
   * @return the field of study
   */
  public FieldOfStudy getFieldOfStudy()
  {
    return fieldOfStudy;
  }

  /**
   * Sets the {@code FieldOfStudy} for this plan.
   *
   * @param fieldOfStudy field of study
   */
  public void setFieldOfStudy(final FieldOfStudy fieldOfStudy)
  {
    this.fieldOfStudy = fieldOfStudy;
  }

  /**
   * Returns the user identifiable name for this plan.
   * <p>
   * Notice: this is not the ID (see {@code getID()} for that).
   *
   * @return {@code String} name of the plan
   */
  public String getPlanName()
  {
    return planName;
  }

  /**
   * Sets the user identifiable name for this plan.
   *
   * @param planName {@code String} name of the plan
   */
  public void setPlanName(final String planName)
  {
    this.planName = planName;
  }

}
