package com.plan.core.models;

/**
 * {@code StudyType} is used for the grouping of field's of study and provides users with
 * more information about a {@code FieldOfStudy}.
 *
 * @author Ernest Tussey
 * @version 1.0
 * @see FieldOfStudy
 * @see StudyType
 * @see TermType
 */
public enum StudyType
{
  MAJOR(0), MINOR(1), OTHER(2);

  private static final String ERROR_PREFIX = "Unexpected value: ";
  private final int value;

  /**
   * Constructs an instance of {@code StudyType} provided an integer
   * value.
   *
   * @param v the integer value
   */
  StudyType(final int v)
  {
    this.value = v;
  }

  /**
   * Utility method for retrieving a study type when stored as an integer.
   *
   * @param v the integer value of the study type
   * @return returns the study type
   * @throws IllegalStateException if the value does not represent any valid study type
   */
  public static StudyType of(final int v)
  {
    switch (v)
    {
      case 0:
        return MAJOR;
      case 1:
        return MINOR;
      case 2:
        return OTHER;
      default:
        throw new IllegalStateException(ERROR_PREFIX + v);
    }
  }

  @Override public String toString()
  {
    switch (value)
    {
      case 0:
        return "Major";
      case 1:
        return "Minor";
      case 2:
        return "Other";
      default:
        throw new IllegalStateException(ERROR_PREFIX + value);
    }
  }
}
