package com.plan.core.models;

/**
 * {@code TermType} is used for the grouping of term's and provides users with
 * more information about a {@code AcademicTerm}.
 *
 * @author Ernest Tussey
 * @version 1.0
 * @see AcademicTerm
 * @see StudyType
 * @see CourseType
 */
public enum TermType
{
  SEMESTER(0), TRIMESTER(1), QUARTER(2), SUMMER_SESSION(3), WINTER_SESSION(4);

  private static final String ERROR_PREFIX = "Unexpected value: ";
  private final int value;

  /**
   * Constructs an instance of {@code TermType} provided an integer
   * value.
   *
   * @param v the integer value
   */
  TermType(final int v)
  {
    this.value = v;
  }

  /**
   * Utility method for retrieving a term type when stored as an integer.
   *
   * @param v the integer value of the term type
   * @return returns the term type
   * @throws IllegalStateException if the value does not represent any valid term type
   */
  public static TermType of(final int v)
  {
    switch (v)
    {
      case 0:
        return SEMESTER;
      case 1:
        return TRIMESTER;
      case 2:
        return QUARTER;
      case 3:
        return SUMMER_SESSION;
      case 4:
        return WINTER_SESSION;
      default:
        throw new IllegalStateException(ERROR_PREFIX + v);
    }
  }

  @Override public String toString()
  {
    switch (value)
    {
      case 0:
        return "Semester";
      case 1:
        return "Trimester";
      case 2:
        return "Quarter";
      case 3:
        return "Summer Session";
      case 4:
        return "Winter Session";
      default:
        throw new IllegalStateException(ERROR_PREFIX + value);
    }
  }
}
