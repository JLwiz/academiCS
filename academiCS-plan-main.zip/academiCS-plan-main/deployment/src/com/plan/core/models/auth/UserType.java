package com.plan.core.models.auth;

import java.util.Locale;

public enum UserType
{
  STUDENT, FACULTY, ADMIN;

  @Override public String toString()
  {
    var chars = name().toLowerCase(Locale.ROOT);
    return Character.toUpperCase(chars.charAt(0)) + chars.substring(1);
  }
}
