package com.plan.core.services;

import com.plan.core.models.CourseGroup;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * {@code CourseGroupService} is a service for storing and managing CourseGroup
 * models. CourseGroup type is bound to IService.
 *
 * @author Ernest Tussey
 * @version 1.0
 */
public class CourseGroupService implements IService<CourseGroup>
{

  private final Map<String, CourseGroup> courseGroupMap;

  /**
   * Constructs an instance CourseGroupService.
   */
  public CourseGroupService()
  {
    this.courseGroupMap = new HashMap<>();
  }

  @Override public void create(final CourseGroup c)
  {
    this.courseGroupMap.put(c.getId(), c);
  }

  @Override public void delete(final String id)
  {
    if (id != null && courseGroupMap.containsKey(id))
      this.courseGroupMap.remove(id);
  }

  @Override public CourseGroup get(final String id)
  {
    return this.courseGroupMap.get(id);
  }

  @Override public Collection<CourseGroup> getAll()
  {
    return this.courseGroupMap.values();
  }

  @Override public boolean isIDTaken(final String id)
  {
    return this.courseGroupMap.containsKey(id);
  }
}
