package com.plan.core.services;

import com.plan.core.models.Course;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * {@code CourseService} is a service for storing and managing Course
 * models. Course type is bound to IService.
 *
 * @author Ernest Tussey
 * @version 1.0
 */
public class CourseService implements IService<Course>
{

  private final Map<String, Course> courseMap;

  /**
   * Constructs an instance of CourseService.
   */
  public CourseService()
  {
    this.courseMap = new HashMap<>();
  }

  @Override public void create(final Course c)
  {
    this.courseMap.put(c.getId(), c);
  }

  @Override public void delete(final String id)
  {
    if (id != null && courseMap.containsKey(id))
      this.courseMap.remove(id);
  }

  @Override public Course get(final String id)
  {
    return this.courseMap.get(id);
  }

  @Override public Collection<Course> getAll()
  {
    return this.courseMap.values();
  }

  @Override public boolean isIDTaken(final String id)
  {
    return this.courseMap.containsKey(id);
  }
}
