package com.plan.core.services;

import com.plan.core.models.FieldOfStudy;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * {@code FieldOfStudyService} is a service for storing and managing FieldOfStudy
 * models. FieldOfStudy type is bound to IService.
 *
 * @author Ernest Tussey
 * @version 1.0
 */
public class FieldOfStudyService implements IService<FieldOfStudy>
{
  private final Map<String, FieldOfStudy> fieldOfStudyMap;

  /**
   * Constructs an instance of FieldOfStudyService.
   */
  public FieldOfStudyService()
  {
    this.fieldOfStudyMap = new HashMap<>();
  }

  /**
   * Adds a new instance of FieldOfStudy.
   *
   * @param f the field of study
   */
  @Override public void create(final FieldOfStudy f)
  {
    this.fieldOfStudyMap.put(f.getId(), f);
  }

  /**
   * Removes a FieldOfStudy from this service.
   * If the passed ID is invaldi nothing occurs.
   *
   * @param id the model's id that is to be deleted
   */
  @Override public void delete(final String id)
  {
    if (id != null && fieldOfStudyMap.containsKey(id))
      this.fieldOfStudyMap.remove(id);
  }

  /**
   * Retrieves a FieldOfStudy model by ID.
   *
   * @param id the models id
   * @return a FieldOfStudy with the provided ID
   */
  @Override public FieldOfStudy get(final String id)
  {
    return this.fieldOfStudyMap.get(id);
  }

  /**
   * Retrieves all models in this service.
   *
   * @return {@code List} of FieldOfStudies
   */
  @Override public Collection<FieldOfStudy> getAll()
  {
    return this.fieldOfStudyMap.values();
  }

  /**
   * Returns true if a model with the passed ID already exists.
   *
   * @param id the id to test
   * @return {@code true} if that ID is taken
   */
  @Override public boolean isIDTaken(final String id)
  {
    return this.fieldOfStudyMap.containsKey(id);
  }
}
