package com.plan.core.services;

import com.plan.core.models.AbstractModel;

import java.util.Collection;

/**
 * {@code IService} is an interface that provides methods to handle
 * models in memory.
 *
 * @param <M> the model type
 * @author Ernest Tussey
 * @version 1.0
 */
public interface IService<M extends AbstractModel>
{

  /**
   * Creates a new model and stores it.
   *
   * @param model the new model
   */
  void create(M model);

  /**
   * Deletes an existing model. If not model exists with the
   * provided id the method does nothing.
   *
   * @param id the model's id that is to be deleted
   */
  void delete(String id);

  /**
   * Gets a model via its String id. {@code null} is returned
   * if a model with the provided id does not exist.
   *
   * @param id the models id
   * @return a model with the provided id or {@code null}
   */
  M get(String id);

  /**
   * Returns a {@code Collection} of models in this
   * services scope.
   *
   * @return {@code Collection} of all models
   */
  Collection<M> getAll();

  /**
   * Checks if any model currently holds the provided id.
   *
   * @param id the id to test
   * @return {@code true} if a model exists with that id
   */
  boolean isIDTaken(String id);

}
