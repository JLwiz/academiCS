package com.plan.core.services;

import com.plan.core.models.StudentPlan;

/**
 * Manages the active StudentPlan model. Only one StudentPlan can
 * be considered active at once.
 *
 * @author Ernest Tussey
 * @version 1.0
 */
public class StudentPlanService
{

  private StudentPlan plan;

  /**
   * Constructs an instance of {@code StudentPlanService}.
   */
  public StudentPlanService()
  {
  }

  /**
   * Returns the active student student plan.
   * {@code null} is returned if there is no active
   * student plan.
   *
   * @return the active StudentPlan model
   */
  public StudentPlan getPlan()
  {
    return plan;
  }

  /**
   * Sets the active student plan.
   *
   * @param plan the active student plan
   */
  public void setPlan(final StudentPlan plan)
  {
    this.plan = plan;
  }
}
