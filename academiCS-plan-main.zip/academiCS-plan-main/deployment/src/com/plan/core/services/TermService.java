package com.plan.core.services;

import com.plan.core.models.AcademicTerm;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * {@code TermService} is an implemenation of {@code IService}
 * for managing AcademicTerm models.
 *
 * @author Ernest Tussey
 * @version 1.0
 */
public class TermService implements IService<AcademicTerm>
{

  private final Map<String, AcademicTerm> termMap;

  /**
   * Construct's a new instance of TermService.
   */
  public TermService()
  {
    this.termMap = new HashMap<>();
  }

  /**
   * Adds an AcademicTerm model to this service.
   *
   * @param t the model to add
   */
  public void create(final AcademicTerm t)
  {
    this.termMap.put(t.getId(), t);
  }

  /**
   * Removes a model from this service by ID.
   *
   * @param id the model's id that is to be deleted
   */
  public void delete(final String id)
  {
    if (id != null && termMap.containsKey(id))
      this.termMap.remove(id);
  }

  /**
   * Retrieves an AcademicTerm model by ID.
   * {@code null} is returned if no model with that
   * ID in this service.
   *
   * @param id the models id
   * @return the model with the passed ID
   */
  public AcademicTerm get(final String id)
  {
    return this.termMap.get(id);
  }

  /**
   * Retrieves all models in this service.
   *
   * @return {@code List} of AcademicTerm models
   */
  public Collection<AcademicTerm> getAll()
  {
    return this.termMap.values();
  }

  /**
   * Returns true if a model with the passed ID
   * exists in this service.
   *
   * @param id the id to test
   * @return {@code true} if a model in this service has the passed ID
   */
  public boolean isIDTaken(final String id)
  {
    return this.termMap.containsKey(id);
  }
}
