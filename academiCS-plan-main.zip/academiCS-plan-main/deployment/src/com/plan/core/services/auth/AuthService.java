package com.plan.core.services.auth;

import com.plan.core.models.auth.UserType;

public class AuthService
{
  private UserType userType;

  public UserType getUserType()
  {
    return this.userType;
  }

  public boolean isLoggedIn()
  {
    return this.userType != null;
  }

  public void login(final UserType ut)
  {
    this.userType = ut;
  }

  public void logout()
  {
    this.userType = null;
  }
}
