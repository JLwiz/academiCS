package com.plan.core.uimodels;

import javax.swing.*;

/**
 * {@code AbstractView} represents a JPanel that is managed by a controller.
 *
 * @param <C> the controller type
 * @author Ernest Tussey
 * @version 1.0
 */
public abstract class AbstractView<C extends IController> extends JPanel
{

  /**
   * Allows protected controller access to any children.
   */
  protected final C controller;

  /**
   * Constructs an instance of {@code AbstractView} provided
   * an owning controller.
   *
   * @param controller the controller that manages this view
   */
  public AbstractView(final C controller)
  {
    this.controller = controller;
  }

}
