package com.plan.core.uimodels;

import javax.swing.*;

/**
 * Utility class for common route guards.
 *
 * @author Ernest Tussey
 * @version 1.0
 */
public class Guards
{

  /**
   * When a route change occurs this guard is invoked. It first checks if
   * the controller wants to deactivate. If it is able to to deactivate
   * then the guard will just return {@code true}. Otherwise a modal
   * prompts the user to confirm if they wish to proceed. The user's
   * choice is returned if the guard should block the route change.
   *
   * @return {@code true} if the there are no unsaved changes
   * or the user overrides the guard
   */
  public static IGuard unsavedChangesGuard()
  {
    return controller -> {
      if (!controller.canDeactivate())
      {
        return JOptionPane.showConfirmDialog(controller.getView(),
            "Are you sure you want to leave without saving?") == JOptionPane.OK_OPTION;
      }
      return true;
    };
  }

}
