package com.plan.core.uimodels;

import javax.swing.*;

/**
 * {@code IController} is the controller of a graphic view. This is the place to
 * handle any events raised by the view and provide methods to be invoked by the
 * view.
 *
 * @author Ernest Tussey
 * @version 1.0
 */
public interface IController
{

  /**
   * This method is NOT called when a route change occurs.
   * This is an optional method that can be utilized by a route
   * guard.
   *
   * @return true if the component can deactivate
   */
  default boolean canDeactivate()
  {
    return true;
  }

  /**
   * Returns the JPanel that represents the view of this controller.
   * Preferably {@code AbstractView} should be used as the view.
   *
   * @return the graphic view
   */
  JPanel getView();

  /**
   * If the controller is index by a ComponentRouter this method is invoked
   * after the route change occurs. This method allows a route to confirm
   * it wish to be invoked and set up any graphic interface before it is
   * rendered.
   */
  void onInit();

}
