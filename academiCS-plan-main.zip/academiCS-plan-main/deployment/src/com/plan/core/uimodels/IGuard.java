package com.plan.core.uimodels;

/**
 * {@code IGuard} is a route guard the can be used to inhibit the deactivation
 * of a route. IGuard is indexed by a {@code ComponentRouter} when a route is
 * registered.
 *
 * @author Ernest Tussey
 * @version 1.0
 */
public interface IGuard
{

  /**
   * When a route change is initiated all guards registered with the active route
   * have this method invoked. If {@code false} is returned the route change is
   * inhibited.
   *
   * @param controller the active controller
   * @return {@code true} if the current route can deactivate
   */
  boolean canDeactivate(final IController controller);

}
