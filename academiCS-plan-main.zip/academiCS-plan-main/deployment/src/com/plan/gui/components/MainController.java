package com.plan.gui.components;

import com.plan.core.conf.StringLocalizer;
import com.plan.core.io.PlanLogger;
import com.plan.core.services.auth.AuthService;
import com.plan.core.uimodels.IController;
import com.plan.gui.components.auth.AuthController;
import com.plan.gui.components.planeditor.PlanEditorController;
import com.plan.gui.routing.ComponentRouter;
import com.plan.gui.routing.RouteChangeListener;
import com.plan.gui.routing.RouteConstants;
import com.plan.gui.routing.RouteEvent;

import javax.swing.*;
import javax.swing.plaf.FontUIResource;
import java.awt.*;

public class MainController implements IController, RouteChangeListener
{

  private final Dimension minScreenSize = new Dimension(800, 600);
  private final MainPanel mainPanel;
  private final ComponentRouter router;
  private final AuthService authService;

  public MainController()
  {
    this.mainPanel = new MainPanel(this);
    this.router = new ComponentRouter();
    this.authService = new AuthService();
    this.router.addRouteChangeListener(this);
    this.router.putRoute(RouteConstants.AUTH, new AuthController(router, authService));
    this.router.putRoute(RouteConstants.PLAN_EDITOR, new PlanEditorController(authService));
  }

  public static void setUIFont(final javax.swing.plaf.FontUIResource f)
  {
    java.util.Enumeration<?> keys = UIManager.getDefaults().keys();
    while (keys.hasMoreElements())
    {
      Object key = keys.nextElement();
      Object value = UIManager.get(key);
      if (value instanceof javax.swing.plaf.FontUIResource)
        UIManager.put(key, f);
    }
  }

  @Override public boolean canDeactivate()
  {
    return true;
  }

  @Override public JPanel getView()
  {
    return this.mainPanel;
  }

  /**
   *
   */
  public void load()
  {
    try
    {
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
      setUIFont(new FontUIResource("Arial", Font.PLAIN, 12));
    }
    catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException e)
    {
      e.printStackTrace();
      PlanLogger.getInstance().error("Failed to apply look and feel", e);
    }

    JFrame frame = new JFrame();
    frame.setTitle(StringLocalizer.getInstance().getString("AcademiCS_Plan"));
    frame.setMinimumSize(minScreenSize);
    frame.setContentPane(mainPanel);
    frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
    frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    frame.setVisible(true);

    SwingUtilities.updateComponentTreeUI(frame);
    this.router.changeRoute(RouteConstants.AUTH);

  }

  @Override public void onInit()
  {

  }

  @Override public void onRouteChange(final RouteEvent e)
  {
    this.mainPanel.setPage(e.getController().getView());
  }
}
