package com.plan.gui.components;

import com.plan.core.uimodels.AbstractView;

import javax.swing.*;
import java.awt.*;

public class MainPanel extends AbstractView<MainController>
{

  public MainPanel(MainController controller)
  {
    super(controller);
    setLayout(new BorderLayout());
  }

  public void setPage(JPanel page)
  {
    this.removeAll();
    this.add(page);
    synchronized (getTreeLock())
    {
      validateTree();
    }
    SwingUtilities.updateComponentTreeUI(this);
    page.repaint();
    this.repaint();
  }
}
