package com.plan.gui.components.auth;

import com.plan.core.models.auth.UserType;
import com.plan.core.uimodels.AbstractView;
import com.plan.gui.util.Styles;

import javax.swing.*;
import java.awt.*;

public class AuthComponent extends AbstractView<AuthController>
{

  private static final Dimension CARD_SIZE = new Dimension(300, 200);

  /**
   * Constructs an instance of {@code AbstractView} provided
   * an owning controller.
   *
   * @param controller the controller that manages this view
   */
  public AuthComponent(final AuthController controller)
  {
    super(controller);
    buildUI();
  }

  public void buildUI()
  {
    setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
    setAlignmentX(CENTER_ALIGNMENT);
    JPanel card = new JPanel();
    card.setBackground(Color.RED);
    card.setMinimumSize(CARD_SIZE);
    card.setPreferredSize(CARD_SIZE);
    card.setMaximumSize(CARD_SIZE);
    card.setBackground(Color.WHITE);
    card.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
    card.setLayout(new GridLayout(5, 1));

    JLabel label = new JLabel("Select User Type", SwingConstants.CENTER);
    label.setFont(Styles.DEFAULT_HEADER_SIZE);

    card.add(label);
    JComboBox<UserType> userType = new JComboBox<>();
    for (UserType value : UserType.values())
    {
      userType.addItem(value);
    }
    card.add(getSpacer());
    card.add(userType);
    card.add(getSpacer());

    JButton button = new JButton("LOGIN");
    button.addActionListener(e -> controller.login((UserType) userType.getSelectedItem()));
    card.add(button);
    add(Box.createVerticalGlue());
    add(card);
    add(Box.createVerticalGlue());
  }

  private JPanel getSpacer()
  {
    JPanel p = new JPanel();
    p.setBackground(Color.WHITE);
    return p;
  }
}
