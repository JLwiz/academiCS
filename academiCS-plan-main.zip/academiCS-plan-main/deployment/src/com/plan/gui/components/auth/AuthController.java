package com.plan.gui.components.auth;

import com.plan.core.models.auth.UserType;
import com.plan.core.services.auth.AuthService;
import com.plan.core.uimodels.IController;
import com.plan.gui.routing.ComponentRouter;
import com.plan.gui.routing.RouteConstants;

import javax.swing.*;

public class AuthController implements IController
{
  private final AuthComponent view;
  private final AuthService authService;
  private final ComponentRouter router;

  public AuthController(final ComponentRouter router, final AuthService authService)
  {
    this.view = new AuthComponent(this);
    this.authService = authService;
    this.router = router;
  }

  @Override public boolean canDeactivate()
  {
    return this.authService.isLoggedIn();
  }

  @Override public JPanel getView()
  {
    return view;
  }

  public void login(final UserType userType)
  {
    if (userType == null)
      return;
    this.authService.login(userType);
    this.router.changeRoute(RouteConstants.PLAN_EDITOR);
  }

  @Override public void onInit()
  {

  }
}
