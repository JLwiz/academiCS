package com.plan.gui.components.planeditor;

import com.plan.core.conf.StringLocalizer;
import com.plan.core.io.FileTypeFilter;
import com.plan.core.io.ModelSerializer;
import com.plan.core.io.PlanLogger;
import com.plan.core.models.StudentPlan;
import com.plan.core.models.auth.UserType;
import com.plan.core.services.*;
import com.plan.core.services.auth.AuthService;
import com.plan.core.uimodels.Guards;
import com.plan.core.uimodels.IController;
import com.plan.gui.components.planeditor.courseedit.CourseEditController;
import com.plan.gui.components.planeditor.coursegroupedit.CourseGroupEditController;
import com.plan.gui.components.planeditor.coursegroupinfo.CourseGroupInfoController;
import com.plan.gui.components.planeditor.coursegroupsearch.CourseGroupSearchController;
import com.plan.gui.components.planeditor.courseinfo.CourseInfoController;
import com.plan.gui.components.planeditor.coursesearch.CourseSearchController;
import com.plan.gui.components.planeditor.dashboard.DashBoardController;
import com.plan.gui.components.planeditor.fieldofstudyedit.FieldOfStudyEditController;
import com.plan.gui.components.planeditor.fieldofstudyinfo.FieldOfStudyInfoController;
import com.plan.gui.components.planeditor.fieldofstudysearch.FieldOfStudySearchController;
import com.plan.gui.components.planeditor.gradchecklist.GradChecklistController;
import com.plan.gui.components.planeditor.planofstudy.PlanOfStudyController;
import com.plan.gui.components.planeditor.studenteditor.StudentEditorController;
import com.plan.gui.components.planeditor.termedit.TermEditController;
import com.plan.gui.components.planeditor.terminfo.TermInfoController;
import com.plan.gui.components.planeditor.termsearch.TermSearchController;
import com.plan.gui.components.reusuable.NewStudentPlanDialog;
import com.plan.gui.components.reusuable.StudentPlanValidator;
import com.plan.gui.routing.ComponentRouter;
import com.plan.gui.routing.RouteChangeListener;
import com.plan.gui.routing.RouteConstants;
import com.plan.gui.routing.RouteEvent;

import javax.swing.*;
import java.io.IOException;
import java.util.Locale;
import java.util.ResourceBundle;

public class PlanEditorController implements IController, RouteChangeListener
{

  private final PlanEditorView view;
  private final AuthService authService;
  private final ComponentRouter subRouter;
  private final CourseService courseService;
  private final TermService termService;
  private final CourseGroupService courseGroupService;
  private final FieldOfStudyService fieldOfStudyService;
  private final StudentPlanService studentPlanService;
  private final StudentEditorController editor;
  private final DashBoardController dashBoardController;
  private final StudentPlanValidator planValidator;
  private boolean hasDataBeenImported;

  private final ResourceBundle strings =
      ResourceBundle.getBundle("Strings", Locale.getDefault(), this.getClass().getClassLoader());

  public PlanEditorController(final AuthService authService)
  {
    this.authService = authService;
    this.view = new PlanEditorView(this);
    this.subRouter = new ComponentRouter();
    this.courseService = new CourseService();
    this.termService = new TermService();
    this.courseGroupService = new CourseGroupService();
    this.fieldOfStudyService = new FieldOfStudyService();
    this.studentPlanService = new StudentPlanService();
    this.editor =
        new StudentEditorController(studentPlanService, termService, courseService, subRouter);
    planValidator =
        new StudentPlanValidator(getView(), courseService, termService, courseGroupService,
            fieldOfStudyService);

    this.subRouter.addRouteChangeListener(this);
    this.dashBoardController =
        new DashBoardController(authService, termService, courseService, courseGroupService,
            fieldOfStudyService, subRouter);
    this.subRouter.putRoute(RouteConstants.DASHBOARD_ROUTE, dashBoardController);
    this.subRouter.putRoute(RouteConstants.STUDENT_EDITOR, editor);

    this.subRouter.putRoute(RouteConstants.PRINT_CHECKLIST,
        new GradChecklistController(studentPlanService, subRouter));
    this.subRouter.putRoute(RouteConstants.PRINT_PLAN,
        new PlanOfStudyController(studentPlanService, subRouter));

    this.subRouter.putRoute(RouteConstants.COURSE_SEARCH,
        new CourseSearchController(courseService, subRouter));
    this.subRouter
        .putRoute(RouteConstants.COURSE_EDIT, new CourseEditController(courseService, subRouter),
            Guards.unsavedChangesGuard());
    this.subRouter.putRoute(RouteConstants.COURSE_VIEW,
        new CourseInfoController(authService, courseService, subRouter));

    this.subRouter
        .putRoute(RouteConstants.TERM_SEARCH, new TermSearchController(termService, subRouter));
    this.subRouter.putRoute(RouteConstants.TERM_EDIT,
        new TermEditController(termService, courseService, subRouter),
        Guards.unsavedChangesGuard());
    this.subRouter.putRoute(RouteConstants.TERM_VIEW,
        new TermInfoController(authService, termService, subRouter));

    this.subRouter.putRoute(RouteConstants.COURSE_GROUP_SEARCH,
        new CourseGroupSearchController(courseGroupService, subRouter));
    this.subRouter.putRoute(RouteConstants.COURSE_GROUP_EDIT,
        new CourseGroupEditController(courseGroupService, courseService, subRouter),
        Guards.unsavedChangesGuard());
    this.subRouter.putRoute(RouteConstants.COURSE_GROUP_VIEW,
        new CourseGroupInfoController(authService, courseGroupService, subRouter));

    this.subRouter.putRoute(RouteConstants.STUDY_SEARCH,
        new FieldOfStudySearchController(fieldOfStudyService, subRouter));
    this.subRouter.putRoute(RouteConstants.STUDY_EDIT,
        new FieldOfStudyEditController(fieldOfStudyService, courseGroupService, subRouter),
        Guards.unsavedChangesGuard());
    this.subRouter.putRoute(RouteConstants.STUDY_VIEW,
        new FieldOfStudyInfoController(authService, fieldOfStudyService, subRouter));
  }

  @Override public boolean canDeactivate()
  {
    return true;
  }

  public void createStudentPlan()
  {
    NewStudentPlanDialog dialog = new NewStudentPlanDialog(getView(), fieldOfStudyService);
    if (dialog.show() != JOptionPane.OK_OPTION)
      return;
    StudentPlan plan = dialog.get();

    if (!planValidator.validatePlan(plan))
      return;
    studentPlanService.setPlan(plan);
    if (this.subRouter.getActiveRoute().equals(RouteConstants.STUDENT_EDITOR))
    {
      this.editor.onInit();
    }
    else
    {
      this.subRouter.changeRoute(RouteConstants.STUDENT_EDITOR);
    }
    view.disableNewOpenPlan();
  }

  public void exportCourseData()
  {
    JFileChooser fileChooser = new JFileChooser();
    fileChooser.setDialogTitle(StringLocalizer.getInstance().getString("Export_Data"));
    fileChooser.setAcceptAllFileFilterUsed(false);
    fileChooser.setFileFilter(new FileTypeFilter(FileTypeFilter.SERIALIZED_DATA,
        StringLocalizer.getInstance().getString("Serialized_Data")));
    if (fileChooser.showSaveDialog(getView()) == JFileChooser.APPROVE_OPTION)
    {
      ModelSerializer
          .exportData(fileChooser.getSelectedFile().getPath(), courseService, termService,
              courseGroupService, fieldOfStudyService);
    }
  }

  @Override public JPanel getView()
  {
    return this.view;
  }

  public void importCourseData()
  {

    JFileChooser fileChooser = new JFileChooser();
    fileChooser.setDialogTitle(StringLocalizer.getInstance().getString("Import_Data"));
    fileChooser.setAcceptAllFileFilterUsed(false);
    fileChooser.setFileFilter(new FileTypeFilter(FileTypeFilter.SERIALIZED_DATA,
        StringLocalizer.getInstance().getString("Serialized_Data")));
    if (fileChooser.showOpenDialog(getView()) == JFileChooser.APPROVE_OPTION)
    {
      if (hasDataBeenImported)
      {
        int opt = JOptionPane.showOptionDialog(getView(),
            StringLocalizer.getInstance().getString("Data_Override_Dialog"),
            StringLocalizer.getInstance().getString("Data_Conflict"), JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE, null, null, null);
        if (opt == JOptionPane.NO_OPTION)
          return;
      }
      try
      {
        ModelSerializer
            .importData(fileChooser.getSelectedFile().getPath(), courseService, termService,
                courseGroupService, fieldOfStudyService);
        this.dashBoardController.loadCounts();

      }
      catch (IOException | ClassNotFoundException e)
      {
        JOptionPane.showMessageDialog(getView(),
            StringLocalizer.getInstance().getString("Corrupt_Data_Dialog"),
            StringLocalizer.getInstance().getString("Import_Error"), JOptionPane.ERROR_MESSAGE);
        return;
      }
    }
    hasDataBeenImported = true;
  }

  public void navigate(String route)
  {
    this.subRouter.changeRoute(route);
  }

  public void navigateToCourseEdit()
  {
    if (subRouter.getActiveRoute().equals(RouteConstants.COURSE_VIEW))
    {
      this.subRouter.changeRoute(RouteConstants.COURSE_EDIT, subRouter.getActiveParams());
      return;
    }
    subRouter.changeRoute(RouteConstants.COURSE_EDIT);
  }

  public void navigateToCourseGroupEdit()
  {
    if (subRouter.getActiveRoute().equals(RouteConstants.COURSE_GROUP_VIEW))
    {
      this.subRouter.changeRoute(RouteConstants.COURSE_GROUP_EDIT, subRouter.getActiveParams());
      return;
    }
    subRouter.changeRoute(RouteConstants.COURSE_GROUP_EDIT);
  }

  public void navigateToFieldOfStudyEdit()
  {
    if (subRouter.getActiveRoute().equals(RouteConstants.STUDY_VIEW))
    {
      this.subRouter.changeRoute(RouteConstants.STUDY_EDIT, subRouter.getActiveParams());
      return;
    }
    subRouter.changeRoute(RouteConstants.STUDY_EDIT);
  }

  public void navigateToTermEdit()
  {
    if (subRouter.getActiveRoute().equals(RouteConstants.TERM_VIEW))
    {
      this.subRouter.changeRoute(RouteConstants.TERM_EDIT, subRouter.getActiveParams());
      return;
    }
    subRouter.changeRoute(RouteConstants.TERM_EDIT);
  }

  @Override public void onInit()
  {
    this.view.enableAdminFunctions(authService.getUserType() == UserType.ADMIN);
    this.subRouter.changeRoute(RouteConstants.DASHBOARD_ROUTE);
  }

  @Override public void onRouteChange(final RouteEvent e)
  {
    String[] params = this.subRouter.getActiveParams();
    if (params != null && params.length == 1 && params[0].equals(RouteConstants.CLOSE_PLAN))
    {
      this.view.enableNewOpenPlan();
    }
    this.view.setPage(e.getController().getView());
  }

  public void openStudentPlan()
  {
    JFileChooser fileChooser = new JFileChooser();
    fileChooser.setDialogTitle(StringLocalizer.getInstance().getString("Open_Student_Plan"));
    fileChooser.setAcceptAllFileFilterUsed(false);
    fileChooser.setFileFilter(new FileTypeFilter(FileTypeFilter.PLAN_DATA,
        StringLocalizer.getInstance().getString("Student_Plan")));
    if (fileChooser.showOpenDialog(getView()) == JFileChooser.APPROVE_OPTION)
    {
      try
      {
        StudentPlan plan = ModelSerializer.openStudentPlan(fileChooser.getSelectedFile().getPath());
        if (!planValidator.validatePlan(plan))
          return;
        studentPlanService.setPlan(plan);
      }
      catch (IOException | ClassNotFoundException e)
      {
        JOptionPane.showMessageDialog(getView(),
            StringLocalizer.getInstance().getString("Corrupt_Data_Dialog"),
            StringLocalizer.getInstance().getString("Import Error"), JOptionPane.ERROR_MESSAGE);
        PlanLogger.getInstance().error("Failed to open student plan", e);
        return;
      }
      if (this.subRouter.getActiveRoute().equals(RouteConstants.STUDENT_EDITOR))
      {
        this.editor.onInit();
      }
      else
      {
        this.subRouter.changeRoute(RouteConstants.STUDENT_EDITOR);
      }
      view.disableNewOpenPlan();
    }
  }
}
