package com.plan.gui.components.planeditor;

import com.plan.core.conf.StringLocalizer;
import com.plan.core.uimodels.AbstractView;
import com.plan.gui.routing.RouteConstants;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;

public class PlanEditorView extends AbstractView<PlanEditorController>
{

  private JPanel contentArea;
  private JMenuItem newPlan;
  private JMenuItem openPlan;
  private JMenuItem fieldOfStudyNew;
  private JMenuItem courseGroupNew;
  private JMenuItem termNew;
  private JMenuItem courseNew;
  private JSeparator adminSeparator;

  public PlanEditorView(PlanEditorController controller)
  {
    super(controller);
    buildUI();
  }

  public void disableNewOpenPlan()
  {
    this.newPlan.setEnabled(false);
    this.openPlan.setEnabled(false);
  }

  public void enableAdminFunctions(final boolean isAdmin)
  {
    this.adminSeparator.setVisible(isAdmin);
    this.courseNew.setVisible(isAdmin);
    this.termNew.setVisible(isAdmin);
    this.courseGroupNew.setVisible(isAdmin);
    this.fieldOfStudyNew.setVisible(isAdmin);
  }

  public void enableNewOpenPlan()
  {
    this.newPlan.setEnabled(true);
    this.openPlan.setEnabled(true);
  }

  public void setPage(JPanel page)
  {
    contentArea.removeAll();

    contentArea.add(page);
    synchronized (getTreeLock())
    {
      validateTree();
    }
    SwingUtilities.updateComponentTreeUI(this);
    page.repaint();
    this.repaint();
  }

  private void buildUI()
  {
    this.setLayout(new BorderLayout());

    JMenuBar menuBar = new JMenuBar();
    menuBar.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW)
        .put(KeyStroke.getKeyStroke(KeyEvent.VK_F10, 0), "none");

    JMenu fileMenu = new JMenu(StringLocalizer.getInstance().getString("File"));
    fileMenu.setMnemonic('F');
    menuBar.add(fileMenu);

    newPlan = new JMenuItem(StringLocalizer.getInstance().getString("New_Student_Plan"));
    newPlan.setAccelerator(KeyStroke.getKeyStroke("ctrl N"));
    newPlan.addActionListener(l -> controller.createStudentPlan());
    fileMenu.add(newPlan);

    openPlan = new JMenuItem(StringLocalizer.getInstance().getString("Open_Plan"));
    openPlan.setAccelerator(KeyStroke.getKeyStroke("ctrl O"));
    openPlan.addActionListener(l -> controller.openStudentPlan());
    fileMenu.add(openPlan);

    fileMenu.add(new JSeparator());

    JMenuItem importCourses = new JMenuItem(StringLocalizer.getInstance().getString("Import_Data"));
    importCourses.addActionListener(e -> controller.importCourseData());
    fileMenu.add(importCourses);

    JMenuItem exportData = new JMenuItem(StringLocalizer.getInstance().getString("Export_Data"));
    exportData.addActionListener(e -> controller.exportCourseData());
    fileMenu.add(exportData);

    fileMenu.add(new JSeparator());

    JMenuItem exit = new JMenuItem(StringLocalizer.getInstance().getString("Exit"));
    exit.setMnemonic('x');
    exit.addActionListener(e -> System.exit(0));
    fileMenu.add(exit);

    JMenu navigateMenu = new JMenu(StringLocalizer.getInstance().getString("Navigate"));
    JMenuItem dashboard = new JMenuItem(StringLocalizer.getInstance().getString("Dashboard"));
    dashboard.setAccelerator(KeyStroke.getKeyStroke("F1"));
    dashboard.addActionListener(e -> controller.navigate(RouteConstants.DASHBOARD_ROUTE));
    navigateMenu.add(dashboard);

    JMenuItem studentEditor =
        new JMenuItem(StringLocalizer.getInstance().getString("Student_Plan_Editor"));
    studentEditor.setAccelerator(KeyStroke.getKeyStroke("F2"));
    studentEditor.addActionListener(e -> controller.navigate(RouteConstants.STUDENT_EDITOR));
    navigateMenu.add(studentEditor);

    navigateMenu.add(new JSeparator());

    JMenuItem courseSearch =
        new JMenuItem(StringLocalizer.getInstance().getString("Course_Search"));
    courseSearch.setAccelerator(KeyStroke.getKeyStroke("F5"));
    courseSearch.addActionListener(e -> controller.navigate(RouteConstants.COURSE_SEARCH));
    navigateMenu.add(courseSearch);

    JMenuItem termSearch = new JMenuItem(StringLocalizer.getInstance().getString("Term_Search"));
    termSearch.setAccelerator(KeyStroke.getKeyStroke("F6"));
    termSearch.addActionListener(e -> controller.navigate(RouteConstants.TERM_SEARCH));
    navigateMenu.add(termSearch);

    JMenuItem courseGroupSearch =
        new JMenuItem(StringLocalizer.getInstance().getString("Course_Group_Search"));
    courseGroupSearch.setAccelerator(KeyStroke.getKeyStroke("F7"));
    courseGroupSearch
        .addActionListener(e -> controller.navigate(RouteConstants.COURSE_GROUP_SEARCH));
    navigateMenu.add(courseGroupSearch);

    JMenuItem fieldOfStudySearch =
        new JMenuItem(StringLocalizer.getInstance().getString("Field_Of_Study_Search"));
    fieldOfStudySearch.setAccelerator(KeyStroke.getKeyStroke("F8"));
    fieldOfStudySearch.addActionListener(e -> controller.navigate(RouteConstants.STUDY_SEARCH));
    navigateMenu.add(fieldOfStudySearch);

    adminSeparator = new JSeparator();

    navigateMenu.add(adminSeparator);

    courseNew = new JMenuItem(StringLocalizer.getInstance().getString("Create_New_Course"));
    courseNew.setAccelerator(KeyStroke.getKeyStroke("F9"));
    courseNew.addActionListener(e -> controller.navigateToCourseEdit());
    navigateMenu.add(courseNew);

    termNew = new JMenuItem(StringLocalizer.getInstance().getString("Create_New_Term"));
    termNew.setAccelerator(KeyStroke.getKeyStroke("F10"));
    termNew.addActionListener(e -> controller.navigateToTermEdit());
    navigateMenu.add(termNew);

    courseGroupNew =
        new JMenuItem(StringLocalizer.getInstance().getString("Create_New_Course_Group"));
    courseGroupNew.setAccelerator(KeyStroke.getKeyStroke("F11"));
    courseGroupNew.addActionListener(e -> controller.navigateToCourseGroupEdit());
    navigateMenu.add(courseGroupNew);

    fieldOfStudyNew =
        new JMenuItem(StringLocalizer.getInstance().getString("Create_New_Field_Of_Study"));
    fieldOfStudyNew.setAccelerator(KeyStroke.getKeyStroke("F12"));
    fieldOfStudyNew.addActionListener(e -> controller.navigateToFieldOfStudyEdit());
    navigateMenu.add(fieldOfStudyNew);

    menuBar.add(navigateMenu);
    this.add(menuBar, BorderLayout.NORTH);

    contentArea = new JPanel();
    contentArea.setLayout(new BorderLayout());

    JScrollPane scrollPane = new JScrollPane(contentArea);
    scrollPane.getVerticalScrollBar().setUnitIncrement(16);
    scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
    scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
    this.add(scrollPane, BorderLayout.CENTER);
  }
}
