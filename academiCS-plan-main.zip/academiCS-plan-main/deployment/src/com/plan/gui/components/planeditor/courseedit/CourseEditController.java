package com.plan.gui.components.planeditor.courseedit;

import com.plan.core.models.Course;
import com.plan.core.models.CourseType;
import com.plan.core.services.CourseService;
import com.plan.core.uimodels.IController;
import com.plan.gui.routing.ComponentRouter;
import com.plan.gui.routing.RouteConstants;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.util.List;

public class CourseEditController implements IController, DocumentListener
{

  private final CourseService service;
  private final ComponentRouter router;
  private final CourseEditView view;

  private boolean hasBeenEdited;

  public CourseEditController(CourseService service, ComponentRouter router)
  {
    this.service = service;
    this.router = router;
    this.view = new CourseEditView(this);
  }

  @Override public boolean canDeactivate()
  {
    return !this.hasBeenEdited;
  }

  @Override public void changedUpdate(DocumentEvent e)
  {

  }

  public CourseService getService()
  {
    return service;
  }

  @Override public JPanel getView()
  {
    return view;
  }

  @Override public void insertUpdate(DocumentEvent e)
  {
    this.hasBeenEdited = true;
    this.view.enableSave();
  }

  public boolean isValidID(String id)
  {
    return !this.service.isIDTaken(id);
  }

  @Override public void onInit()
  {
    this.view.resetForm();
    if (router.getActiveParams() != null && router.getActiveParams().length > 0)
    {
      Course loadedCourse = this.service.get(router.getActiveParams()[0]);
      if (loadedCourse == null)
      {
        this.hasBeenEdited = false; // force route change
        this.router.changeRoute(RouteConstants.COURSE_SEARCH);
      }
      else
      {
        this.view.setForm(loadedCourse);
      }
    }
    this.hasBeenEdited = false;
    view.setFocus();
  }

  @Override public void removeUpdate(DocumentEvent e)
  {
    this.hasBeenEdited = true;
    this.view.enableSave();
  }

  public void save(String id, String name, String shortName, int units, CourseType type,
      String description, List<Course> sp, List<Course> asp, List<Course> wp, List<Course> awp,
      List<Course> co, List<Course> aco)
  {
    Course course = new Course(id, System.currentTimeMillis());
    course.setTitle(name);
    course.setAbbreviatedTitle(shortName);
    course.setUnits(units);
    course.setCourseType(type);
    course.setDescription(description);
    course.setStrongPrerequisites(sp);
    course.setAltStrongPrerequisites(asp);
    course.setWeakPrerequisites(wp);
    course.setAltWeakPrerequisites(awp);
    course.setCorequisites(co);
    course.setAltCorequisites(aco);

    this.service.create(course);
    this.hasBeenEdited = false;
    this.router.changeRoute(RouteConstants.COURSE_SEARCH);
  }
}
