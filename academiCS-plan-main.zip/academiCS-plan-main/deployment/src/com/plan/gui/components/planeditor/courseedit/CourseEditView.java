package com.plan.gui.components.planeditor.courseedit;

import com.plan.core.conf.StringLocalizer;
import com.plan.core.models.Course;
import com.plan.core.models.CourseType;
import com.plan.core.uimodels.AbstractView;
import com.plan.gui.components.reusuable.CourseSelectionList;
import com.plan.gui.util.FormUtil;
import com.plan.gui.util.Styles;

import javax.swing.*;
import java.awt.*;

public class CourseEditView extends AbstractView<CourseEditController>
{

  private JTextField courseCodeField;
  private JTextField courseNameField;
  private JTextField courseShortNameField;
  private JTextField courseUnitField;
  private JComboBox<CourseType> courseTypeField;
  private JTextArea descriptionField;
  private JButton saveButton;

  private CourseSelectionList strongPrerequisites;
  private CourseSelectionList altStrongPrerequisites;

  private CourseSelectionList weakPrerequisites;
  private CourseSelectionList altWeakPrerequisites;

  private CourseSelectionList corequisites;
  private CourseSelectionList altCorequisites;

  private JLabel pageTitle;

  private boolean isNew;

  public CourseEditView(CourseEditController controller)
  {
    super(controller);
    buildUI();
  }

  public void enableSave()
  {
    saveButton.setEnabled(true);
  }

  public boolean isFormValid()
  {
    boolean b = FormUtil.isValidText(courseCodeField, 1);
    boolean b1 = FormUtil.isValidText(courseNameField, 1);
    boolean b2 = FormUtil.isValidText(courseShortNameField, 1);
    boolean b3 = FormUtil.isValidInt(courseUnitField, 0, 100);
    if (this.isNew && !controller.isValidID(courseCodeField.getText()))
    {
      courseCodeField.setBorder(Styles.ERROR_BORDER);
      return false;
    }
    return b && b1 && b2 && b3;
  }

  public void resetForm()
  {
    this.isNew = true;
    this.pageTitle.setText(StringLocalizer.getInstance().getString("Create_Course"));
    strongPrerequisites.reset();
    altStrongPrerequisites.reset();
    weakPrerequisites.reset();
    altWeakPrerequisites.reset();
    corequisites.reset();
    altCorequisites.reset();

    courseCodeField.setEnabled(true);
    courseCodeField.setText("");
    courseCodeField.setBorder(Styles.DEFAULT_BORDER);
    courseNameField.setText("");
    courseNameField.setBorder(Styles.DEFAULT_BORDER);
    courseShortNameField.setText("");
    courseShortNameField.setBorder(Styles.DEFAULT_BORDER);
    courseUnitField.setText("");
    courseUnitField.setBorder(Styles.DEFAULT_BORDER);
    courseTypeField.getModel().setSelectedItem(CourseType.REQUIRED);
    descriptionField.setText("");
    saveButton.setEnabled(false);
  }

  public void setFocus()
  {
    courseCodeField.requestFocus();
  }

  public void setForm(Course c)
  {
    this.isNew = false;
    this.pageTitle.setText(StringLocalizer.getInstance().getString("Edit_Course"));
    strongPrerequisites.setSelectedCourses(c.getStrongPrerequisites());
    altStrongPrerequisites.setSelectedCourses(c.getAltStrongPrerequisites());
    weakPrerequisites.setSelectedCourses(c.getWeakPrerequisites());
    altWeakPrerequisites.setSelectedCourses(c.getAltWeakPrerequisites());
    corequisites.setSelectedCourses(c.getCorequisites());
    altCorequisites.setSelectedCourses(c.getAltCorequisites());

    courseCodeField.setText(c.getId());
    courseCodeField.setEnabled(false);
    courseCodeField.setBorder(Styles.DEFAULT_BORDER);
    courseNameField.setText(c.getTitle());
    courseNameField.setBorder(Styles.DEFAULT_BORDER);
    courseShortNameField.setText(c.getAbbreviatedTitle());
    courseShortNameField.setBorder(Styles.DEFAULT_BORDER);
    courseUnitField.setText(c.getUnits() + "");
    courseUnitField.setBorder(Styles.DEFAULT_BORDER);
    courseTypeField.getModel().setSelectedItem(c.getCourseType());
    descriptionField.setText(c.getDescription());
    saveButton.setEnabled(true);
  }

  private JPanel addCourseList(CourseSelectionList list, String label)
  {
    JPanel row = new JPanel(new BorderLayout());
    row.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
    row.add(new JLabel(label), BorderLayout.NORTH);
    row.add(list, BorderLayout.CENTER);
    return row;
  }

  private JPanel addFormField(JComponent field, String label)
  {
    JPanel row = new JPanel();
    row.setLayout(new BoxLayout(row, BoxLayout.X_AXIS));
    row.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
    JPanel codeWrapper = new JPanel(new BorderLayout());
    codeWrapper.add(new JLabel(label), BorderLayout.NORTH);
    field.setMaximumSize(Styles.TEXT_FIELD_SIZE);
    field.setFont(Styles.DEFAULT_TEXT_FIELD_SIZE);
    codeWrapper.add(field);
    row.add(codeWrapper);
    row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 75));
    return row;
  }

  private void buildUI()
  {
    setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
    setBorder(Styles.DEFAULT_PADDING);

    JPanel titleRow = new JPanel();
    titleRow.setLayout(new BoxLayout(titleRow, BoxLayout.X_AXIS));
    pageTitle = new JLabel("", SwingConstants.LEFT);
    pageTitle.setFont(Styles.DEFAULT_HEADER_SIZE);
    pageTitle.setMaximumSize(Styles.TEXT_FIELD_SIZE);
    titleRow.add(pageTitle);
    add(titleRow);

    courseCodeField = new JTextField();
    courseCodeField.getDocument().addDocumentListener(controller);
    add(addFormField(courseCodeField,
        StringLocalizer.getInstance().getString("Course_Code_Title")));

    courseNameField = new JTextField();
    courseNameField.getDocument().addDocumentListener(controller);
    add(addFormField(courseNameField,
        StringLocalizer.getInstance().getString("Course_Name_Title")));

    courseShortNameField = new JTextField();
    courseShortNameField.getDocument().addDocumentListener(controller);
    add(addFormField(courseShortNameField,
        StringLocalizer.getInstance().getString("Course_Abrv_Name_Title")));

    courseUnitField = new JTextField();
    courseUnitField.getDocument().addDocumentListener(controller);
    add(addFormField(courseUnitField,
        StringLocalizer.getInstance().getString("Course_Unit_Title")));

    courseTypeField = new JComboBox<>();
    courseTypeField.addItem(CourseType.REQUIRED);
    courseTypeField.addItem(CourseType.ELECTIVE);
    courseTypeField.addItem(CourseType.GENERAL_EDUCATION);
    add(addFormField(courseTypeField,
        StringLocalizer.getInstance().getString("Course_Type_Title")));

    descriptionField = new JTextArea();
    descriptionField.setMaximumSize(new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));
    descriptionField.setLineWrap(true);
    descriptionField.setWrapStyleWord(true);
    descriptionField.getDocument().addDocumentListener(controller);
    JScrollPane scroll = new JScrollPane(descriptionField);
    scroll.setPreferredSize(new Dimension(1, 300));
    scroll.setMaximumSize(new Dimension(Integer.MAX_VALUE, 300));

    descriptionField.setFont(Styles.DEFAULT_TEXT_FIELD_SIZE);
    JPanel p = addFormField(scroll, StringLocalizer.getInstance().getString("Course_Description"));
    p.setMaximumSize(new Dimension(Integer.MAX_VALUE, 300));
    add(p);

    strongPrerequisites = new CourseSelectionList(controller.getService());
    altStrongPrerequisites = new CourseSelectionList(controller.getService());
    weakPrerequisites = new CourseSelectionList(controller.getService());
    altWeakPrerequisites = new CourseSelectionList(controller.getService());
    corequisites = new CourseSelectionList(controller.getService());
    altCorequisites = new CourseSelectionList(controller.getService());

    add(addCourseList(strongPrerequisites, StringLocalizer.getInstance().getString("Str_Prereq")));
    add(addCourseList(altStrongPrerequisites,
        StringLocalizer.getInstance().getString("Alt_Str_Prereq")));
    add(addCourseList(weakPrerequisites, StringLocalizer.getInstance().getString("Weak_Prereq")));
    add(addCourseList(altWeakPrerequisites,
        StringLocalizer.getInstance().getString("Alt_Weak_Prereq")));
    add(addCourseList(corequisites, StringLocalizer.getInstance().getString("Coreqs")));
    add(addCourseList(altCorequisites, StringLocalizer.getInstance().getString("Alt_Coreqs")));

    JPanel submitRow = new JPanel();
    submitRow.setLayout(new BoxLayout(submitRow, BoxLayout.X_AXIS));
    submitRow.add(Box.createHorizontalGlue());
    saveButton = new JButton(StringLocalizer.getInstance().getString("Save"));
    saveButton.setEnabled(true);
    saveButton.addActionListener(e -> {
      if (isFormValid())
        controller.save(courseCodeField.getText(), courseNameField.getText(),
            courseShortNameField.getText(), Integer.parseInt(courseUnitField.getText()),
            (CourseType) courseTypeField.getSelectedItem(), descriptionField.getText(),
            strongPrerequisites.getSelectedCourses(), altStrongPrerequisites.getSelectedCourses(),
            weakPrerequisites.getSelectedCourses(), altWeakPrerequisites.getSelectedCourses(),
            corequisites.getSelectedCourses(), altCorequisites.getSelectedCourses());
    });
    submitRow.add(saveButton);

    add(submitRow);
  }
}
