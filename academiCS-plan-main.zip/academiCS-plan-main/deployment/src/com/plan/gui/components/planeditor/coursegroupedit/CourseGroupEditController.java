package com.plan.gui.components.planeditor.coursegroupedit;

import com.plan.core.models.Course;
import com.plan.core.models.CourseGroup;
import com.plan.core.services.CourseGroupService;
import com.plan.core.services.CourseService;
import com.plan.core.uimodels.IController;
import com.plan.gui.routing.ComponentRouter;
import com.plan.gui.routing.RouteConstants;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.util.List;
import java.util.UUID;

public class CourseGroupEditController implements IController, DocumentListener
{

  private final CourseGroupService courseGroupService;
  private final CourseService courseService;
  private final ComponentRouter subRouter;

  private final CourseGroupEditView view;

  private boolean hasBeenEdited;

  public CourseGroupEditController(CourseGroupService courseGroupService,
      CourseService courseService, ComponentRouter subRouter)
  {
    this.courseGroupService = courseGroupService;
    this.courseService = courseService;
    this.subRouter = subRouter;
    this.view = new CourseGroupEditView(this);
  }

  @Override public boolean canDeactivate()
  {
    return !this.hasBeenEdited;
  }

  @Override public void changedUpdate(DocumentEvent e)
  {

  }

  public CourseService getCourseService()
  {
    return this.courseService;
  }

  @Override public JPanel getView()
  {
    return view;
  }

  @Override public void insertUpdate(DocumentEvent e)
  {
    this.hasBeenEdited = true;
    this.view.enableSave();
  }

  @Override public void onInit()
  {
    this.view.resetForm();
    if (subRouter.getActiveParams() != null && subRouter.getActiveParams().length > 0)
    {
      CourseGroup loadedGroup = this.courseGroupService.get(subRouter.getActiveParams()[0]);
      if (loadedGroup == null)
      {
        this.hasBeenEdited = false; // force route change
        this.subRouter.changeRoute(RouteConstants.COURSE_GROUP_SEARCH);
      }
      else
      {
        this.view.setForm(loadedGroup);
      }
    }
    this.hasBeenEdited = false;
    this.view.setFocus();
  }

  @Override public void removeUpdate(DocumentEvent e)
  {
    this.hasBeenEdited = true;
    this.view.enableSave();
  }

  public void save(String title, int required, List<Course> courseList)
  {
    CourseGroup courseGroup;
    if (subRouter.getActiveParams() != null && subRouter.getActiveParams().length > 0)
    {
      courseGroup = courseGroupService.get(subRouter.getActiveParams()[0]);
    }
    else
    {
      courseGroup = new CourseGroup(UUID.randomUUID().toString(), System.currentTimeMillis());
    }
    courseGroup.setTitle(title);
    courseGroup.setRequiredCourses(required);
    courseGroup.setCourses(courseList);

    this.courseGroupService.create(courseGroup);
    this.hasBeenEdited = false;
    this.subRouter.changeRoute(RouteConstants.COURSE_GROUP_SEARCH);
  }
}
