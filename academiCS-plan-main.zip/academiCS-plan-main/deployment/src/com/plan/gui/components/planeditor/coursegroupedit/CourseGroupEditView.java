package com.plan.gui.components.planeditor.coursegroupedit;

import com.plan.core.conf.StringLocalizer;
import com.plan.core.models.CourseGroup;
import com.plan.core.uimodels.AbstractView;
import com.plan.gui.components.reusuable.CourseSelectionList;
import com.plan.gui.util.FormUtil;
import com.plan.gui.util.Styles;

import javax.swing.*;
import java.awt.*;

public class CourseGroupEditView extends AbstractView<CourseGroupEditController>
{

  private JLabel pageTitle;
  private JTextField titleField;
  private JTextField requiredField;

  private JButton saveButton;

  private CourseSelectionList courseList;

  private boolean isNew;

  public CourseGroupEditView(CourseGroupEditController controller)
  {
    super(controller);
    buildUI();
  }

  public void enableSave()
  {
    saveButton.setEnabled(true);
  }

  public boolean isFormValid()
  {
    boolean b = FormUtil.isValidText(titleField, 1);
    boolean b1 = FormUtil.isValidInt(requiredField, 0, courseList.getSelectedCourses().size());

    return b && b1;
  }

  public void resetForm()
  {
    this.isNew = true;
    this.pageTitle.setText(StringLocalizer.getInstance().getString("Create_Course_Group"));

    this.courseList.reset();

    titleField.setText("");
    titleField.setBorder(Styles.DEFAULT_BORDER);

    requiredField.setBorder(Styles.DEFAULT_BORDER);
    requiredField.setText("");

    saveButton.setEnabled(false);
  }

  public void setFocus()
  {
    titleField.requestFocus();
  }

  public void setForm(CourseGroup t)
  {
    this.isNew = false;
    this.pageTitle.setText(StringLocalizer.getInstance().getString("Edit_Course_Group"));
    courseList.setSelectedCourses(t.getCourses());

    titleField.setText(t.getTitle());
    titleField.setBorder(Styles.DEFAULT_BORDER);
    requiredField.setText(t.getRequiredCourses() + "");
    requiredField.setBorder(Styles.DEFAULT_BORDER);

    saveButton.setEnabled(true);
  }

  private JPanel addCourseList(CourseSelectionList list, String label)
  {
    JPanel row = new JPanel(new BorderLayout());
    row.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
    row.add(new JLabel(label), BorderLayout.NORTH);
    row.add(list, BorderLayout.CENTER);
    return row;
  }

  private JPanel addFormField(JComponent field, String label)
  {
    JPanel row = new JPanel();
    row.setLayout(new BoxLayout(row, BoxLayout.X_AXIS));
    row.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
    JPanel codeWrapper = new JPanel(new BorderLayout());
    codeWrapper.add(new JLabel(label), BorderLayout.NORTH);
    field.setMaximumSize(Styles.TEXT_FIELD_SIZE);
    field.setFont(Styles.DEFAULT_TEXT_FIELD_SIZE);
    codeWrapper.add(field);
    row.add(codeWrapper);
    row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 75));
    return row;
  }

  private void buildUI()
  {
    setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
    setBorder(Styles.DEFAULT_PADDING);

    JPanel titleRow = new JPanel();
    titleRow.setLayout(new BoxLayout(titleRow, BoxLayout.X_AXIS));
    pageTitle = new JLabel(StringLocalizer.getInstance().getString("Edit_Course_Group"),
        SwingConstants.LEFT);
    pageTitle.setFont(Styles.DEFAULT_HEADER_SIZE);
    pageTitle.setMaximumSize(Styles.TEXT_FIELD_SIZE);
    titleRow.add(pageTitle);
    add(titleRow);

    titleField = new JTextField();
    titleField.getDocument().addDocumentListener(controller);
    add(addFormField(titleField, StringLocalizer.getInstance().getString("Course_Group_Title")));

    requiredField = new JTextField();
    requiredField.getDocument().addDocumentListener(controller);
    add(addFormField(requiredField,
        StringLocalizer.getInstance().getString("Number_Of_Required_Courses")));

    courseList = new CourseSelectionList(controller.getCourseService());
    add(addCourseList(courseList, StringLocalizer.getInstance().getString("Courses")));

    JPanel submitRow = new JPanel();
    submitRow.setLayout(new BoxLayout(submitRow, BoxLayout.X_AXIS));
    submitRow.add(Box.createHorizontalGlue());
    saveButton = new JButton(StringLocalizer.getInstance().getString("Save"));
    saveButton.setEnabled(true);
    saveButton.addActionListener(e -> {
      if (isFormValid())
        controller.save(titleField.getText(), Integer.parseInt(requiredField.getText()),
            courseList.getSelectedCourses());
    });
    submitRow.add(saveButton);

    add(submitRow);
  }
}
