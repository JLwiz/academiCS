package com.plan.gui.components.planeditor.coursegroupinfo;

import com.plan.core.models.CourseGroup;
import com.plan.core.models.auth.UserType;
import com.plan.core.services.CourseGroupService;
import com.plan.core.services.auth.AuthService;
import com.plan.core.uimodels.IController;
import com.plan.gui.routing.ComponentRouter;
import com.plan.gui.routing.RouteConstants;

import javax.swing.*;

public class CourseGroupInfoController implements IController
{
  private final AuthService authService;

  private final CourseGroupInfoView view;

  private final CourseGroupService courseGroupService;
  private final ComponentRouter subRouter;

  public CourseGroupInfoController(final AuthService authService,
      CourseGroupService courseGroupService, ComponentRouter subRouter)
  {
    this.authService = authService;
    this.view = new CourseGroupInfoView(this);
    this.courseGroupService = courseGroupService;
    this.subRouter = subRouter;
  }

  @Override public boolean canDeactivate()
  {
    return true;
  }

  public void deleteCourseGroup()
  {
    boolean delete =
        JOptionPane.showConfirmDialog(null, "Are you sure you want to delete this course group?")
            == JOptionPane.OK_OPTION;
    if (delete)
    {
      this.courseGroupService.delete(subRouter.getActiveParams()[0]);
      this.subRouter.changeRoute(RouteConstants.COURSE_GROUP_SEARCH);
    }
  }

  public void editCourseGroup()
  {
    this.subRouter.changeRoute(RouteConstants.COURSE_GROUP_EDIT, subRouter.getActiveParams());
  }

  @Override public JPanel getView()
  {
    return view;
  }

  @Override public void onInit()
  {
    if (subRouter.getActiveParams() == null || subRouter.getActiveParams().length == 0)
    {
      this.subRouter.changeRoute(RouteConstants.COURSE_GROUP_SEARCH);
      return;
    }

    CourseGroup course = courseGroupService.get(subRouter.getActiveParams()[0]);
    if (course == null)
    {
      this.subRouter.changeRoute(RouteConstants.COURSE_GROUP_SEARCH);
      return;
    }
    this.view.enableAdmin(authService.getUserType() == UserType.ADMIN);

    view.setCourseGroup(course);
  }
}
