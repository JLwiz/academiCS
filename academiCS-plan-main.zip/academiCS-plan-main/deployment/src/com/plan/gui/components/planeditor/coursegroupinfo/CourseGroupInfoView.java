package com.plan.gui.components.planeditor.coursegroupinfo;

import com.plan.core.conf.StringLocalizer;
import com.plan.core.models.Course;
import com.plan.core.models.CourseGroup;
import com.plan.core.uimodels.AbstractView;
import com.plan.gui.util.FormUtil;
import com.plan.gui.util.Styles;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.Vector;
import java.util.stream.Collectors;

public class CourseGroupInfoView extends AbstractView<CourseGroupInfoController>
{

  private JLabel idLabel;
  private JLabel createdTimeLabel;
  private JLabel titleLabel;
  private JLabel requiredLabel;

  private JList<String> courseList;

  private JButton editButton;
  private JButton deleteButton;

  public CourseGroupInfoView(CourseGroupInfoController controller)
  {
    super(controller);
    buildUI();
  }

  public void enableAdmin(final boolean isAdmin)
  {
    this.editButton.setVisible(isAdmin);
    this.deleteButton.setVisible(isAdmin);
  }

  public void setCourseGroup(CourseGroup group)
  {
    idLabel.setText(group.getId());
    createdTimeLabel.setText(FormUtil.getDateString(group.getCreatedDate()));

    titleLabel.setText(group.getTitle());
    requiredLabel.setText(group.getRequiredCourses() + "");

    courseList.setListData(listToVector(group.getCourses()));
  }

  private void buildUI()
  {
    setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
    setBorder(Styles.DEFAULT_PADDING);

    JPanel titleRow = new JPanel();
    titleRow.setLayout(new BoxLayout(titleRow, BoxLayout.X_AXIS));
    JLabel title = new JLabel(StringLocalizer.getInstance().getString("Course_Group_Information"),
        SwingConstants.LEFT);
    title.setFont(Styles.DEFAULT_HEADER_SIZE);
    title.setMaximumSize(Styles.TEXT_FIELD_SIZE);
    titleRow.add(title);
    titleRow.add(Box.createHorizontalGlue());
    editButton = new JButton(StringLocalizer.getInstance().getString("Edit"));
    editButton.addActionListener(e -> controller.editCourseGroup());
    deleteButton = new JButton(StringLocalizer.getInstance().getString("Delete"));
    deleteButton.addActionListener(e -> controller.deleteCourseGroup());

    setMaximumSize(new Dimension(3, 1));
    titleRow.add(editButton);
    titleRow.add(deleteButton);

    add(titleRow);

    idLabel = new JLabel("", SwingConstants.LEFT);
    add(getRow(idLabel, StringLocalizer.getInstance().getString("Course_Group_ID")));

    createdTimeLabel = new JLabel("", SwingConstants.LEFT);
    add(getRow(createdTimeLabel,
        StringLocalizer.getInstance().getString("Course_Group_Created_Time")));

    titleLabel = new JLabel("", SwingConstants.LEFT);
    add(getRow(titleLabel, StringLocalizer.getInstance().getString("Course_Group_Title")));

    requiredLabel = new JLabel("", SwingConstants.LEFT);
    add(getRow(requiredLabel, StringLocalizer.getInstance().getString("Required_From_Group")));

    courseList = new JList<>();
    add(getListRow(courseList, "Courses in Group"));

  }

  private JPanel getListRow(JList<String> list, String title)
  {
    JPanel row = new JPanel();
    row.setLayout(new BoxLayout(row, BoxLayout.X_AXIS));
    row.setBorder(BorderFactory.createTitledBorder(Styles.DEFAULT_BORDER, title));
    JScrollPane scrollPane = new JScrollPane(list);
    scrollPane.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
    row.add(scrollPane);
    return row;
  }

  private JPanel getRow(JComponent label, String title)
  {
    JPanel row = new JPanel();
    row.setLayout(new BoxLayout(row, BoxLayout.X_AXIS));
    row.setBorder(BorderFactory.createTitledBorder(Styles.DEFAULT_BORDER, title));
    label.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
    row.add(label);
    return row;
  }

  private Vector<String> listToVector(List<Course> courseList)
  {
    if (courseList == null)
      return new Vector<>();
    return courseList.stream().map(c -> c.getAbbreviatedTitle() + ": " + c.getTitle())
        .collect(Collectors.toCollection(Vector::new));
  }
}
