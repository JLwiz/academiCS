package com.plan.gui.components.planeditor.coursegroupsearch;

import com.plan.core.services.CourseGroupService;
import com.plan.core.uimodels.IController;
import com.plan.gui.routing.ComponentRouter;
import com.plan.gui.routing.RouteConstants;

import javax.swing.*;
import java.util.stream.Collectors;

public class CourseGroupSearchController implements IController
{

  private final CourseGroupSearchView view;

  private final CourseGroupService courseGroupService;
  private final ComponentRouter subRouter;

  public CourseGroupSearchController(CourseGroupService courseGroupService,
      ComponentRouter subRouter)
  {
    this.courseGroupService = courseGroupService;
    this.subRouter = subRouter;
    this.view = new CourseGroupSearchView(this);
  }

  @Override public JPanel getView()
  {
    return view;
  }

  @Override public void onInit()
  {
    view.setTable(courseGroupService.getAll());
    view.setFocus();
  }

  public void search(String title)
  {
    view.setTable(courseGroupService.getAll().stream()
        .filter(t -> t.getTitle().toLowerCase().contains(title.toLowerCase()))
        .collect(Collectors.toList()));
  }

  public void select(String id)
  {
    this.subRouter.changeRoute(RouteConstants.COURSE_GROUP_VIEW, id);
  }
}
