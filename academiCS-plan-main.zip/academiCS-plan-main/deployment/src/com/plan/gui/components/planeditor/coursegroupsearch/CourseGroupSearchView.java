package com.plan.gui.components.planeditor.coursegroupsearch;

import com.plan.core.conf.StringLocalizer;
import com.plan.core.models.CourseGroup;
import com.plan.core.uimodels.AbstractView;
import com.plan.gui.util.Styles;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.Collection;
import java.util.Vector;

public class CourseGroupSearchView extends AbstractView<CourseGroupSearchController>
{

  private JTextField courseGroupTitleField;
  private JTable searchTable;

  public CourseGroupSearchView(CourseGroupSearchController controller)
  {
    super(controller);
    buildUI();
  }

  public void setFocus()
  {
    courseGroupTitleField.requestFocus();
  }

  public void setTable(Collection<CourseGroup> courseGroups)
  {
    Vector<String> headers = new Vector<>();
    headers.add(StringLocalizer.getInstance().getString("Course_Group_ID"));
    headers.add(StringLocalizer.getInstance().getString("Course_Group_Title"));
    headers.add(StringLocalizer.getInstance().getString("Course_Group_Number_of_Courses"));
    headers.add(StringLocalizer.getInstance().getString("Course_Group_Required_Courses"));

    Vector<Vector<String>> data = new Vector<>();
    for (CourseGroup group : courseGroups)
    {
      Vector<String> d = new Vector<>();
      d.add(group.getId());
      d.add(group.getTitle());
      d.add(group.getCourses().size() + "");
      d.add(group.getRequiredCourses() + "");
      data.add(d);
    }
    DefaultTableModel model = new DefaultTableModel(data, headers);
    searchTable.setModel(model);

  }

  private void buildUI()
  {
    setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
    setBorder(Styles.DEFAULT_PADDING);

    JPanel titleRow = new JPanel();
    titleRow.setLayout(new BoxLayout(titleRow, BoxLayout.X_AXIS));
    JLabel title = new JLabel(StringLocalizer.getInstance().getString("Course_Group_Search"),
        SwingConstants.LEFT);
    title.setFont(Styles.DEFAULT_HEADER_SIZE);
    title.setMaximumSize(Styles.TEXT_FIELD_SIZE);
    titleRow.add(title);
    add(titleRow);

    JPanel rowOne = new JPanel();
    rowOne.setLayout(new BoxLayout(rowOne, BoxLayout.X_AXIS));
    rowOne.setBorder(BorderFactory.createEmptyBorder(5, 0, 20, 0));

    JPanel termTitleWrapper = new JPanel(new BorderLayout());
    termTitleWrapper.add(new JLabel(StringLocalizer.getInstance().getString("Course_Group_Name")),
        BorderLayout.NORTH);
    courseGroupTitleField = new JTextField();
    courseGroupTitleField
        .addActionListener(e -> controller.search(courseGroupTitleField.getText()));
    courseGroupTitleField.setMaximumSize(Styles.TEXT_FIELD_SIZE);
    courseGroupTitleField.setFont(Styles.DEFAULT_TEXT_FIELD_SIZE);
    termTitleWrapper.add(courseGroupTitleField);
    rowOne.add(termTitleWrapper);
    rowOne.setMaximumSize(new Dimension(Integer.MAX_VALUE, 300));
    add(rowOne);

    searchTable = new JTable()
    {
      @Override public boolean isCellEditable(int rowIndex, int colIndex)
      {
        return false; //Disallow the editing of any cell
      }
    };
    searchTable.getTableHeader().setReorderingAllowed(false);
    searchTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    searchTable.getSelectionModel().addListSelectionListener(l -> {
      if (!l.getValueIsAdjusting() && searchTable.getSelectedRow() >= 0)
      {
        controller.select(searchTable.getValueAt(searchTable.getSelectedRow(), 0).toString());
        searchTable.clearSelection();
      }
    });
    add(new JScrollPane(searchTable));
  }

}
