package com.plan.gui.components.planeditor.courseinfo;

import com.plan.core.models.Course;
import com.plan.core.models.auth.UserType;
import com.plan.core.services.CourseService;
import com.plan.core.services.auth.AuthService;
import com.plan.core.uimodels.IController;
import com.plan.gui.routing.ComponentRouter;
import com.plan.gui.routing.RouteConstants;

import javax.swing.*;
import java.util.Locale;
import java.util.ResourceBundle;

public class CourseInfoController implements IController
{

  private final AuthService authService;

  private final CourseService service;
  private final ComponentRouter router;

  private final CourseInfoView view;

  protected ResourceBundle strings =
      ResourceBundle.getBundle("Strings", Locale.getDefault(), this.getClass().getClassLoader());

  public CourseInfoController(final AuthService authService, CourseService service,
      ComponentRouter router)
  {
    this.authService = authService;
    view = new CourseInfoView(this);
    this.service = service;
    this.router = router;
  }

  @Override public boolean canDeactivate()
  {
    return true;
  }

  public void deleteCourse()
  {
    boolean delete =
        JOptionPane.showConfirmDialog(null, strings.getString("Delete_Course_Confirmation_Dialog"))
            == JOptionPane.OK_OPTION;
    if (delete)
    {
      this.service.delete(router.getActiveParams()[0]);
      this.router.changeRoute(RouteConstants.COURSE_SEARCH);
    }
  }

  public void editCourse()
  {
    this.router.changeRoute(RouteConstants.COURSE_EDIT, router.getActiveParams());
  }

  @Override public JPanel getView()
  {
    return this.view;
  }

  @Override public void onInit()
  {
    if (router.getActiveParams() == null || router.getActiveParams().length == 0)
    {
      this.router.changeRoute(RouteConstants.COURSE_SEARCH);
      return;
    }

    Course course = service.get(router.getActiveParams()[0]);
    if (course == null)
    {
      this.router.changeRoute(RouteConstants.COURSE_SEARCH);
      return;
    }
    this.view.enableAdmin(authService.getUserType() == UserType.ADMIN);

    view.setCourse(course);
  }
}
