package com.plan.gui.components.planeditor.courseinfo;

import com.plan.core.conf.StringLocalizer;
import com.plan.core.models.Course;
import com.plan.core.uimodels.AbstractView;
import com.plan.gui.util.Styles;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.Vector;
import java.util.stream.Collectors;

public class CourseInfoView extends AbstractView<CourseInfoController>
{

  private JLabel courseCodeLabel;
  private JLabel titleLabel;
  private JLabel shortTitleLabel;
  private JLabel courseTypeLabel;
  private JLabel unitLabel;
  private JTextArea descriptionLabel;

  private JList<String> sp;
  private JList<String> asp;
  private JList<String> wp;
  private JList<String> awp;
  private JList<String> co;
  private JList<String> aco;

  private JButton editButton;
  private JButton deleteButton;

  public CourseInfoView(CourseInfoController controller)
  {
    super(controller);
    buildUI();
  }

  public void enableAdmin(final boolean isAdmin)
  {
    this.editButton.setVisible(isAdmin);
    this.deleteButton.setVisible(isAdmin);
  }

  public void setCourse(Course course)
  {
    courseCodeLabel.setText(course.getId());
    titleLabel.setText(course.getTitle());
    shortTitleLabel.setText(course.getAbbreviatedTitle());
    courseTypeLabel.setText(course.getCourseType().toString());
    unitLabel.setText("" + course.getUnits());
    descriptionLabel.setText((course.getDescription() == null) ? StringLocalizer
        .getInstance()
        .getString("No_description") : course.getDescription());

    sp.setListData(listToVector(course.getStrongPrerequisites()));
    asp.setListData(listToVector(course.getAltStrongPrerequisites()));
    wp.setListData(listToVector(course.getWeakPrerequisites()));
    awp.setListData(listToVector(course.getAltWeakPrerequisites()));
    co.setListData(listToVector(course.getCorequisites()));
    aco.setListData(listToVector(course.getAltCorequisites()));
  }

  private void buildUI()
  {
    setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
    setBorder(Styles.DEFAULT_PADDING);

    JPanel titleRow = new JPanel();
    titleRow.setLayout(new BoxLayout(titleRow, BoxLayout.X_AXIS));
    JLabel title = new JLabel("Course Information", SwingConstants.LEFT);
    title.setFont(Styles.DEFAULT_HEADER_SIZE);
    title.setMaximumSize(Styles.TEXT_FIELD_SIZE);
    titleRow.add(title);
    titleRow.add(Box.createHorizontalGlue());
    editButton = new JButton(StringLocalizer.getInstance().getString("Edit"));
    editButton.addActionListener(e -> controller.editCourse());
    deleteButton = new JButton(StringLocalizer.getInstance().getString("Delete"));
    deleteButton.addActionListener(e -> controller.deleteCourse());
    setMaximumSize(new Dimension(3, 1));
    titleRow.add(editButton);
    titleRow.add(deleteButton);

    add(titleRow);

    courseCodeLabel = new JLabel("", SwingConstants.LEFT);
    add(getRow(courseCodeLabel, StringLocalizer.getInstance().getString("Course_Code")));

    titleLabel = new JLabel("", SwingConstants.LEFT);
    add(getRow(titleLabel, StringLocalizer.getInstance().getString("Course_Name")));

    shortTitleLabel = new JLabel("", SwingConstants.LEFT);
    add(getRow(shortTitleLabel,
        StringLocalizer.getInstance().getString("Course_Abbreviated_Name")));

    courseTypeLabel = new JLabel("", SwingConstants.LEFT);
    add(getRow(courseTypeLabel, StringLocalizer.getInstance().getString("Course_Type")));

    unitLabel = new JLabel("", SwingConstants.LEFT);
    add(getRow(unitLabel, StringLocalizer.getInstance().getString("Course_Units")));

    descriptionLabel = new JTextArea();
    descriptionLabel.setEditable(false);
    descriptionLabel.setLineWrap(true);
    descriptionLabel.setWrapStyleWord(true);
    descriptionLabel.setMaximumSize(new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));
    JScrollPane scrollPane = new JScrollPane(descriptionLabel);
    add(getRow(scrollPane, StringLocalizer.getInstance().getString("Course_Description")));
    scrollPane.setMaximumSize(new Dimension(Integer.MAX_VALUE, 100));

    sp = new JList<>();
    add(getListRow(sp, StringLocalizer.getInstance().getString("Str_Prereq")));

    asp = new JList<>();
    add(getListRow(asp, StringLocalizer.getInstance().getString("Alt_Str_Prereq")));

    wp = new JList<>();
    add(getListRow(wp, StringLocalizer.getInstance().getString("Weak_Prereq")));

    awp = new JList<>();
    add(getListRow(awp, StringLocalizer.getInstance().getString("Alt_Weak_Prereq")));

    co = new JList<>();
    add(getListRow(co, StringLocalizer.getInstance().getString("Coreqs")));

    aco = new JList<>();
    add(getListRow(aco, StringLocalizer.getInstance().getString("Alt_Coreqs")));
  }

  private JPanel getListRow(JList<String> list, String title)
  {
    JPanel row = new JPanel();
    row.setLayout(new BoxLayout(row, BoxLayout.X_AXIS));
    row.setBorder(BorderFactory.createTitledBorder(Styles.DEFAULT_BORDER, title));
    JScrollPane scrollPane = new JScrollPane(list);
    scrollPane.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
    row.add(scrollPane);
    return row;
  }

  private JPanel getRow(JComponent label, String title)
  {
    JPanel row = new JPanel();
    row.setLayout(new BoxLayout(row, BoxLayout.X_AXIS));
    row.setBorder(BorderFactory.createTitledBorder(Styles.DEFAULT_BORDER, title));
    label.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
    row.add(label);
    return row;
  }

  private Vector<String> listToVector(List<Course> courseList)
  {
    if (courseList == null)
      return new Vector<>();
    return courseList.stream().map(c -> c.getAbbreviatedTitle() + ": " + c.getTitle())
        .collect(Collectors.toCollection(Vector::new));
  }
}
