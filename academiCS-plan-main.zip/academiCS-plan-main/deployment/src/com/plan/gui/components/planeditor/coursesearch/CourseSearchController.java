package com.plan.gui.components.planeditor.coursesearch;

import com.plan.core.services.CourseService;
import com.plan.core.uimodels.IController;
import com.plan.gui.routing.ComponentRouter;
import com.plan.gui.routing.RouteConstants;

import javax.swing.*;
import java.util.stream.Collectors;

public class CourseSearchController implements IController
{

  private final ComponentRouter router;
  private final CourseSearchView view;
  private final CourseService service;

  public CourseSearchController(CourseService service, ComponentRouter router)
  {
    this.router = router;
    this.view = new CourseSearchView(this);
    this.service = service;
  }

  @Override public boolean canDeactivate()
  {
    return true;
  }

  @Override public JPanel getView()
  {
    return view;
  }

  @Override public void onInit()
  {
    view.setTable(service.getAll());
    view.setFocus();
  }

  public void search(String name, String shortName, String code)
  {
    view.setTable(service.getAll().stream().filter(
        c -> c.getTitle().toLowerCase().contains(name.toLowerCase()) && c.getAbbreviatedTitle()
            .toLowerCase().contains(shortName.toLowerCase()) && c.getId().toLowerCase()
            .contains(code.toLowerCase())).collect(Collectors.toList()));
  }

  public void select(String id)
  {
    this.router.changeRoute(RouteConstants.COURSE_VIEW, id);
  }
}
