package com.plan.gui.components.planeditor.coursesearch;

import com.plan.core.conf.StringLocalizer;
import com.plan.core.models.Course;
import com.plan.core.uimodels.AbstractView;
import com.plan.gui.util.Styles;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.Collection;
import java.util.Vector;

public class CourseSearchView extends AbstractView<CourseSearchController>
{

  private JTextField nameField;
  private JTextField shortNameField;
  private JTextField codeField;

  private JTable searchTable;

  public CourseSearchView(CourseSearchController controller)
  {
    super(controller);
    buildUI();
  }

  public void setFocus()
  {
    shortNameField.requestFocus();
  }

  public void setTable(Collection<Course> courses)
  {
    Vector<String> headers = new Vector<>();
    headers.add(StringLocalizer.getInstance().getString("Course_Code"));
    headers.add(StringLocalizer.getInstance().getString("Course_Name"));
    headers.add(StringLocalizer.getInstance().getString("Course_Abbreviated_Name"));
    headers.add(StringLocalizer.getInstance().getString("Course_Type"));

    Vector<Vector<String>> data = new Vector<>();
    for (Course c : courses)
    {
      Vector<String> d = new Vector<>();
      d.add(c.getId());
      d.add(c.getTitle());
      d.add(c.getAbbreviatedTitle());
      d.add(c.getCourseType().toString());
      data.add(d);
    }
    DefaultTableModel model = new DefaultTableModel(data, headers);
    searchTable.setModel(model);

  }

  private void buildUI()
  {
    setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
    setBorder(Styles.DEFAULT_PADDING);

    JPanel titleRow = new JPanel();
    titleRow.setLayout(new BoxLayout(titleRow, BoxLayout.X_AXIS));
    JLabel title =
        new JLabel(StringLocalizer.getInstance().getString("Course_Search"), SwingConstants.LEFT);
    title.setFont(Styles.DEFAULT_HEADER_SIZE);
    title.setMaximumSize(Styles.TEXT_FIELD_SIZE);
    titleRow.add(title);
    add(titleRow);

    JPanel firstRow = new JPanel();
    firstRow.setLayout(new BoxLayout(firstRow, BoxLayout.X_AXIS));
    firstRow.setBorder(BorderFactory.createEmptyBorder(5, 0, 5, 0));

    JPanel shortNameWrapper = new JPanel(new BorderLayout());
    shortNameWrapper.add(new JLabel(StringLocalizer.getInstance().getString("Abbreviated_Name")),
        BorderLayout.NORTH);
    shortNameField = new JTextField();
    shortNameField.addActionListener(
        e -> controller.search(nameField.getText(), shortNameField.getText(), codeField.getText()));
    shortNameField.setMaximumSize(Styles.TEXT_FIELD_SIZE);
    shortNameField.setFont(Styles.DEFAULT_TEXT_FIELD_SIZE);
    shortNameWrapper.add(shortNameField, BorderLayout.CENTER);
    firstRow.add(shortNameWrapper);

    JPanel nameWrapper = new JPanel(new BorderLayout());
    nameWrapper.add(new JLabel(StringLocalizer.getInstance().getString("Course_Name")),
        BorderLayout.NORTH);
    nameField = new JTextField();
    nameField.addActionListener(
        e -> controller.search(nameField.getText(), shortNameField.getText(), codeField.getText()));
    nameField.setMaximumSize(Styles.TEXT_FIELD_SIZE);
    nameField.setFont(Styles.DEFAULT_TEXT_FIELD_SIZE);
    nameWrapper.add(nameField, BorderLayout.CENTER);
    firstRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 300));
    firstRow.add(nameWrapper);
    add(firstRow);

    JPanel secondRow = new JPanel();
    secondRow.setLayout(new BoxLayout(secondRow, BoxLayout.X_AXIS));
    secondRow.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));

    JPanel codeWrapper = new JPanel(new BorderLayout());
    codeWrapper.add(new JLabel(StringLocalizer.getInstance().getString("Course_Code")),
        BorderLayout.NORTH);
    codeField = new JTextField();
    codeField.addActionListener(
        e -> controller.search(nameField.getText(), shortNameField.getText(), codeField.getText()));
    codeField.setMaximumSize(Styles.TEXT_FIELD_SIZE);
    codeField.setFont(Styles.DEFAULT_TEXT_FIELD_SIZE);
    codeWrapper.add(codeField);
    secondRow.add(codeWrapper);
    secondRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 300));
    add(secondRow);

    searchTable = new JTable()
    {
      @Override public boolean isCellEditable(int rowIndex, int colIndex)
      {
        return false; //Disallow the editing of any cell
      }
    };
    searchTable.getTableHeader().setReorderingAllowed(false);
    searchTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    searchTable.getSelectionModel().addListSelectionListener(l -> {
      if (!l.getValueIsAdjusting() && searchTable.getSelectedRow() >= 0)
      {

        controller.select(searchTable.getValueAt(searchTable.getSelectedRow(), 0).toString());
        searchTable.clearSelection();
      }
    });
    add(new JScrollPane(searchTable));
  }
}
