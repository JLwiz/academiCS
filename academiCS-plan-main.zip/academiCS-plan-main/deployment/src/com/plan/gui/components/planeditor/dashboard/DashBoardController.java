package com.plan.gui.components.planeditor.dashboard;

import com.plan.core.models.auth.UserType;
import com.plan.core.services.CourseGroupService;
import com.plan.core.services.CourseService;
import com.plan.core.services.FieldOfStudyService;
import com.plan.core.services.TermService;
import com.plan.core.services.auth.AuthService;
import com.plan.core.uimodels.IController;
import com.plan.gui.routing.ComponentRouter;

import javax.swing.*;

public class DashBoardController implements IController
{

  private final DashboardView view;

  private final AuthService authService;

  private final CourseService courseService;
  private final TermService termService;
  private final CourseGroupService courseGroupService;
  private final FieldOfStudyService fieldOfStudyService;

  private final ComponentRouter router;

  public DashBoardController(final AuthService authService, final TermService termService,
      final CourseService courseService, final CourseGroupService courseGroupService,
      final FieldOfStudyService fieldOfStudyService, final ComponentRouter router)
  {
    this.authService = authService;
    this.termService = termService;
    this.courseService = courseService;
    this.courseGroupService = courseGroupService;
    this.fieldOfStudyService = fieldOfStudyService;
    this.view = new DashboardView(this);
    this.router = router;
  }

  public void buttonRoute(String type, String route)
  {
    var tempRoute = route;
    if (tempRoute.equals("field-of-studie"))
    {
      tempRoute = "study";
    }
    router.changeRoute(tempRoute + "-" + type);
  }

  @Override public boolean canDeactivate()
  {
    return true;
  }

  @Override public JPanel getView()
  {
    return this.view;
  }

  public void loadCounts()
  {
    this.view.setCounts(courseService.getAll().size(), termService.getAll().size(),
        courseGroupService.getAll().size(), fieldOfStudyService.getAll().size());
  }

  @Override public void onInit()
  {
    this.view.enableAdmin(this.authService.getUserType() == UserType.ADMIN);
    loadCounts();
  }
}
