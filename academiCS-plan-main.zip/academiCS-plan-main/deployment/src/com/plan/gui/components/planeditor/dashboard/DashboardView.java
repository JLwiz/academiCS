package com.plan.gui.components.planeditor.dashboard;

import com.plan.core.conf.StringLocalizer;
import com.plan.core.uimodels.AbstractView;
import com.plan.gui.util.Styles;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.util.ArrayList;

public class DashboardView extends AbstractView<DashBoardController>
{

  private static final Border CARD_PADDING = BorderFactory.createEmptyBorder(0, 50, 0, 50);
  private static final Dimension CARD_SIZE = new Dimension(350, 200);

  private final JLabel courseCount;
  private final JLabel termCount;
  private final JLabel courseGroupCount;
  private final JLabel fieldOfStudyCount;

  private final java.util.List<JButton> adminButtons;

  public DashboardView(final DashBoardController controller)
  {
    super(controller);
    this.adminButtons = new ArrayList<>();
    setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
    setBorder(Styles.DEFAULT_PADDING);
    JPanel titleRow = new JPanel();
    titleRow.setLayout(new BoxLayout(titleRow, BoxLayout.X_AXIS));
    JLabel title = new JLabel(StringLocalizer.getInstance().getString("Planning Dashboard"),
        SwingConstants.LEFT);
    title.setFont(Styles.DEFAULT_HEADER_SIZE);
    title.setMaximumSize(Styles.TEXT_FIELD_SIZE);
    titleRow.add(title);
    add(titleRow);

    JPanel info = new JPanel();
    info.setBorder(Styles.DEFAULT_PADDING);

    courseCount = createCard(info, "Courses", Color.WHITE);
    termCount = createCard(info, "Terms", Color.WHITE);
    courseGroupCount = createCard(info, "Course groups", Color.WHITE);
    fieldOfStudyCount = createCard(info, "Field of studies", Color.WHITE);
    add(info);
  }

  public void enableAdmin(final boolean isAdmin)
  {
    this.adminButtons.forEach(b -> b.setVisible(isAdmin));
  }

  public void setCounts(int courses, int terms, int courseGroups, int fieldsOfStudy)
  {
    this.courseCount.setText(courses + "");
    this.termCount.setText(terms + "");
    this.courseGroupCount.setText(courseGroups + "");
    this.fieldOfStudyCount.setText(fieldsOfStudy + "");
  }

  private JLabel createCard(final JPanel parent, final String txt, Color color)
  {
    JPanel card = new JPanel();
    card.setLayout(new GridLayout(3, 0));

    card.setAlignmentX(CENTER_ALIGNMENT);
    card.setAlignmentY(CENTER_ALIGNMENT);

    card.setBorder(CARD_PADDING);
    card.setBackground(color);
    card.setMinimumSize(CARD_SIZE);
    card.setPreferredSize(CARD_SIZE);
    JLabel count = new JLabel("0", SwingConstants.CENTER);
    count.setFont(Styles.DEFAULT_HEADER_SIZE);
    count.setBackground(Color.red);
    card.add(count);
    JLabel label = new JLabel(txt + " loaded", SwingConstants.CENTER);
    label.setFont(Styles.PAGE_FONT);

    card.add(label);
    card.add(createCardButtons(txt));
    parent.add(card);
    return count;
  }

  private JPanel createCardButtons(final String txt)
  {
    JPanel buttons = new JPanel();
    buttons.setLayout(new GridLayout(2, 0));
    buttons.setAlignmentX(CENTER_ALIGNMENT);
    buttons.setAlignmentY(CENTER_ALIGNMENT);

    JButton editButton = new JButton("Create " + txt);
    JButton searchButton = new JButton("Search " + txt);

    editButton.addActionListener(e -> controller.buttonRoute("edit",
        txt.toLowerCase().replaceAll(" ", "-").substring(0, txt.length() - 1)));
    searchButton.addActionListener(e -> controller.buttonRoute("search",
        txt.toLowerCase().replaceAll(" ", "-").substring(0, txt.length() - 1)));

    buttons.add(searchButton);
    buttons.add(editButton);

    this.adminButtons.add(editButton);
    return buttons;
  }
}
