package com.plan.gui.components.planeditor.fieldofstudyedit;

import com.plan.core.models.CourseGroup;
import com.plan.core.models.FieldOfStudy;
import com.plan.core.models.StudyType;
import com.plan.core.services.CourseGroupService;
import com.plan.core.services.FieldOfStudyService;
import com.plan.core.uimodels.IController;
import com.plan.gui.routing.ComponentRouter;
import com.plan.gui.routing.RouteConstants;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.util.List;
import java.util.UUID;

public class FieldOfStudyEditController implements IController, DocumentListener
{

  private final FieldOfStudyService fieldOfStudyService;
  private final CourseGroupService courseGroupService;
  private final ComponentRouter subRouter;

  private final FieldOfStudyEditView view;

  private boolean hasBeenEdited;

  public FieldOfStudyEditController(FieldOfStudyService fieldOfStudyService,
      CourseGroupService courseGroupService, ComponentRouter subRouter)
  {
    this.fieldOfStudyService = fieldOfStudyService;
    this.courseGroupService = courseGroupService;
    this.subRouter = subRouter;

    this.view = new FieldOfStudyEditView(this);
  }

  @Override public boolean canDeactivate()
  {
    return !this.hasBeenEdited;
  }

  @Override public void changedUpdate(DocumentEvent e)
  {

  }

  public CourseGroupService getCourseGroupService()
  {
    return this.courseGroupService;
  }

  @Override public JPanel getView()
  {
    return view;
  }

  @Override public void insertUpdate(DocumentEvent e)
  {
    this.hasBeenEdited = true;
    this.view.enableSave();
  }

  @Override public void onInit()
  {
    this.view.resetForm();
    if (subRouter.getActiveParams() != null && subRouter.getActiveParams().length > 0)
    {
      FieldOfStudy loadedFOS = this.fieldOfStudyService.get(subRouter.getActiveParams()[0]);
      if (loadedFOS == null)
      {
        this.hasBeenEdited = false; // force route change
        this.subRouter.changeRoute(RouteConstants.STUDY_SEARCH);
      }
      else
      {
        this.view.setForm(loadedFOS);
      }
    }
    this.hasBeenEdited = false;
    this.view.setFocus();
  }

  @Override public void removeUpdate(DocumentEvent e)
  {
    this.hasBeenEdited = true;
    this.view.enableSave();
  }

  public void save(String title, StudyType studyType, List<CourseGroup> courseGroups)
  {
    FieldOfStudy fos;
    if (subRouter.getActiveParams() != null && subRouter.getActiveParams().length > 0)
    {
      fos = fieldOfStudyService.get(subRouter.getActiveParams()[0]);
    }
    else
    {
      fos = new FieldOfStudy(UUID.randomUUID().toString(), System.currentTimeMillis());
    }
    fos.setName(title);
    fos.setStudyType(studyType);
    fos.setCourseGroups(courseGroups);

    this.fieldOfStudyService.create(fos);
    this.hasBeenEdited = false;
    this.subRouter.changeRoute(RouteConstants.STUDY_SEARCH);
  }
}
