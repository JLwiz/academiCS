package com.plan.gui.components.planeditor.fieldofstudyedit;

import com.plan.core.conf.StringLocalizer;
import com.plan.core.models.FieldOfStudy;
import com.plan.core.models.StudyType;
import com.plan.core.uimodels.AbstractView;
import com.plan.gui.components.reusuable.CourseGroupSelectionList;
import com.plan.gui.util.FormUtil;
import com.plan.gui.util.Styles;

import javax.swing.*;
import java.awt.*;

public class FieldOfStudyEditView extends AbstractView<FieldOfStudyEditController>
{

  private JLabel pageTitle;
  private JTextField fosTitleField;
  private JComboBox<StudyType> fosTypeField;

  private CourseGroupSelectionList courseGroups;

  private JButton saveButton;

  private boolean isNew;

  public FieldOfStudyEditView(FieldOfStudyEditController controller)
  {
    super(controller);
    buildUI();
  }

  public void enableSave()
  {
    saveButton.setEnabled(true);
  }

  public boolean isFormValid()
  {
    return FormUtil.isValidText(fosTitleField, 1);
  }

  public void resetForm()
  {
    this.isNew = true;
    this.pageTitle.setText(StringLocalizer.getInstance().getString("Create_Field_Of_Study"));

    this.courseGroups.reset();

    fosTitleField.setText("");
    fosTitleField.setBorder(Styles.DEFAULT_BORDER);
    fosTypeField.getModel().setSelectedItem(StudyType.MAJOR);

    saveButton.setEnabled(false);
  }

  public void setFocus()
  {
    fosTitleField.requestFocus();
  }

  public void setForm(FieldOfStudy t)
  {
    this.isNew = false;
    this.pageTitle.setText(StringLocalizer.getInstance().getString("Edit_Field_Of_Study"));
    courseGroups.setSelectedCourses(t.getCourseGroups());

    fosTitleField.setText(t.getName());
    fosTypeField.setBorder(Styles.DEFAULT_BORDER);
    fosTypeField.getModel().setSelectedItem(t.getStudyType());

    saveButton.setEnabled(true);
  }

  private JPanel addCourseList(CourseGroupSelectionList list)
  {
    JPanel row = new JPanel(new BorderLayout());
    row.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
    row.add(new JLabel(StringLocalizer.getInstance().getString("Course_Groups")),
        BorderLayout.NORTH);
    row.add(list, BorderLayout.CENTER);
    return row;
  }

  private JPanel addFormField(JComponent field, String label)
  {
    JPanel row = new JPanel();
    row.setLayout(new BoxLayout(row, BoxLayout.X_AXIS));
    row.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
    JPanel codeWrapper = new JPanel(new BorderLayout());
    codeWrapper.add(new JLabel(label), BorderLayout.NORTH);
    field.setMaximumSize(Styles.TEXT_FIELD_SIZE);
    field.setFont(Styles.DEFAULT_TEXT_FIELD_SIZE);
    codeWrapper.add(field);
    row.add(codeWrapper);
    row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 75));
    return row;
  }

  private void buildUI()
  {
    setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
    setBorder(Styles.DEFAULT_PADDING);

    JPanel titleRow = new JPanel();
    titleRow.setLayout(new BoxLayout(titleRow, BoxLayout.X_AXIS));
    pageTitle = new JLabel(StringLocalizer.getInstance().getString("Edit_Field_Of_Study"),
        SwingConstants.LEFT);
    pageTitle.setFont(Styles.DEFAULT_HEADER_SIZE);
    pageTitle.setMaximumSize(Styles.TEXT_FIELD_SIZE);
    titleRow.add(pageTitle);
    add(titleRow);

    fosTitleField = new JTextField();
    fosTitleField.getDocument().addDocumentListener(controller);
    add(addFormField(fosTitleField,
        StringLocalizer.getInstance().getString("Field_Of_Study_Name")));

    fosTypeField = new JComboBox<>();
    fosTypeField.addItem(StudyType.MAJOR);
    fosTypeField.addItem(StudyType.MINOR);
    fosTypeField.addItem(StudyType.OTHER);
    add(addFormField(fosTypeField, StringLocalizer.getInstance().getString("Field_Of_Study_Type")));

    courseGroups = new CourseGroupSelectionList(controller.getCourseGroupService());

    add(addCourseList(courseGroups));

    JPanel submitRow = new JPanel();
    submitRow.setLayout(new BoxLayout(submitRow, BoxLayout.X_AXIS));
    submitRow.add(Box.createHorizontalGlue());
    saveButton = new JButton(StringLocalizer.getInstance().getString("Save"));
    saveButton.setEnabled(true);
    saveButton.addActionListener(e -> {
      if (isFormValid())
        controller.save(fosTitleField.getText(), (StudyType) fosTypeField.getSelectedItem(),
            courseGroups.getSelectedCourses());
    });
    submitRow.add(saveButton);

    add(submitRow);
  }
}
