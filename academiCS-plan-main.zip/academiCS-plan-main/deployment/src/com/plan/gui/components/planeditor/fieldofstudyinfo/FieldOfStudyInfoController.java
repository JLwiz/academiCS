package com.plan.gui.components.planeditor.fieldofstudyinfo;

import com.plan.core.models.FieldOfStudy;
import com.plan.core.models.auth.UserType;
import com.plan.core.services.FieldOfStudyService;
import com.plan.core.services.auth.AuthService;
import com.plan.core.uimodels.IController;
import com.plan.gui.routing.ComponentRouter;
import com.plan.gui.routing.RouteConstants;

import javax.swing.*;
import java.util.Locale;
import java.util.ResourceBundle;

public class FieldOfStudyInfoController implements IController
{

  private final AuthService authService;

  private final FieldOfStudyService service;
  private final ComponentRouter subRouter;

  private final FieldOfStudyInfoView view;

  private final ResourceBundle strings =
      ResourceBundle.getBundle("Strings", Locale.getDefault(), this.getClass().getClassLoader());

  public FieldOfStudyInfoController(final AuthService authService,
      FieldOfStudyService fieldOfStudyService, ComponentRouter subRouter)
  {
    this.authService = authService;
    this.service = fieldOfStudyService;
    this.subRouter = subRouter;

    this.view = new FieldOfStudyInfoView(this);
  }

  @Override public boolean canDeactivate()
  {
    return true;
  }

  public void deleteFieldOfStudy()
  {
    boolean delete =
        JOptionPane.showConfirmDialog(null, strings.getString("Delete_FOS_Confirmation_Dialog"))
            == JOptionPane.OK_OPTION;
    if (delete)
    {
      this.service.delete(subRouter.getActiveParams()[0]);
      this.subRouter.changeRoute(RouteConstants.STUDY_SEARCH);
    }
  }

  public void editFieldOfStudy()
  {
    this.subRouter.changeRoute(RouteConstants.STUDY_EDIT, subRouter.getActiveParams());
  }

  @Override public JPanel getView()
  {
    return view;
  }

  @Override public void onInit()
  {
    if (subRouter.getActiveParams() == null || subRouter.getActiveParams().length == 0)
    {
      this.subRouter.changeRoute(RouteConstants.STUDY_SEARCH);
      return;
    }

    FieldOfStudy study = service.get(subRouter.getActiveParams()[0]);
    if (study == null)
    {
      this.subRouter.changeRoute(RouteConstants.STUDY_SEARCH);
      return;
    }
    this.view.enableAdmin(authService.getUserType() == UserType.ADMIN);

    view.setFieldOfStudy(study);
  }
}
