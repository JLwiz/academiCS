package com.plan.gui.components.planeditor.fieldofstudyinfo;

import com.plan.core.conf.StringLocalizer;
import com.plan.core.models.CourseGroup;
import com.plan.core.models.FieldOfStudy;
import com.plan.core.uimodels.AbstractView;
import com.plan.gui.util.FormUtil;
import com.plan.gui.util.Styles;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.Vector;
import java.util.stream.Collectors;

public class FieldOfStudyInfoView extends AbstractView<FieldOfStudyInfoController>
{

  private JLabel idLabel;
  private JLabel createdTimeLabel;
  private JLabel titleLabel;
  private JLabel studyTypeLabel;

  private JList<String> courseGroups;
  private JButton editButton;
  private JButton deleteButton;

  public FieldOfStudyInfoView(FieldOfStudyInfoController controller)
  {
    super(controller);
    buildUI();
  }

  public void enableAdmin(final boolean isAdmin)
  {
    this.editButton.setVisible(isAdmin);
    this.deleteButton.setVisible(isAdmin);
  }

  public void setFieldOfStudy(FieldOfStudy study)
  {
    idLabel.setText(study.getId());
    createdTimeLabel.setText(FormUtil.getDateString(study.getCreatedDate()));

    titleLabel.setText(study.getName());
    studyTypeLabel.setText(study.getStudyType().toString());

    courseGroups.setListData(listToVector(study.getCourseGroups()));
  }

  private void buildUI()
  {
    setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
    setBorder(Styles.DEFAULT_PADDING);

    JPanel titleRow = new JPanel();
    titleRow.setLayout(new BoxLayout(titleRow, BoxLayout.X_AXIS));
    JLabel title = new JLabel("Field Of Study Information", SwingConstants.LEFT);
    title.setFont(Styles.DEFAULT_HEADER_SIZE);
    title.setMaximumSize(Styles.TEXT_FIELD_SIZE);
    titleRow.add(title);
    titleRow.add(Box.createHorizontalGlue());
    editButton = new JButton(StringLocalizer.getInstance().getString("Edit"));
    editButton.addActionListener(e -> controller.editFieldOfStudy());
    deleteButton = new JButton(StringLocalizer.getInstance().getString("Delete"));
    deleteButton.addActionListener(e -> controller.deleteFieldOfStudy());

    setMaximumSize(new Dimension(3, 1));
    titleRow.add(editButton);
    titleRow.add(deleteButton);

    add(titleRow);

    idLabel = new JLabel("", SwingConstants.LEFT);
    add(getRow(idLabel, StringLocalizer.getInstance().getString("Field_Of_Study_ID")));

    createdTimeLabel = new JLabel("", SwingConstants.LEFT);
    add(getRow(createdTimeLabel, StringLocalizer.getInstance().getString("Field_Of_Study_Time")));

    titleLabel = new JLabel("", SwingConstants.LEFT);
    add(getRow(titleLabel, StringLocalizer.getInstance().getString("Field_Of_Study_Name_Alt")));

    studyTypeLabel = new JLabel("", SwingConstants.LEFT);
    add(getRow(studyTypeLabel, StringLocalizer.getInstance().getString("Field_Of_Study_Type_Alt")));

    courseGroups = new JList<>();
    add(getListRow(courseGroups));

  }

  private JPanel getListRow(JList<String> list)
  {
    JPanel row = new JPanel();
    row.setLayout(new BoxLayout(row, BoxLayout.X_AXIS));
    row.setBorder(BorderFactory.createTitledBorder(Styles.DEFAULT_BORDER,
        StringLocalizer.getInstance().getString("Course_Groups")));
    JScrollPane scrollPane = new JScrollPane(list);
    scrollPane.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
    row.add(scrollPane);
    return row;
  }

  private JPanel getRow(JComponent label, String title)
  {
    JPanel row = new JPanel();
    row.setLayout(new BoxLayout(row, BoxLayout.X_AXIS));
    row.setBorder(BorderFactory.createTitledBorder(Styles.DEFAULT_BORDER, title));
    label.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
    row.add(label);
    return row;
  }

  private Vector<String> listToVector(List<CourseGroup> courseList)
  {
    if (courseList == null)
      return new Vector<>();
    return courseList.stream().map(CourseGroup::getTitle)
        .collect(Collectors.toCollection(Vector::new));
  }
}
