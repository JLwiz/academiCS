package com.plan.gui.components.planeditor.fieldofstudysearch;

import com.plan.core.services.FieldOfStudyService;
import com.plan.core.uimodels.IController;
import com.plan.gui.routing.ComponentRouter;
import com.plan.gui.routing.RouteConstants;

import javax.swing.*;
import java.util.stream.Collectors;

public class FieldOfStudySearchController implements IController
{

  private final FieldOfStudyService service;
  private final ComponentRouter subRouter;

  private final FieldOfStudySearchView view;

  public FieldOfStudySearchController(FieldOfStudyService fieldOfStudyService,
      ComponentRouter subRouter)
  {
    this.service = fieldOfStudyService;
    this.subRouter = subRouter;

    this.view = new FieldOfStudySearchView(this);
  }

  @Override public boolean canDeactivate()
  {
    return true;
  }

  @Override public JPanel getView()
  {
    return view;
  }

  @Override public void onInit()
  {
    view.setTable(service.getAll());
    view.setFocus();
  }

  public void search(String title)
  {
    view.setTable(service.getAll().stream()
        .filter(t -> t.getName().toLowerCase().contains(title.toLowerCase()))
        .collect(Collectors.toList()));
  }

  public void select(String id)
  {
    this.subRouter.changeRoute(RouteConstants.STUDY_VIEW, id);
  }
}
