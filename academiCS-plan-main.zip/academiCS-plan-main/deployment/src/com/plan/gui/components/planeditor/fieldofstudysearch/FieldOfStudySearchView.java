package com.plan.gui.components.planeditor.fieldofstudysearch;

import com.plan.core.conf.StringLocalizer;
import com.plan.core.models.FieldOfStudy;
import com.plan.core.uimodels.AbstractView;
import com.plan.gui.util.Styles;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.Collection;
import java.util.Vector;

public class FieldOfStudySearchView extends AbstractView<FieldOfStudySearchController>
{

  private JTextField fieldOfStudyTitleField;
  private JTable searchTable;

  public FieldOfStudySearchView(FieldOfStudySearchController controller)
  {
    super(controller);
    buildUI();
  }

  public void setFocus()
  {
    fieldOfStudyTitleField.requestFocus();
  }

  public void setTable(Collection<FieldOfStudy> studies)
  {
    Vector<String> headers = new Vector<>();
    headers.add(StringLocalizer.getInstance().getString("Field_Of_Study_Id"));
    headers.add(StringLocalizer.getInstance().getString("Field_Of_Study_Title"));
    headers.add(StringLocalizer.getInstance().getString("Field_Of_Study_Type"));

    Vector<Vector<String>> data = new Vector<>();
    for (FieldOfStudy study : studies)
    {
      Vector<String> d = new Vector<>();
      d.add(study.getId());
      d.add(study.getName());
      d.add(study.getStudyType().toString());
      data.add(d);
    }
    DefaultTableModel model = new DefaultTableModel(data, headers);
    searchTable.setModel(model);

  }

  private void buildUI()
  {
    setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
    setBorder(Styles.DEFAULT_PADDING);

    JPanel titleRow = new JPanel();
    titleRow.setLayout(new BoxLayout(titleRow, BoxLayout.X_AXIS));
    JLabel title = new JLabel(StringLocalizer.getInstance().getString("Field_Of_Study_Search"),
        SwingConstants.LEFT);
    title.setFont(Styles.DEFAULT_HEADER_SIZE);
    title.setMaximumSize(Styles.TEXT_FIELD_SIZE);
    titleRow.add(title);
    add(titleRow);

    JPanel rowOne = new JPanel();
    rowOne.setLayout(new BoxLayout(rowOne, BoxLayout.X_AXIS));
    rowOne.setBorder(BorderFactory.createEmptyBorder(5, 0, 20, 0));

    JPanel termTitleWrapper = new JPanel(new BorderLayout());
    termTitleWrapper
        .add(new JLabel(StringLocalizer.getInstance().getString("Field_Of_Study_Title")),
            BorderLayout.NORTH);
    fieldOfStudyTitleField = new JTextField();
    fieldOfStudyTitleField
        .addActionListener(e -> controller.search(fieldOfStudyTitleField.getText()));
    fieldOfStudyTitleField.setMaximumSize(Styles.TEXT_FIELD_SIZE);
    fieldOfStudyTitleField.setFont(Styles.DEFAULT_TEXT_FIELD_SIZE);
    termTitleWrapper.add(fieldOfStudyTitleField);
    rowOne.add(termTitleWrapper);
    rowOne.setMaximumSize(new Dimension(Integer.MAX_VALUE, 300));
    add(rowOne);

    searchTable = new JTable()
    {
      @Override public boolean isCellEditable(int rowIndex, int colIndex)
      {
        return false; //Disallow the editing of any cell
      }
    };
    searchTable.getTableHeader().setReorderingAllowed(false);
    searchTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    searchTable.getSelectionModel().addListSelectionListener(l -> {
      if (!l.getValueIsAdjusting() && searchTable.getSelectedRow() >= 0)
      {
        controller.select(searchTable.getValueAt(searchTable.getSelectedRow(), 0).toString());
        searchTable.clearSelection();
      }
    });
    add(new JScrollPane(searchTable));
  }
}
