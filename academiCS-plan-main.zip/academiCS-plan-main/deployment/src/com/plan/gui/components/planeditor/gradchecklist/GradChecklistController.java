package com.plan.gui.components.planeditor.gradchecklist;

import com.plan.core.conf.StringLocalizer;
import com.plan.core.io.PlanLogger;
import com.plan.core.models.*;
import com.plan.core.services.StudentPlanService;
import com.plan.core.uimodels.IController;
import com.plan.gui.routing.ComponentRouter;
import com.plan.gui.routing.RouteConstants;

import javax.swing.*;
import java.awt.*;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class GradChecklistController implements IController
{

  private final GradChecklistView view;
  private final StudentPlanService service;
  private final ComponentRouter router;

  public GradChecklistController(final StudentPlanService service, final ComponentRouter router)
  {
    this.service = service;
    this.router = router;
    this.view = new GradChecklistView(this);
  }

  @Override public boolean canDeactivate()
  {
    return true;
  }

  @Override public JPanel getView()
  {
    return view;
  }

  @Override public void onInit()
  {
    if (this.service.getPlan() == null)
    {
      router.changeRoute(RouteConstants.DASHBOARD_ROUTE);
      return;
    }

    Map<String, String> requiredCourses =
        courseGroupsToMap(getCourseGroups(CourseType.REQUIRED, service.getPlan().getFieldOfStudy()),
            service.getPlan().getCourseMap());
    Map<String, String> electiveCourses =
        courseGroupsToMap(getCourseGroups(CourseType.ELECTIVE, service.getPlan().getFieldOfStudy()),
            service.getPlan().getCourseMap());
    Map<String, String> genEdCourses = courseGroupsToMap(
        getCourseGroups(CourseType.GENERAL_EDUCATION, service.getPlan().getFieldOfStudy()),
        service.getPlan().getCourseMap());

    view.resetPage();
    view.setRequiredCourses(requiredCourses);
    view.setElectiveCourses(electiveCourses);
    view.setGenEdCourses(genEdCourses);
  }

  public void print()
  {
    PrinterJob job = PrinterJob.getPrinterJob();
    job.setJobName(StringLocalizer.getInstance().getString("Graduation_Checklist"));
    System.out.println(view.getPrintableContent());
    job.setPrintable((g, pf, p) -> {
      if (p > 0)
        return Printable.NO_SUCH_PAGE;
      Graphics2D g2 = (Graphics2D) g;

      g2.translate(pf.getImageableX(), pf.getImageableY());
      double xScale = (72d * 8.5) / (96d * 8.5);
      double yScale = (72d * 11d) / (96d * 11d);
      g2.scale(xScale, yScale);
      this.view.getPrintableContent().paint(g2);
      return Printable.PAGE_EXISTS;
    });
    if (job.printDialog())
    {
      try
      {
        job.print();
      }
      catch (PrinterException e)
      {
        e.printStackTrace();
        PlanLogger.getInstance().error("Failed to print", e);
      }
    }
  }

  private Map<String, String> courseGroupsToMap(List<CourseGroup> courseGroups,
      Map<AcademicTerm, List<Course>> studentCourseMap)
  {
    Map<String, String> map = new HashMap<>();
    if (studentCourseMap == null || courseGroups.size() == 0)
      return map;
    for (var g : courseGroups)
    {
      if (g.getRequiredCourses() == g.getCourses().size())
      {
        g.getCourses().forEach(c -> {
          var t = find(c, studentCourseMap);
          map.put(c.getAbbreviatedTitle() + " " + c.getTitle(),
              t == null ? "[ Not Satisfied ]" : t.getTitle());
        });
      }
      else if (g.getRequiredCourses() == 1)
      {
        AcademicTerm t = null;
        Course selectedCourse = null;
        for (var c : g.getCourses())
        {
          t = find(c, studentCourseMap);
          selectedCourse = c;
          if (t != null)
            break;
        }
        map.put(g.getTitle() + ": " + courseListToString(g.getCourses()),
            t == null ? "[ Not Satisfied ]" :
                "(" + selectedCourse.getAbbreviatedTitle() + ") " + t.getTitle());
      }
      else if (g.getRequiredCourses() > 1 && g.getRequiredCourses() < g.getCourses().size())
      {
        List<Course> temp = new ArrayList<>(g.getCourses());
        for (int i = 0; i < g.getRequiredCourses(); i++)
        {
          AcademicTerm t = null;
          Course c = null;
          while (t == null && temp.size() > 0)
          {
            c = temp.get(0);
            t = find(c, studentCourseMap);
            temp.remove(c);
          }
          map.put((g.getTitle() + " " + (i + 1)), t == null ? "[ Not Satisfied ]" :
              "(" + c.getAbbreviatedTitle() + ") " + t.getTitle());
        }
      }
    }
    return map;
  }

  private String courseListToString(List<Course> courses)
  {
    if (courses == null || courses.size() == 0)
      return "";
    return IntStream.range(0, courses.size() - 1)
        .mapToObj(i -> courses.get(i).getAbbreviatedTitle()).collect(Collectors
            .joining(", ", "", " or " + courses.get(courses.size() - 1).getAbbreviatedTitle()));
  }

  private AcademicTerm find(Course course, Map<AcademicTerm, List<Course>> studentCourseMap)
  {
    for (AcademicTerm term : studentCourseMap.keySet())
    {
      if (studentCourseMap.get(term).stream().anyMatch(c -> course.getId().equals(c.getId())))
        return term;
    }
    return null;
  }

  private List<CourseGroup> getCourseGroups(CourseType type, FieldOfStudy fieldOfStudy)
  {
    List<CourseGroup> groups = new ArrayList<>();
    for (CourseGroup g : fieldOfStudy.getCourseGroups())
    {
      if (g.getCourses() != null && g.getCourses().size() > 0)
      {
        if (g.getCourses().get(0).getCourseType() == type)
        {
          groups.add(g);
        }
      }
    }
    return groups;
  }
}
