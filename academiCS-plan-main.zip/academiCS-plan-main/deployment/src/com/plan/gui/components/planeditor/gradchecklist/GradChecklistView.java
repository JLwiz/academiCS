package com.plan.gui.components.planeditor.gradchecklist;

import com.plan.core.conf.StringLocalizer;
import com.plan.core.uimodels.AbstractView;
import com.plan.gui.util.Styles;

import javax.swing.*;
import java.awt.*;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * {@code GradChecklistView}.
 *
 * @author Ernest Tussey
 * @version 1.0
 */
public class GradChecklistView extends AbstractView<GradChecklistController>
{

  private JPanel contentArea;
  private JPanel page;
  private int currentRow = 0;

  /**
   * Constructs an instance of {@code AbstractView} provided
   * an owning controller.
   *
   * @param controller the controller that manages this view
   */
  public GradChecklistView(final GradChecklistController controller)
  {
    super(controller);
    buildUI();
  }

  public JPanel getPrintableContent()
  {
    return page;
  }

  public void resetPage()
  {
    contentArea.removeAll();
    currentRow = 0;
  }

  public void setElectiveCourses(Map<String, String> courseMap)
  {
    buildGrid(StringLocalizer.getInstance().getString("Elective_Courses"), courseMap);
  }

  public void setGenEdCourses(Map<String, String> courseMap)
  {
    buildGrid(StringLocalizer.getInstance().getString("General_Education_Courses"), courseMap);
  }

  public void setRequiredCourses(Map<String, String> courseMap)
  {
    buildGrid(StringLocalizer.getInstance().getString("Required_Courses"), courseMap);
  }

  private void buildGrid(String courseColName, Map<String, String> courseMap)
  {
    if (courseMap.size() == 0)
    {
      return;
    }
    GridBagConstraints gbc = new GridBagConstraints();
    JLabel courseCol = new JLabel(courseColName);
    courseCol.setFont(Styles.PAGE_FONT_BOLD);
    gbc.fill = GridBagConstraints.HORIZONTAL;
    gbc.anchor = GridBagConstraints.NORTH;
    gbc.weightx = 0.75;
    gbc.gridx = 0;
    gbc.gridy = currentRow;
    gbc.ipady = 10;
    contentArea.add(courseCol, gbc);

    JLabel termCol = new JLabel("Term");
    termCol.setFont(Styles.PAGE_FONT_BOLD);
    gbc.fill = GridBagConstraints.HORIZONTAL;
    gbc.anchor = GridBagConstraints.NORTH;
    gbc.weightx = 0.25;
    gbc.gridx = 1;
    gbc.gridy = currentRow;
    gbc.ipady = 10;
    contentArea.add(termCol, gbc);
    currentRow++;

    AtomicInteger row = new AtomicInteger(currentRow);
    courseMap.keySet().stream().sorted().forEach(c -> {
      JLabel cLabel = new JLabel(c);
      cLabel.setFont(Styles.PAGE_FONT);
      gbc.fill = GridBagConstraints.HORIZONTAL;
      gbc.anchor = GridBagConstraints.NORTH;
      gbc.weightx = 0.75;
      gbc.gridx = 0;
      gbc.gridy = row.get();
      gbc.ipady = 10;
      contentArea.add(cLabel, gbc);
      JLabel tLabel = new JLabel(courseMap.get(c));
      tLabel.setFont(Styles.PAGE_FONT);
      gbc.fill = GridBagConstraints.HORIZONTAL;
      gbc.anchor = GridBagConstraints.NORTH;
      gbc.weightx = 0.25;
      gbc.gridx = 1;
      gbc.gridy = row.get();
      gbc.ipady = 10;
      contentArea.add(tLabel, gbc);
      row.getAndIncrement();
    });
    currentRow = row.get();

    gbc.fill = GridBagConstraints.HORIZONTAL;
    gbc.anchor = GridBagConstraints.NORTH;
    gbc.weightx = 0.75;
    gbc.gridx = 0;
    gbc.gridy = currentRow;
    gbc.ipady = 10;
    contentArea.add(new JLabel(), gbc);

    gbc.fill = GridBagConstraints.HORIZONTAL;
    gbc.anchor = GridBagConstraints.NORTH;
    gbc.weightx = 0.25;
    gbc.gridx = 1;
    gbc.gridy = currentRow;
    gbc.ipady = 10;
    contentArea.add(new JLabel(), gbc);
    currentRow++;
  }

  private JPanel buildPage()
  {
    JPanel pageWrapper = new JPanel(new BorderLayout());
    pageWrapper.setBorder(Styles.DEFAULT_BORDER);

    page = new JPanel();
    page.setLayout(new BoxLayout(page, BoxLayout.Y_AXIS));
    page.setBackground(Color.WHITE);
    page.setBorder(Styles.PAGE_MARGIN);
    page.setMaximumSize(Styles.PAGE_SIZE);
    page.setPreferredSize(Styles.PAGE_SIZE);
    page.setMaximumSize(Styles.PAGE_SIZE);
    page.setSize(Styles.PAGE_SIZE);

    JPanel contentWrapper = new JPanel(new BorderLayout());
    contentWrapper.setBackground(Color.WHITE);
    JLabel pageHeader =
        new JLabel(StringLocalizer.getInstance().getString("Field_Requirements_Checklist"),
            SwingConstants.CENTER);
    pageHeader.setFont(Styles.DEFAULT_HEADER_SIZE);
    contentWrapper.add(pageHeader, BorderLayout.NORTH);

    JPanel wrap = new JPanel(new BorderLayout());
    contentArea = new JPanel(new GridBagLayout());
    contentArea.setBackground(Color.WHITE);
    contentArea.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
    contentWrapper.setBackground(Color.WHITE);
    wrap.add(contentArea, BorderLayout.BEFORE_FIRST_LINE);
    wrap.setBackground(Color.WHITE);
    contentWrapper.add(wrap, BorderLayout.CENTER);

    page.add(contentWrapper);
    pageWrapper.add(page);
    return pageWrapper;
  }

  private void buildUI()
  {
    setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
    setBorder(Styles.DEFAULT_PADDING);

    JPanel titleRow = new JPanel();
    titleRow.setLayout(new BoxLayout(titleRow, BoxLayout.X_AXIS));
    JLabel title = new JLabel(StringLocalizer.getInstance().getString("Requirement_Checklist"),
        SwingConstants.LEFT);
    title.setFont(Styles.DEFAULT_HEADER_SIZE);
    title.setMaximumSize(Styles.TEXT_FIELD_SIZE);
    titleRow.add(title);
    titleRow.add(Box.createHorizontalGlue());
    JButton printButton = new JButton(StringLocalizer.getInstance().getString("Print"));
    printButton.addActionListener(e -> controller.print());
    setMaximumSize(new Dimension(3, 1));
    titleRow.add(printButton);
    add(titleRow);

    JPanel pageBody = new JPanel();
    pageBody.setAlignmentX(CENTER_ALIGNMENT);
    pageBody.add(Box.createHorizontalGlue());
    pageBody.add(buildPage());
    pageBody.add(Box.createHorizontalGlue());
    add(pageBody);
  }
}
