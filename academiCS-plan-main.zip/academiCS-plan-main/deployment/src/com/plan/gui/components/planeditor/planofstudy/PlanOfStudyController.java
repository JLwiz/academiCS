package com.plan.gui.components.planeditor.planofstudy;

import com.plan.core.io.PlanLogger;
import com.plan.core.models.AcademicTerm;
import com.plan.core.models.TermType;
import com.plan.core.services.StudentPlanService;
import com.plan.core.uimodels.IController;
import com.plan.gui.routing.ComponentRouter;
import com.plan.gui.routing.RouteConstants;

import javax.swing.*;
import java.awt.*;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class PlanOfStudyController implements IController
{
  private final PlanOfStudyView view;

  private final StudentPlanService service;
  private final ComponentRouter router;

  private boolean includeSummer;
  private boolean includeWinter;
  private TermType type;

  public PlanOfStudyController(final StudentPlanService service, final ComponentRouter router)
  {
    this.service = service;
    this.router = router;
    this.view = new PlanOfStudyView(this);
  }

  public void addRow()
  {
    this.view.addNewRow(new ArrayList<>(service.getPlan().getCourseMap().keySet()),
        service.getPlan().getCourseMap());
  }

  public void autoPopulate()
  {
    List<AcademicTerm> terms = new ArrayList<>(service.getPlan().getCourseMap().keySet());
    if (terms.size() == 0)
      return;
    terms.sort(Comparator.comparingLong(AcademicTerm::getStartDate));

    includeWinter = false;
    includeSummer = false;
    type = TermType.SEMESTER;
    for (AcademicTerm term : terms)
    {
      if (term.getTermType() == TermType.WINTER_SESSION)
        includeWinter = true;
      else if (term.getTermType() == TermType.SUMMER_SESSION)
        includeSummer = true;
      else
        type = term.getTermType();
    }
    List<String> headers = new ArrayList<>();
    if (type == TermType.SEMESTER)
      headers.add("Fall");
    if (type == TermType.TRIMESTER)
    {
      headers.add("Trimester 1");
      headers.add("Trimester 2");
    }
    if (type == TermType.QUARTER)
    {
      headers.add("Q1");
      headers.add("Q2");
    }
    if (includeWinter)
      headers.add("Winter");
    if (type == TermType.SEMESTER)
      headers.add("Spring");
    if (type == TermType.TRIMESTER)
    {
      headers.add("Trimester 3");
    }
    if (type == TermType.QUARTER)
    {
      headers.add("Q3");
      headers.add("Q4");
    }
    if (includeSummer)
      headers.add("Summer");
    view.setHeader(headers);
    view.setTerms(terms);
    view.rebuild(false, service.getPlan().getCourseMap());
  }

  @Override public JPanel getView()
  {
    return view;
  }

  @Override public void onInit()
  {
    if (this.service.getPlan() == null)
    {
      router.changeRoute(RouteConstants.DASHBOARD_ROUTE);
      return;
    }
    autoPopulate();
  }

  public void print()
  {
    PrinterJob job = PrinterJob.getPrinterJob();
    job.setJobName("Plan of Study");
    job.setPrintable((g, pf, p) -> {
      if (p > 0)
        return Printable.NO_SUCH_PAGE;
      Graphics2D g2 = (Graphics2D) g;

      g2.translate(pf.getImageableX(), pf.getImageableY());
      double xScale = (72d * 8.5) / (96d * 8.5);
      double yScale = (72d * 11d) / (96d * 11d);
      g2.scale(xScale, yScale);
      this.view.getPrintableContent().paint(g2);
      return Printable.PAGE_EXISTS;
    });
    if (job.printDialog())
    {
      try
      {
        job.print();
      }
      catch (PrinterException e)
      {
        e.printStackTrace();
        PlanLogger.getInstance().error("Failed to print", e);
      }
    }
  }

  public void setEditor(boolean editing)
  {
    view.rebuild(editing, service.getPlan().getCourseMap());
  }

}
