package com.plan.gui.components.planeditor.planofstudy;

import com.plan.core.conf.StringLocalizer;
import com.plan.core.models.AcademicTerm;
import com.plan.core.models.Course;
import com.plan.core.uimodels.AbstractView;
import com.plan.gui.util.Styles;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class PlanOfStudyView extends AbstractView<PlanOfStudyController>
{

  static final Border GRID_PADDING = BorderFactory.createEmptyBorder(10, 10, 10, 10);
  static final Color HEADER_COLOR = new Color(202, 190, 217);
  static final Color EVEN_COLOR = new Color(239, 239, 239);
  static final Color ODD_COLOR = new Color(255, 255, 255);
  private final List<JPanel> headerRow;
  private final List<TermCellEditor> editorList;
  private JButton printButton;
  private JButton saveButton;
  private JButton editButton;
  private JButton addRowButton;
  private JPanel contentArea;
  private JPanel page;

  /**
   * Constructs an instance of {@code AbstractView} provided
   * an owning controller.
   *
   * @param controller the controller that manages this view
   */
  public PlanOfStudyView(final PlanOfStudyController controller)
  {
    super(controller);
    this.editorList = new ArrayList<>();
    this.headerRow = new ArrayList<>();
    buildUI();
  }

  public void addNewRow(final List<AcademicTerm> terms,
      final Map<AcademicTerm, List<Course>> courseMap)
  {
    for (int i = 0; i < headerRow.size() - 1; i++)
    {
      this.editorList.add(new TermCellEditor(null, terms));
    }

    rebuild(true, courseMap);
  }

  public JPanel getPrintableContent()
  {
    return page;
  }

  public void rebuild(final boolean isEditor, final Map<AcademicTerm, List<Course>> courseMap)
  {
    if (headerRow.size() == 0)
      headerRow.add(new JPanel());
    printButton.setEnabled(!isEditor);
    editButton.setEnabled(!isEditor);
    saveButton.setEnabled(isEditor);
    this.contentArea.removeAll();
    this.contentArea.setLayout(new GridLayout(0, headerRow.size()));
    this.headerRow.forEach(this.contentArea::add);
    int year = 1;
    for (int i = 0; i < editorList.size(); i += (headerRow.size()) - 1)
    {
      this.contentArea.add(getYearCell(year, year % 2 == 0));
      for (int j = 0; j < headerRow.size() - 1; j++)
      {
        TermCellEditor editor;
        if (i + j >= editorList.size())
        {
          editor = new TermCellEditor(null, new ArrayList<>(courseMap.keySet()));
          editorList.add(editor);
        }
        else
        {
          editor = editorList.get(i + j);
        }
        var courses = editor.getTerm() == null ? null : courseMap.get(editor.getTerm());
        editor.setEditing(isEditor, courses, year % 2 == 0);
        this.contentArea.add(editor);
      }
      year++;
    }
    if (isEditor)
      this.contentArea.add(addRowButton);
    this.validate();
    this.repaint();
  }

  public void setHeader(final List<String> values)
  {
    this.headerRow.clear();
    this.headerRow.add(new JPanel());
    values.forEach(v -> this.headerRow.add(getHeader(v)));
  }

  public void setTerms(final List<AcademicTerm> terms)
  {
    this.editorList.clear();
    for (int i = 0; i < terms.size(); i++)
    {
      this.editorList.add(new TermCellEditor(terms.get(i), terms));
    }
  }

  private JPanel buildPage()
  {
    JPanel pageWrapper = new JPanel(new BorderLayout());
    pageWrapper.setBorder(Styles.DEFAULT_BORDER);

    page = new JPanel();
    page.setLayout(new BoxLayout(page, BoxLayout.Y_AXIS));
    page.setBackground(Color.WHITE);
    page.setBorder(Styles.PAGE_MARGIN);
    page.setMaximumSize(Styles.PAGE_SIZE);
    page.setPreferredSize(Styles.PAGE_SIZE);
    page.setMaximumSize(Styles.PAGE_SIZE);
    page.setSize(Styles.PAGE_SIZE);

    JPanel contentWrapper = new JPanel(new BorderLayout());
    contentWrapper.setBackground(Color.WHITE);

    JPanel wrap = new JPanel(new BorderLayout());
    contentArea = new JPanel();
    contentArea.setBackground(Color.WHITE);
    contentArea.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
    contentWrapper.setBackground(Color.WHITE);
    wrap.add(contentArea, BorderLayout.BEFORE_FIRST_LINE);
    wrap.setBackground(Color.WHITE);
    contentWrapper.add(wrap, BorderLayout.CENTER);

    page.add(contentWrapper);
    pageWrapper.add(page);
    return pageWrapper;
  }

  private void buildUI()
  {
    setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
    setBorder(Styles.DEFAULT_PADDING);

    JPanel titleRow = new JPanel();
    titleRow.setLayout(new BoxLayout(titleRow, BoxLayout.X_AXIS));
    JLabel title = new JLabel("Plan of Study", SwingConstants.LEFT);
    title.setFont(Styles.DEFAULT_HEADER_SIZE);
    title.setMaximumSize(Styles.TEXT_FIELD_SIZE);
    titleRow.add(title);
    titleRow.add(Box.createHorizontalGlue());
    printButton = new JButton(StringLocalizer.getInstance().getString("Print"));
    printButton.addActionListener(e -> controller.print());
    editButton = new JButton(StringLocalizer.getInstance().getString("Edit"));

    saveButton = new JButton(StringLocalizer.getInstance().getString("Save"));
    saveButton.addActionListener(e -> controller.setEditor(false));
    editButton.addActionListener(e -> controller.setEditor(true));
    setMaximumSize(new Dimension(3, 1));
    titleRow.add(saveButton);
    titleRow.add(editButton);
    titleRow.add(printButton);
    add(titleRow);

    JPanel pageBody = new JPanel();
    pageBody.setAlignmentX(CENTER_ALIGNMENT);
    pageBody.add(Box.createHorizontalGlue());
    pageBody.add(buildPage());
    pageBody.add(Box.createHorizontalGlue());
    add(pageBody);

    addRowButton = new JButton("Add Row");
    addRowButton.addActionListener(l -> controller.addRow());
  }

  private JPanel getHeader(final String text)
  {
    JPanel header = new JPanel(new BorderLayout());
    header.setBorder(GRID_PADDING);
    header.setBackground(new Color(202, 190, 217));
    JLabel title = new JLabel();
    title.setText(text);
    title.setFont(Styles.PAGE_FONT_BOLD);
    header.add(title);
    return header;
  }

  private JPanel getYearCell(final int year, final boolean isEven)
  {
    JPanel cell = new JPanel(new BorderLayout());
    cell.setBorder(GRID_PADDING);
    cell.setBackground(isEven ? PlanOfStudyView.EVEN_COLOR : PlanOfStudyView.ODD_COLOR);
    JLabel title = new JLabel();
    title.setText("Year " + year);
    title.setFont(Styles.PAGE_FONT_BOLD);
    cell.add(title);
    return cell;
  }

}
