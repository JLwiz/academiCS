package com.plan.gui.components.planeditor.planofstudy;

import com.plan.core.models.AcademicTerm;
import com.plan.core.models.Course;
import com.plan.gui.util.Styles;

import javax.swing.*;
import java.util.List;

public class TermCellEditor extends JPanel
{
  private final JComboBox<String> termBox;
  private AcademicTerm value;

  public TermCellEditor(final AcademicTerm current, final List<AcademicTerm> terms)
  {
    this.value = current;
    setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
    setBorder(PlanOfStudyView.GRID_PADDING);
    termBox = new JComboBox<>();
    String noneOpt = "[ None ]";
    termBox.addItem(noneOpt);
    terms.forEach(t -> {
      if (t != null)
        termBox.addItem(t.getTitle());
    });
    if (current != null)
      termBox.setSelectedItem(current.getTitle());
    else
      termBox.setSelectedItem(noneOpt);
    termBox.addActionListener(e -> {
      String selected = (String) termBox.getSelectedItem();
      if (selected == null)
      {
        this.value = null;
        return;
      }
      for (AcademicTerm term : terms)
      {
        if (term == null)
          continue;
        if (term.getTitle().equals(selected))
          this.value = term;
      }
    });
  }

  public AcademicTerm getTerm()
  {
    return this.value;
  }

  public void setEditing(boolean editing, List<Course> courses, final boolean isEven)
  {
    setBackground(isEven ? PlanOfStudyView.EVEN_COLOR : PlanOfStudyView.ODD_COLOR);
    this.removeAll();
    if (editing)
      setEditableView();
    else
      setNonEditableView(courses);
    this.validate();
    this.repaint();
  }

  private void setEditableView()
  {
    this.add(termBox);
  }

  private void setNonEditableView(List<Course> courses)
  {
    if (courses == null || courses.size() == 0)
    {
      JLabel noCourses = new JLabel("No courses.");
      noCourses.setFont(Styles.PAGE_FONT);
      add(noCourses);
      return;
    }
    courses.forEach(c -> {
      JLabel courseName = new JLabel(c.getAbbreviatedTitle());
      courseName.setFont(Styles.PAGE_FONT);
      add(courseName);
    });
  }

}
