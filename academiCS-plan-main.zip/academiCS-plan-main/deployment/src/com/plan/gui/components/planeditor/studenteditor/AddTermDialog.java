package com.plan.gui.components.planeditor.studenteditor;

import com.plan.core.models.AcademicTerm;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.*;

public class AddTermDialog
{

  private final List<JComponent> components;

  private final String title;
  private final int messageType;
  private final Component root;
  private final String[] options;
  private final JComboBox<AcademicTerm> termBox;
  protected ResourceBundle strings =
      ResourceBundle.getBundle("Strings", Locale.getDefault(), this.getClass().getClassLoader());
  private int optionIndex;

  public AddTermDialog(Component root, Collection<AcademicTerm> terms)
  {
    components = new ArrayList<>();

    title = strings.getString("Add_Academic_Term");
    messageType = JOptionPane.PLAIN_MESSAGE;
    this.root = root;
    options = new String[] {strings.getString("Select"), strings.getString("Cancel")};
    setOptionSelection(0);

    addComponent(new JLabel(strings.getString("Terms")));
    termBox = new JComboBox<>();
    terms.forEach(termBox::addItem);
    addComponent(termBox);
  }

  public void addComponent(JComponent component)
  {
    components.add(component);
  }

  public AcademicTerm get()
  {
    return (AcademicTerm) termBox.getSelectedItem();
  }

  public void setOptionSelection(int optionIndex)
  {
    this.optionIndex = optionIndex;
  }

  public int show()
  {
    int optionType = JOptionPane.OK_CANCEL_OPTION;
    Object optionSelection = null;

    if (options.length != 0)
    {
      optionSelection = options[optionIndex];
    }

    return JOptionPane
        .showOptionDialog(root, components.toArray(), title, optionType, messageType, null, options,
            optionSelection);
  }
}
