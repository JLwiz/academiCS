package com.plan.gui.components.planeditor.studenteditor;

import com.plan.core.models.AcademicTerm;
import com.plan.core.models.Course;
import com.plan.gui.util.ResourceLoader;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;

public class CourseCard extends JPanel
{

  private static final Border CARD_BORDER = BorderFactory.createLineBorder(Color.BLACK);
  private static final Border CARD_PADDING = BorderFactory.createEmptyBorder(0, 0, 5, 0);
  private static final Border PADDING = BorderFactory.createEmptyBorder(5, 5, 5, 5);
  private static final Border ERROR_PADDING = BorderFactory.createEmptyBorder(0, 0, 5, 0);
  private static final Border ACTION_PADDING = BorderFactory.createEmptyBorder(0, 0, 5, 0);
  private static final Color ERROR_COLOR = new Color(220, 38, 38);
  private static final Border ERROR_BORDER = BorderFactory.createLineBorder(ERROR_COLOR, 1, true);
  private static final Font TITLE_FONT = new Font("Arial", Font.BOLD, 14);
  private static final Font SUBTITLE_FONT = new Font("Arial", Font.PLAIN, 12);

  private final JLabel errorLabel;
  private final JButton delete;

  private final Course course;
  private final AcademicTerm currentTerm;

  public CourseCard(AcademicTerm currentTerm, Course course, StudentEditorController controller)
  {
    this.currentTerm = currentTerm;
    this.course = course;
    setLayout(new BorderLayout());
    setBorder(CARD_PADDING);
    setPreferredSize(new Dimension(300, 125));
    setMaximumSize(new Dimension(300, 125));
    setMinimumSize(new Dimension(200, 1));

    JPanel cardWrapper = new JPanel(new BorderLayout());
    cardWrapper.setBorder(CARD_BORDER);

    JPanel contentWrapper = new JPanel(new BorderLayout());
    contentWrapper.setBorder(PADDING);

    JPanel errorWrapper = new JPanel(new BorderLayout());
    errorWrapper.setBorder(ERROR_PADDING);
    errorLabel = new JLabel("", SwingConstants.CENTER);
    errorLabel.setBorder(ERROR_BORDER);
    errorLabel.setForeground(ERROR_COLOR);
    errorLabel.setVisible(false);
    errorWrapper.add(errorLabel);
    contentWrapper.add(errorWrapper, BorderLayout.NORTH);

    JPanel courseInfo = new JPanel();
    courseInfo.setLayout(new BoxLayout(courseInfo, BoxLayout.Y_AXIS));

    JLabel title = new JLabel(course.getTitle());
    title.setFont(TITLE_FONT);
    courseInfo.add(title);

    JLabel smallTitle = new JLabel(course.getAbbreviatedTitle());
    smallTitle.setFont(SUBTITLE_FONT);
    courseInfo.add(smallTitle);

    JLabel smallInfo =
        new JLabel(course.getCourseType().toString() + " \u2022 " + course.getUnits() + " Units");
    smallInfo.setFont(SUBTITLE_FONT);
    smallInfo.setForeground(Color.darkGray);
    courseInfo.add(smallInfo);
    contentWrapper.add(courseInfo, BorderLayout.CENTER);

    JPanel actionRow = new JPanel();
    actionRow.setLayout(new BoxLayout(actionRow, BoxLayout.X_AXIS));
    actionRow.setBorder(ACTION_PADDING);
    actionRow.add(Box.createHorizontalGlue());
    delete = new JButton(
        ResourceLoader.createInstance().getIcon(controller.getView(), "icons/trash.png"));
    delete.addActionListener(l -> controller.removeCourse(course));
    actionRow.add(delete);
    contentWrapper.add(actionRow, BorderLayout.SOUTH);

    cardWrapper.add(contentWrapper);
    add(cardWrapper);

  }

  public Course getCourse()
  {
    return this.course;
  }

  public AcademicTerm getCurrentTerm()
  {
    return currentTerm;
  }

  public void setError(String error)
  {
    String msg = String.format("<html><body style='width: %1spx'>%1s", 150, error);
    this.errorLabel.setText(msg);
    this.errorLabel.setVisible(true);
  }
}
