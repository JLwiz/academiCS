package com.plan.gui.components.planeditor.studenteditor;

import com.plan.core.models.AcademicTerm;
import com.plan.core.models.Course;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class CourseValidator
{

  protected ResourceBundle strings =
      ResourceBundle.getBundle("Strings", Locale.getDefault(), this.getClass().getClassLoader());
  private String errorMsg;

  public CourseValidator()
  {
  }

  public String getValidationErrorMessage()
  {
    return errorMsg;
  }

  public boolean isValid(Course course, AcademicTerm selectedTerm,
      Map<AcademicTerm, List<Course>> userCourseMap)
  {
    errorMsg = "";
    if (!isCourseOfferedInTerm(course, selectedTerm))
    {
      errorMsg = strings.getString("TERM_NOT_OFFERED_ERROR");
      return false;
    }
    else if (!areCorequisitesValid(course, selectedTerm, userCourseMap))
    {
      errorMsg =
          strings.getString("COREQ_SAT_ERROR") + courseListToString(course.getCorequisites()) + ".";
      if (!nullOrEmpty(course.getAltCorequisites()))
        errorMsg +=
            strings.getString("Or_Choose") + courseListToString(course.getAltCorequisites()) + ".";
      return false;
    }
    else if (!areStrongPrerequisitesValid(course, selectedTerm, userCourseMap))
    {
      errorMsg = strings.getString("STR_COREQ_SAT_ERROR") + courseListToString(
          course.getStrongPrerequisites()) + ".";
      if (!nullOrEmpty(course.getAltStrongPrerequisites()))
        errorMsg +=
            strings.getString("Or_Choose") + courseListToString(course.getAltStrongPrerequisites())
                + ".";
      return false;
    }
    else if (!areWeakPrerequisitesValid(course, selectedTerm, userCourseMap))
    {
      errorMsg = strings.getString("WEAK_COREQ_SAT_ERROR") + courseListToString(
          course.getWeakPrerequisites()) + ".";
      if (!nullOrEmpty(course.getAltWeakPrerequisites()))
        errorMsg +=
            strings.getString("Or_Choose") + courseListToString(course.getAltWeakPrerequisites())
                + ".";
      return false;
    }
    return true;
  }

  private boolean areCorequisitesValid(Course course, AcademicTerm selectedTerm,
      Map<AcademicTerm, List<Course>> userCourseMap)
  {
    if (!nullOrEmpty(course.getCorequisites()))
    {
      return termContains(selectedTerm, course.getCorequisites(), userCourseMap);
    }
    else if (!nullOrEmpty(course.getAltCorequisites()))
    {
      return termContains(selectedTerm, course.getAltCorequisites(), userCourseMap);
    }
    return true;
  }

  private boolean areStrongPrerequisitesValid(Course course, AcademicTerm selectedTerm,
      Map<AcademicTerm, List<Course>> userCourseMap)
  {
    if (nullOrEmpty(course.getStrongPrerequisites()) && nullOrEmpty(
        course.getAltStrongPrerequisites()))
      return true;
    var sortedTerms =
        userCourseMap.keySet().stream().sorted(Comparator.comparing(AcademicTerm::getStartDate))
            .collect(Collectors.toList());

    if (sortedTerms.size() <= 1)
      return false;
    var subList = sortedTerms.subList(0, sortedTerms.indexOf(selectedTerm));
    boolean found = true;
    if (!nullOrEmpty(course.getStrongPrerequisites()))
    {
      for (Course c : course.getStrongPrerequisites())
      {
        if (!find(c, subList, userCourseMap))
        {
          found = false;
        }

      }
    }
    if (!nullOrEmpty(course.getAltStrongPrerequisites()) && !found)
    {
      found = true;
      for (Course c : course.getAltStrongPrerequisites())
      {
        if (!find(c, subList, userCourseMap))
          return false;
      }
    }
    return found;
  }

  private boolean areWeakPrerequisitesValid(Course course, AcademicTerm selectedTerm,
      Map<AcademicTerm, List<Course>> userCourseMap)
  {
    if (nullOrEmpty(course.getWeakPrerequisites()) && nullOrEmpty(course.getAltWeakPrerequisites()))
      return true;
    var sortedTerms =
        userCourseMap.keySet().stream().sorted(Comparator.comparing(AcademicTerm::getStartDate))
            .collect(Collectors.toList());

    var subList = sortedTerms.subList(0, sortedTerms.indexOf(selectedTerm) + 1);
    boolean found = true;
    if (!nullOrEmpty(course.getWeakPrerequisites()))
    {
      for (Course c : course.getWeakPrerequisites())
      {
        if (!find(c, subList, userCourseMap))
          found = false;
      }
    }
    if (!nullOrEmpty(course.getAltWeakPrerequisites()) && !found)
    {
      found = true;
      for (Course c : course.getAltWeakPrerequisites())
      {
        if (!find(c, subList, userCourseMap))
          return false;
      }
    }
    return found;
  }

  private String courseListToString(List<Course> courses)
  {
    if (courses == null || courses.size() == 0)
      return "";
    return IntStream.range(0, courses.size() - 1)
        .mapToObj(i -> courses.get(i).getAbbreviatedTitle() + ", ")
        .collect(Collectors.joining("", "", courses.get(courses.size() - 1).getAbbreviatedTitle()));
  }

  private boolean find(Course course, List<AcademicTerm> terms,
      Map<AcademicTerm, List<Course>> userCourseMap)
  {
    for (AcademicTerm term : terms)
    {
      if (userCourseMap.get(term).stream().anyMatch(c -> course.getId().equals(c.getId())))
        return true;
    }
    return false;
  }

  private boolean isCourseOfferedInTerm(Course course, AcademicTerm selectedTerm)
  {
    var plannedOfferings = selectedTerm.getIntendedCourses();
    var actualOfferings = selectedTerm.getActualCourses();
    return (plannedOfferings != null && plannedOfferings.contains(course)) || (
        actualOfferings != null && actualOfferings.contains(course));
  }

  private boolean nullOrEmpty(Collection<?> collection)
  {
    return collection == null || collection.size() == 0;
  }

  private boolean termContains(AcademicTerm selectedTerm, Collection<Course> courses,
      Map<AcademicTerm, List<Course>> userCourseMap)
  {
    //Everything contains nothing but nothing only contains nothing
    if (nullOrEmpty(courses))
      return true;
    return userCourseMap.get(selectedTerm).containsAll(courses);
  }
}
