package com.plan.gui.components.planeditor.studenteditor;

import com.plan.core.io.FileTypeFilter;
import com.plan.core.io.JSONFileUtility;
import com.plan.core.io.ModelSerializer;
import com.plan.core.models.AcademicTerm;
import com.plan.core.models.Course;
import com.plan.core.services.CourseService;
import com.plan.core.services.StudentPlanService;
import com.plan.core.services.TermService;
import com.plan.core.uimodels.IController;
import com.plan.gui.components.planeditor.studenteditor.drag.CourseTransferable;
import com.plan.gui.routing.ComponentRouter;
import com.plan.gui.routing.RouteConstants;

import javax.swing.*;
import java.awt.*;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DragGestureEvent;
import java.awt.dnd.DragGestureListener;
import java.awt.dnd.DragSource;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

public class StudentEditorController implements IController, DragGestureListener
{

  private final CourseValidator courseValidator;
  private final StudentEditorView view;

  private final StudentPlanService service;
  private final CourseService courseService;
  private final TermService termService;
  private final ComponentRouter router;

  private final HashSet<AcademicTerm> selectedTerms;

  private boolean isSaved;

  private final ResourceBundle strings =
      ResourceBundle.getBundle("Strings", Locale.getDefault(), this.getClass().getClassLoader());

  public StudentEditorController(StudentPlanService service, TermService termService,
      CourseService courseService, ComponentRouter router)
  {
    this.router = router;
    this.service = service;
    this.termService = termService;
    this.courseService = courseService;
    this.view = new StudentEditorView(this);
    this.selectedTerms = new HashSet<>();
    this.courseValidator = new CourseValidator();
    this.isSaved = true;
  }

  public void addTerm()
  {
    var notUsed = termService.getAll().stream().filter(t -> !selectedTerms.contains(t))
        .collect(Collectors.toList());
    AddTermDialog addTermDialog = new AddTermDialog(getView(), notUsed);
    if (addTermDialog.show() == JOptionPane.OK_OPTION)
    {
      var term = addTermDialog.get();
      if (term == null)
        return;
      service.getPlan().getCourseMap().put(term, new ArrayList<>());
      selectedTerms.add(term);
      isSaved = false;
      this.view.setEditor(service.getPlan(), isSaved);
    }
  }

  @Override public boolean canDeactivate()
  {
    view.disableAllOpts();
    return true;
  }

  public void close()
  {

    boolean shouldClose = isSaved
        || JOptionPane.showConfirmDialog(view, strings.getString("Save_Confirmation_Dialog"))
        == JOptionPane.OK_OPTION;
    if (shouldClose)
    {
      this.service.setPlan(null);
      this.view.clearEditor();
      this.selectedTerms.clear();
      this.isSaved = true;
      this.router.changeRoute(RouteConstants.DASHBOARD_ROUTE, RouteConstants.CLOSE_PLAN);
    }

  }

  @Override public void dragGestureRecognized(DragGestureEvent e)
  {
    Cursor cursor = null;
    CourseCard card = (CourseCard) e.getComponent();

    Course course = card.getCourse();
    if (e.getDragAction() == DnDConstants.ACTION_COPY)
    {
      cursor = DragSource.DefaultCopyDrop;
    }
    e.startDrag(cursor, new CourseTransferable(card.getCurrentTerm(), course));
  }

  public void exportToTrack()
  {
    JFileChooser fileChooser = new JFileChooser();
    fileChooser.setDialogTitle(strings.getString("Export_Plan_Data"));
    fileChooser.setAcceptAllFileFilterUsed(false);
    fileChooser.setFileFilter(new FileTypeFilter(FileTypeFilter.JSON_DATA, "JSON File (*.json)"));
    if (fileChooser.showSaveDialog(getView()) == JFileChooser.APPROVE_OPTION)
    {
      JSONFileUtility.exportJSONData(fileChooser.getSelectedFile().getPath(), service);
    }
  }

  @Override public JPanel getView()
  {
    return view;
  }

  public void moveCourse(AcademicTerm newTerm, Course c)
  {
    // this seems redundant but the drag effects the reference
    // c != course
    var course = courseService.get(c.getId());

    var map = service.getPlan().getCourseMap();
    map.forEach((k, v) -> v.removeIf(temp -> c.getId().equals(temp.getId())));
    map.get(newTerm).add(course);

    isSaved = false;
    this.view.setEditor(service.getPlan(), isSaved);
  }

  @Override public void onInit()
  {
    if (service.getPlan() == null)
      return;
    this.selectedTerms.addAll(
        service.getPlan().getCourseMap().keySet().stream().map(t -> termService.get(t.getId()))
            .collect(Collectors.toList()));
    this.view.setEditor(service.getPlan(), isSaved);
    this.view.buildEditorTree(service.getPlan());
  }

  public void printChecklist()
  {
    if (service.getPlan() != null)
    {
      this.router.changeRoute(RouteConstants.PRINT_CHECKLIST);
    }
  }

  public void printPlanOfStudy()
  {
    if (service.getPlan() != null)
    {
      this.router.changeRoute(RouteConstants.PRINT_PLAN);
    }
  }

  public void removeCourse(Course c)
  {
    var map = service.getPlan().getCourseMap();
    map.forEach((k, v) -> v.removeIf(temp -> c.getId().equals(temp.getId())));
    isSaved = false;
    this.view.setEditor(service.getPlan(), isSaved);
  }

  public void removeTerm(AcademicTerm t)
  {
    var map = service.getPlan().getCourseMap();
    var opt = map.keySet().stream().filter(temp -> temp.getId().equals(t.getId())).findFirst();
    opt.ifPresent(map::remove);
    opt.ifPresent(selectedTerms::remove);
    isSaved = false;
    this.view.setEditor(service.getPlan(), isSaved);
  }

  public void save()
  {
    JFileChooser fileChooser = new JFileChooser();
    fileChooser.setDialogTitle(strings.getString("Save_Student_Plan"));
    fileChooser.setAcceptAllFileFilterUsed(false);
    fileChooser.setFileFilter(new FileTypeFilter(".plan", "Student Plan"));
    if (fileChooser.showOpenDialog(getView()) == JFileChooser.APPROVE_OPTION)
    {
      ModelSerializer.saveStudentPlan(fileChooser.getSelectedFile().getPath(), service);
      this.isSaved = true;
      this.view.disableSave();
    }
  }

  public String validateCourse(Course course, AcademicTerm selectedTerm)
  {
    return this.courseValidator.isValid(course, selectedTerm, service.getPlan().getCourseMap()) ?
        null : this.courseValidator.getValidationErrorMessage();
  }
}
