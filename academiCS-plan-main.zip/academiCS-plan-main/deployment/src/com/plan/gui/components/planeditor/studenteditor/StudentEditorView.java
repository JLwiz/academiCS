package com.plan.gui.components.planeditor.studenteditor;

import com.plan.core.conf.StringLocalizer;
import com.plan.core.models.*;
import com.plan.core.uimodels.AbstractView;
import com.plan.gui.components.planeditor.studenteditor.drag.TreeDragListener;
import com.plan.gui.util.ResourceLoader;
import com.plan.gui.util.Styles;

import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import java.awt.*;
import java.awt.dnd.DnDConstants;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

public class StudentEditorView extends AbstractView<StudentEditorController>
{

  private JPanel rightPane;
  private JTree courseGroupTree;

  private JButton close;
  private JButton save;
  private JButton checkList;
  private JButton plan;
  private JButton exportToTrack;

  private boolean hasErrors;

  /**
   * Constructs an instance of {@code AbstractView} provided
   * an owning controller.
   *
   * @param controller the controller that manages this view
   */
  public StudentEditorView(StudentEditorController controller)
  {
    super(controller);
    buildUI();
  }

  public void buildEditorTree(StudentPlan plan)
  {
    FieldOfStudy fieldOfStudy = plan.getFieldOfStudy();
    List<CourseGroup> groups = fieldOfStudy.getCourseGroups();
    DefaultMutableTreeNode top = new DefaultMutableTreeNode(fieldOfStudy.getName());
    groups.forEach(g -> {
      DefaultMutableTreeNode groupNode = new DefaultMutableTreeNode(g.getTitle());
      g.getCourses().forEach(c -> groupNode.add(new DefaultMutableTreeNode(c)));
      top.add(groupNode);
    });
    courseGroupTree.setModel(new DefaultTreeModel(top));
  }

  public void clearEditor()
  {
    rightPane.removeAll();
    courseGroupTree.setModel(null);
    disableAllOpts();
    SwingUtilities.updateComponentTreeUI(this);
    synchronized (getTreeLock())
    {
      validateTree();
    }
    repaint();
  }

  public void disableAllOpts()
  {
    this.plan.setEnabled(false);
    this.checkList.setEnabled(false);
    this.save.setEnabled(false);
    this.close.setEnabled(false);
    this.exportToTrack.setEnabled(false);
  }

  public void disableSave()
  {
    this.save.setEnabled(false);
  }

  public void setEditor(StudentPlan plan, boolean isSaved)
  {
    if (plan == null)
      return;
    this.hasErrors = false;
    this.save.setEnabled(!isSaved);

    rightPane.removeAll();
    Map<AcademicTerm, List<Course>> courseMap = plan.getCourseMap();
    var sortedTerms =
        courseMap.keySet().stream().sorted(Comparator.comparing(AcademicTerm::getStartDate));
    sortedTerms.forEach(t -> {
      var tc = new TermCard(t, controller);
      courseMap.get(t).forEach(c -> {
        if (tc.addCourse(t, c))
          hasErrors = true;
      });
      rightPane.add(tc);
    });
    this.setOptsEnabled(!hasErrors);
    this.close.setEnabled(true);
    JButton newTerm = new JButton("+");
    newTerm.addActionListener(l -> controller.addTerm());
    rightPane.add(newTerm);

    SwingUtilities.updateComponentTreeUI(this);
    synchronized (getTreeLock())
    {
      validateTree();
    }
    repaint();
  }

  public void setOptsEnabled(boolean enabled)
  {
    this.plan.setEnabled(enabled);
    this.checkList.setEnabled(enabled);
    this.exportToTrack.setEnabled(enabled);
  }

  private void buildUI()
  {
    setLayout(new BorderLayout());
    JToolBar toolBar = new JToolBar();

    close = new JButton(ResourceLoader.createInstance().getIcon(this, "icons/close.png"));
    close.setText(StringLocalizer.getInstance().getString("Close"));
    close.setVerticalTextPosition(SwingConstants.BOTTOM);
    close.setHorizontalTextPosition(SwingConstants.CENTER);
    close.setToolTipText(StringLocalizer.getInstance().getString("Close_Plan"));
    close.addActionListener(l -> controller.close());
    close.setEnabled(false);
    toolBar.add(close);

    save = new JButton(ResourceLoader.createInstance().getIcon(this, "icons/save.png"));
    save.setToolTipText(StringLocalizer.getInstance().getString("Save_as"));
    save.setText(StringLocalizer.getInstance().getString("Save"));
    save.setVerticalTextPosition(SwingConstants.BOTTOM);
    save.setHorizontalTextPosition(SwingConstants.CENTER);
    save.addActionListener(l -> controller.save());
    save.setEnabled(false);
    toolBar.add(save);

    exportToTrack = new JButton(ResourceLoader.createInstance().getIcon(this, "icons/export.png"));
    exportToTrack.setToolTipText(StringLocalizer.getInstance().getString("Export_To_Track"));
    exportToTrack.setText(StringLocalizer.getInstance().getString("Export"));
    exportToTrack.setVerticalTextPosition(SwingConstants.BOTTOM);
    exportToTrack.setHorizontalTextPosition(SwingConstants.CENTER);
    exportToTrack.addActionListener(l -> controller.exportToTrack());
    exportToTrack.setEnabled(false);
    toolBar.add(exportToTrack);

    checkList = new JButton(ResourceLoader.createInstance().getIcon(this, "icons/ck.png"));
    checkList.setToolTipText(StringLocalizer.getInstance().getString("View_Graduation_Checklist"));
    checkList.setText(StringLocalizer.getInstance().getString("Checklist"));
    checkList.setVerticalTextPosition(SwingConstants.BOTTOM);
    checkList.setHorizontalTextPosition(SwingConstants.CENTER);
    checkList.addActionListener(l -> controller.printChecklist());
    checkList.setEnabled(false);
    toolBar.add(checkList);

    plan = new JButton(ResourceLoader.createInstance().getIcon(this, "icons/plan.png"));
    plan.setToolTipText(StringLocalizer.getInstance().getString("View_Plan_Of_Study"));
    plan.setText(StringLocalizer.getInstance().getString("Plan"));
    plan.setVerticalTextPosition(SwingConstants.BOTTOM);
    plan.setHorizontalTextPosition(SwingConstants.CENTER);
    plan.addActionListener(l -> controller.printPlanOfStudy());
    plan.setEnabled(false);
    toolBar.add(plan);

    add(toolBar, BorderLayout.NORTH);
    courseGroupTree = new JTree(null, false);
    new TreeDragListener(courseGroupTree, DnDConstants.ACTION_COPY_OR_MOVE);
    JPanel leftPane = new JPanel();
    leftPane.setLayout(new BorderLayout());
    leftPane.setBackground(Color.WHITE);
    leftPane.setBorder(BorderFactory.createEmptyBorder(3, 5, 0, 0));
    leftPane.add(courseGroupTree);

    JScrollPane leftScroll = new JScrollPane(leftPane);
    leftScroll.setPreferredSize(new Dimension(200, 1));
    leftScroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
    leftScroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);

    rightPane = new JPanel();
    rightPane.setBorder(Styles.DEFAULT_PADDING);
    rightPane.setLayout(new BoxLayout(rightPane, BoxLayout.X_AXIS));

    JScrollPane rightScroll = new JScrollPane(rightPane);

    rightScroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
    rightScroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);

    JPanel rightWrapper = new JPanel(new GridLayout(1, 0));
    rightWrapper.setMaximumSize(new Dimension(100, 100));
    rightWrapper.setPreferredSize(new Dimension(100, 100));
    rightWrapper.add(rightScroll);
    JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftScroll, rightWrapper);
    splitPane.setOneTouchExpandable(true);
    add(splitPane);
  }
}
