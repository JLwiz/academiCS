package com.plan.gui.components.planeditor.studenteditor;

import com.plan.core.models.AcademicTerm;
import com.plan.core.models.Course;
import com.plan.gui.components.planeditor.studenteditor.drag.CourseTargetListener;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DragSource;
import java.util.Locale;
import java.util.ResourceBundle;

public class TermCard extends JPanel
{

  private static final Border TERM_PADDING = BorderFactory.createEmptyBorder(0, 5, 5, 10);
  private static final Border PADDING = BorderFactory.createEmptyBorder(5, 5, 5, 5);

  private final JPanel contentArea;
  private final AcademicTerm term;

  private final StudentEditorController controller;

  private final ResourceBundle strings =
      ResourceBundle.getBundle("Strings", Locale.getDefault(), this.getClass().getClassLoader());

  public TermCard(AcademicTerm term, StudentEditorController controller)
  {
    this.term = term;
    this.controller = controller;
    setLayout(new BorderLayout());
    setBorder(TERM_PADDING);
    setMaximumSize(new Dimension(250, Integer.MAX_VALUE));
    setMinimumSize(new Dimension(250, 1));

    JPanel termWrapper = new JPanel();
    termWrapper.setLayout(new BorderLayout());
    termWrapper.setBorder(BorderFactory.createLineBorder(Color.BLACK));
    JPanel titleWrapper = new JPanel(new BorderLayout());

    JButton button = new JButton(term.getTitle());
    JPopupMenu popup = new JPopupMenu();
    JMenuItem menuItem = new JMenuItem(strings.getString("Remove_term"));
    menuItem.addActionListener(l -> controller.removeTerm(term));
    popup.add(menuItem);
    button.addActionListener(l -> popup.show(button, 0, button.getHeight()));
    titleWrapper.add(button);
    termWrapper.add(titleWrapper, BorderLayout.NORTH);

    contentArea = new JPanel();
    contentArea.setBorder(PADDING);
    contentArea.setLayout(new BoxLayout(contentArea, BoxLayout.Y_AXIS));
    termWrapper.add(contentArea, BorderLayout.CENTER);

    add(termWrapper);
    new CourseTargetListener(this);
  }

  public boolean addCourse(AcademicTerm term, Course course)
  {
    boolean errorOccurred = false;
    CourseCard courseCard = new CourseCard(term, course, controller);
    DragSource ds = new DragSource();
    ds.createDefaultDragGestureRecognizer(courseCard, DnDConstants.ACTION_COPY, controller);
    var error = controller.validateCourse(course, term);
    if (error != null)
    {
      courseCard.setError(error);
      errorOccurred = true;
    }
    contentArea.add(courseCard);
    return errorOccurred;
  }

  public void notifyControllerOfDropEvent(Course course)
  {
    controller.moveCourse(term, course);
  }
}
