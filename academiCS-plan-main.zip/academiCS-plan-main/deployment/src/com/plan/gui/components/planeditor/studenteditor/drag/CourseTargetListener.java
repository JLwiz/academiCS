package com.plan.gui.components.planeditor.studenteditor.drag;

import com.plan.core.models.Course;
import com.plan.gui.components.planeditor.studenteditor.TermCard;

import java.awt.datatransfer.Transferable;
import java.awt.dnd.*;

public class CourseTargetListener implements DropTargetListener
{

  private final TermCard termCard;

  public CourseTargetListener(TermCard panel)
  {
    this.termCard = panel;
    new DropTarget(panel, DnDConstants.ACTION_COPY, this, true, null);
  }

  @Override public void dragEnter(DropTargetDragEvent event)
  {

  }

  @Override public void dragExit(DropTargetEvent event)
  {

  }

  @Override public void dragOver(DropTargetDragEvent event)
  {

  }

  @Override public void drop(DropTargetDropEvent event)
  {
    try
    {
      Transferable tr = event.getTransferable();
      Course course = (Course) tr.getTransferData(CourseTransferable.courseFlavor);
      if (event.isDataFlavorSupported(CourseTransferable.courseFlavor))
      {
        event.acceptDrop(DnDConstants.ACTION_COPY);
        this.termCard.notifyControllerOfDropEvent(course);
        event.dropComplete(true);
        return;
      }
      event.rejectDrop();
    }
    catch (Exception e)
    {
      e.printStackTrace();
      event.rejectDrop();
    }
  }

  @Override public void dropActionChanged(DropTargetDragEvent event)
  {

  }

}
