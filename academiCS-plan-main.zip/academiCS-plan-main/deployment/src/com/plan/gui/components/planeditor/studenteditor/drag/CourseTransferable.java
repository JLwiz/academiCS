package com.plan.gui.components.planeditor.studenteditor.drag;

import com.plan.core.models.AcademicTerm;
import com.plan.core.models.Course;

import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;

public class CourseTransferable implements Transferable
{
  public static final DataFlavor courseFlavor = new DataFlavor(Course.class, "A Course");
  private static final DataFlavor[] supportedFlavors = {courseFlavor};

  private final Course course;
  private final AcademicTerm currentTerm;

  public CourseTransferable(AcademicTerm currentTerm, Course course)
  {
    this.currentTerm = currentTerm;
    this.course = course;
  }

  @Override public Course getTransferData(DataFlavor flavor) throws UnsupportedFlavorException
  {
    if (flavor.equals(courseFlavor))
    {
      return course;
    }
    else
      throw new UnsupportedFlavorException(flavor);
  }

  @Override public DataFlavor[] getTransferDataFlavors()
  {
    return supportedFlavors;
  }

  @Override public boolean isDataFlavorSupported(DataFlavor flavor)
  {
    return flavor.equals(courseFlavor);
  }

  public AcademicTerm oldTerm()
  {
    return currentTerm;
  }
}
