package com.plan.gui.components.planeditor.studenteditor.drag;

import com.plan.core.models.Course;

import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;
import java.awt.dnd.DragGestureEvent;
import java.awt.dnd.DragGestureListener;
import java.awt.dnd.DragGestureRecognizer;
import java.awt.dnd.DragSource;

public class TreeDragListener implements DragGestureListener
{
  DragSource source;

  DragGestureRecognizer recognizer;

  JTree sourceTree;

  public TreeDragListener(JTree tree, int actions)
  {
    sourceTree = tree;
    source = new DragSource();
    recognizer = source.createDefaultDragGestureRecognizer(sourceTree, actions, this);
  }

  @Override public void dragGestureRecognized(DragGestureEvent dge)
  {
    TreePath path = sourceTree.getSelectionPath();
    if ((path == null) || (path.getPathCount() <= 1))
    {
      return;
    }
    DefaultMutableTreeNode selectedNode =
        (DefaultMutableTreeNode) sourceTree.getLastSelectedPathComponent();
    Course c = (Course) selectedNode.getUserObject();
    dge.startDrag(DragSource.DefaultCopyDrop, new CourseTransferable(null, c));
  }

}
