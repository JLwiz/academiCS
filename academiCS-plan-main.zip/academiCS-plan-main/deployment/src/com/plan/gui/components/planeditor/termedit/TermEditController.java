package com.plan.gui.components.planeditor.termedit;

import com.plan.core.models.AcademicTerm;
import com.plan.core.models.Course;
import com.plan.core.models.TermType;
import com.plan.core.services.CourseService;
import com.plan.core.services.TermService;
import com.plan.core.uimodels.IController;
import com.plan.gui.routing.ComponentRouter;
import com.plan.gui.routing.RouteConstants;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.util.List;
import java.util.UUID;

public class TermEditController implements IController, DocumentListener
{

  private final TermEditView view;
  private final TermService termService;
  private final CourseService courseService;
  private final ComponentRouter router;

  private boolean hasBeenEdited;

  public TermEditController(final TermService termService, final CourseService courseService,
      final ComponentRouter router)
  {
    this.courseService = courseService;
    view = new TermEditView(this);
    this.termService = termService;
    this.router = router;

  }

  @Override public boolean canDeactivate()
  {
    return !this.hasBeenEdited;
  }

  @Override public void changedUpdate(DocumentEvent e)
  {

  }

  public CourseService getCourseService()
  {
    return this.courseService;
  }

  @Override public JPanel getView()
  {
    return view;
  }

  @Override public void insertUpdate(DocumentEvent e)
  {
    this.hasBeenEdited = true;
    this.view.enableSave();
  }

  @Override public void onInit()
  {
    this.view.resetForm();
    if (router.getActiveParams() != null && router.getActiveParams().length > 0)
    {
      AcademicTerm loadedTerm = this.termService.get(router.getActiveParams()[0]);
      if (loadedTerm == null)
      {
        this.hasBeenEdited = false; // force route change
        this.router.changeRoute(RouteConstants.TERM_SEARCH);
      }
      else
      {
        this.view.setForm(loadedTerm);
      }
    }
    this.hasBeenEdited = false;
    this.view.setFocus();
  }

  @Override public void removeUpdate(DocumentEvent e)
  {
    this.hasBeenEdited = true;
    this.view.enableSave();
  }

  public void save(String title, TermType termType, long startDate, long endDate,
      List<Course> actual, List<Course> planned)
  {
    AcademicTerm academicTerm;
    if (router.getActiveParams() != null && router.getActiveParams().length > 0)
    {
      academicTerm = termService.get(router.getActiveParams()[0]);
    }
    else
    {
      academicTerm = new AcademicTerm(UUID.randomUUID().toString(), System.currentTimeMillis());
    }
    academicTerm.setTitle(title);
    academicTerm.setTermType(termType);
    academicTerm.setStartDate(startDate);
    academicTerm.setEndDate(endDate);
    academicTerm.setActualCourses(actual);
    academicTerm.setIntendedCourses(planned);

    this.termService.create(academicTerm);
    this.hasBeenEdited = false;
    this.router.changeRoute(RouteConstants.TERM_SEARCH);
  }
}
