package com.plan.gui.components.planeditor.termedit;

import com.plan.core.conf.StringLocalizer;
import com.plan.core.models.AcademicTerm;
import com.plan.core.models.TermType;
import com.plan.core.uimodels.AbstractView;
import com.plan.gui.components.reusuable.CourseSelectionList;
import com.plan.gui.util.FormUtil;
import com.plan.gui.util.Styles;

import javax.swing.*;
import java.awt.*;
import java.text.SimpleDateFormat;

public class TermEditView extends AbstractView<TermEditController>
{

  private JTextField termTitleField;
  private JComboBox<TermType> termTypeField;
  private JFormattedTextField startDateField;
  private JFormattedTextField endDateField;

  private JButton saveButton;

  private CourseSelectionList actualCourses;
  private CourseSelectionList plannedCourses;

  private JLabel pageTitle;
  private boolean isNew;

  public TermEditView(TermEditController controller)
  {
    super(controller);
    buildUI();
  }

  public void enableSave()
  {
    saveButton.setEnabled(true);
  }

  public boolean isFormValid()
  {
    boolean b = FormUtil.isValidText(termTitleField, 1);
    boolean b1 = FormUtil.isValidText(startDateField, 1);
    boolean b2 = FormUtil.isValidText(endDateField, 1);

    return b && b1 && b2;
  }

  public void resetForm()
  {
    this.isNew = true;
    this.pageTitle.setText(StringLocalizer.getInstance().getString("Create_Term"));

    this.actualCourses.reset();
    this.plannedCourses.reset();

    termTitleField.setText("");
    termTitleField.setBorder(Styles.DEFAULT_BORDER);
    termTypeField.getModel().setSelectedItem(TermType.SEMESTER);
    startDateField.setText("");
    startDateField.setBorder(Styles.DEFAULT_BORDER);
    endDateField.setText("");
    endDateField.setBorder(Styles.DEFAULT_BORDER);

    saveButton.setEnabled(false);
  }

  public void setFocus()
  {
    termTitleField.requestFocus();
  }

  public void setForm(AcademicTerm t)
  {
    this.isNew = false;
    this.pageTitle.setText(StringLocalizer.getInstance().getString("Edit_Term"));
    actualCourses.setSelectedCourses(t.getActualCourses());
    plannedCourses.setSelectedCourses(t.getIntendedCourses());

    termTitleField.setText(t.getTitle());
    termTypeField.setBorder(Styles.DEFAULT_BORDER);
    termTypeField.getModel().setSelectedItem(t.getTermType());
    startDateField.setText(FormUtil.getDateString(t.getStartDate()));
    startDateField.setBorder(Styles.DEFAULT_BORDER);
    endDateField.setText(FormUtil.getDateString(t.getEndDate()));
    endDateField.setBorder(Styles.DEFAULT_BORDER);

    saveButton.setEnabled(true);
  }

  private JPanel addCourseList(CourseSelectionList list, String label)
  {
    JPanel row = new JPanel(new BorderLayout());
    row.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
    row.add(new JLabel(label), BorderLayout.NORTH);
    row.add(list, BorderLayout.CENTER);
    return row;
  }

  private JPanel addFormField(JComponent field, String label)
  {
    JPanel row = new JPanel();
    row.setLayout(new BoxLayout(row, BoxLayout.X_AXIS));
    row.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
    JPanel codeWrapper = new JPanel(new BorderLayout());
    codeWrapper.add(new JLabel(label), BorderLayout.NORTH);
    field.setMaximumSize(Styles.TEXT_FIELD_SIZE);
    field.setFont(Styles.DEFAULT_TEXT_FIELD_SIZE);
    codeWrapper.add(field);
    row.add(codeWrapper);
    row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 75));
    return row;
  }

  private void buildUI()
  {
    setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
    setBorder(Styles.DEFAULT_PADDING);

    JPanel titleRow = new JPanel();
    titleRow.setLayout(new BoxLayout(titleRow, BoxLayout.X_AXIS));
    pageTitle =
        new JLabel(StringLocalizer.getInstance().getString("Edit_Term"), SwingConstants.LEFT);
    pageTitle.setFont(Styles.DEFAULT_HEADER_SIZE);
    pageTitle.setMaximumSize(Styles.TEXT_FIELD_SIZE);
    titleRow.add(pageTitle);
    add(titleRow);

    termTitleField = new JTextField();
    termTitleField.getDocument().addDocumentListener(controller);
    add(addFormField(termTitleField, StringLocalizer.getInstance().getString("Term_Title")));

    termTypeField = new JComboBox<>();
    termTypeField.addItem(TermType.SEMESTER);
    termTypeField.addItem(TermType.TRIMESTER);
    termTypeField.addItem(TermType.QUARTER);
    termTypeField.addItem(TermType.SUMMER_SESSION);
    termTypeField.addItem(TermType.WINTER_SESSION);
    add(addFormField(termTypeField, StringLocalizer.getInstance().getString("Term_Type")));

    startDateField = new JFormattedTextField(new SimpleDateFormat("yyyy-MM-dd"));
    startDateField.getDocument().addDocumentListener(controller);
    add(addFormField(startDateField, StringLocalizer.getInstance().getString("Term_Start_Date")));

    endDateField = new JFormattedTextField(new SimpleDateFormat("yyyy-MM-dd"));
    endDateField.getDocument().addDocumentListener(controller);
    add(addFormField(endDateField, StringLocalizer.getInstance().getString("Term_End_Date")));

    actualCourses = new CourseSelectionList(controller.getCourseService());
    plannedCourses = new CourseSelectionList(controller.getCourseService());
    actualCourses.setScheduleVisible(true);
    plannedCourses.setScheduleVisible(true);

    add(addCourseList(actualCourses,
        StringLocalizer.getInstance().getString("Actual_Course_Offerings")));
    add(addCourseList(plannedCourses,
        StringLocalizer.getInstance().getString("Planned_Course_Offerings")));

    JPanel submitRow = new JPanel();
    submitRow.setLayout(new BoxLayout(submitRow, BoxLayout.X_AXIS));
    submitRow.add(Box.createHorizontalGlue());
    saveButton = new JButton(StringLocalizer.getInstance().getString("Save"));
    saveButton.setEnabled(true);
    saveButton.addActionListener(e -> {
      if (isFormValid())
        controller.save(termTitleField.getText(), (TermType) termTypeField.getSelectedItem(),
            FormUtil.getDateFromString(startDateField.getText()),
            FormUtil.getDateFromString(endDateField.getText()), actualCourses.getSelectedCourses(),
            plannedCourses.getSelectedCourses());
    });
    submitRow.add(saveButton);

    add(submitRow);
  }
}
