package com.plan.gui.components.planeditor.terminfo;

import com.plan.core.conf.StringLocalizer;
import com.plan.core.models.AcademicTerm;
import com.plan.core.models.auth.UserType;
import com.plan.core.services.TermService;
import com.plan.core.services.auth.AuthService;
import com.plan.core.uimodels.IController;
import com.plan.gui.routing.ComponentRouter;
import com.plan.gui.routing.RouteConstants;

import javax.swing.*;

public class TermInfoController implements IController
{

  private final AuthService authService;

  private final TermInfoView view;

  private final TermService service;
  private final ComponentRouter router;

  public TermInfoController(final AuthService authService, TermService service,
      ComponentRouter router)
  {
    this.authService = authService;
    this.service = service;
    this.router = router;
    view = new TermInfoView(this);
  }

  public void deleteTerm()
  {
    boolean delete = JOptionPane.showConfirmDialog(null,
        StringLocalizer.getInstance().getString("Term_Delete_Confirmation"))
        == JOptionPane.OK_OPTION;
    if (delete)
    {
      this.service.delete(router.getActiveParams()[0]);
      this.router.changeRoute(RouteConstants.TERM_SEARCH);
    }
  }

  public void editTerm()
  {
    this.router.changeRoute(RouteConstants.TERM_EDIT, router.getActiveParams());
  }

  @Override public JPanel getView()
  {
    return view;
  }

  @Override public void onInit()
  {
    if (router.getActiveParams() == null || router.getActiveParams().length == 0)
    {
      this.router.changeRoute(RouteConstants.TERM_SEARCH);
      return;
    }

    AcademicTerm course = service.get(router.getActiveParams()[0]);
    if (course == null)
    {
      this.router.changeRoute(RouteConstants.TERM_SEARCH);
      return;
    }
    this.view.enableAdmin(authService.getUserType() == UserType.ADMIN);
    view.setTerm(course);
  }
}
