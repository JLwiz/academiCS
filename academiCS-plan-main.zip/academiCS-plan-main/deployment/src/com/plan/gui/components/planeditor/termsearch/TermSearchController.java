package com.plan.gui.components.planeditor.termsearch;

import com.plan.core.services.TermService;
import com.plan.core.uimodels.IController;
import com.plan.gui.routing.ComponentRouter;
import com.plan.gui.routing.RouteConstants;

import javax.swing.*;
import java.util.stream.Collectors;

public class TermSearchController implements IController
{

  private final TermSearchView view;
  private final TermService service;
  private final ComponentRouter router;

  public TermSearchController(final TermService service, final ComponentRouter router)
  {
    this.service = service;
    this.router = router;
    this.view = new TermSearchView(this);
  }

  @Override public boolean canDeactivate()
  {
    return true;
  }

  @Override public JPanel getView()
  {
    return view;
  }

  @Override public void onInit()
  {
    view.setTable(service.getAll());
    view.setFocus();
  }

  public void search(String title)
  {
    view.setTable(service.getAll().stream()
        .filter(t -> t.getTitle().toLowerCase().contains(title.toLowerCase()))
        .collect(Collectors.toList()));
  }

  public void select(String id)
  {
    this.router.changeRoute(RouteConstants.TERM_VIEW, id);
  }
}
