package com.plan.gui.components.planeditor.termsearch;

import com.plan.core.models.AcademicTerm;
import com.plan.core.uimodels.AbstractView;
import com.plan.gui.util.FormUtil;
import com.plan.gui.util.Styles;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.Collection;
import java.util.Vector;

public class TermSearchView extends AbstractView<TermSearchController>
{

  private JTextField termTitleField;
  private JTable searchTable;

  public TermSearchView(TermSearchController controller)
  {
    super(controller);
    buildUI();
  }

  public void setFocus()
  {
    termTitleField.requestFocus();
  }

  public void setTable(Collection<AcademicTerm> terms)
  {
    Vector<String> headers = new Vector<>();
    headers.add("Term ID");
    headers.add("Term Title");
    headers.add("Term Type");
    headers.add("Term Start Date");
    headers.add("Term End Date");

    Vector<Vector<String>> data = new Vector<>();
    for (AcademicTerm term : terms)
    {
      Vector<String> d = new Vector<>();
      d.add(term.getId());
      d.add(term.getTitle());
      d.add(term.getTermType().toString());
      d.add(FormUtil.getDateString(term.getStartDate()));
      d.add(FormUtil.getDateString(term.getEndDate()));
      data.add(d);
    }
    DefaultTableModel model = new DefaultTableModel(data, headers);
    searchTable.setModel(model);

  }

  private void buildUI()
  {
    setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
    setBorder(Styles.DEFAULT_PADDING);

    JPanel titleRow = new JPanel();
    titleRow.setLayout(new BoxLayout(titleRow, BoxLayout.X_AXIS));
    JLabel title = new JLabel("Term Search", SwingConstants.LEFT);
    title.setFont(Styles.DEFAULT_HEADER_SIZE);
    title.setMaximumSize(Styles.TEXT_FIELD_SIZE);
    titleRow.add(title);
    add(titleRow);

    JPanel rowOne = new JPanel();
    rowOne.setLayout(new BoxLayout(rowOne, BoxLayout.X_AXIS));
    rowOne.setBorder(BorderFactory.createEmptyBorder(5, 0, 20, 0));

    JPanel termTitleWrapper = new JPanel(new BorderLayout());
    termTitleWrapper.add(new JLabel("Term Title"), BorderLayout.NORTH);
    termTitleField = new JTextField();
    termTitleField.addActionListener(e -> controller.search(termTitleField.getText()));
    termTitleField.setMaximumSize(Styles.TEXT_FIELD_SIZE);
    termTitleField.setFont(Styles.DEFAULT_TEXT_FIELD_SIZE);
    termTitleWrapper.add(termTitleField);
    rowOne.add(termTitleWrapper);
    rowOne.setMaximumSize(new Dimension(Integer.MAX_VALUE, 300));
    add(rowOne);

    searchTable = new JTable()
    {
      @Override public boolean isCellEditable(int rowIndex, int colIndex)
      {
        return false; //Disallow the editing of any cell
      }
    };
    searchTable.getTableHeader().setReorderingAllowed(false);
    searchTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    searchTable.getSelectionModel().addListSelectionListener(l -> {
      if (!l.getValueIsAdjusting() && searchTable.getSelectedRow() >= 0)
      {
        controller.select(searchTable.getValueAt(searchTable.getSelectedRow(), 0).toString());
        searchTable.clearSelection();
      }
    });
    add(new JScrollPane(searchTable));
  }

}
