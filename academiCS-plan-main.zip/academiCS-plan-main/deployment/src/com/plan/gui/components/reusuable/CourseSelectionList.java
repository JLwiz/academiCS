package com.plan.gui.components.reusuable;

import com.plan.core.io.XMLFileUtility;
import com.plan.core.models.Course;
import com.plan.core.services.CourseService;
import com.plan.gui.util.ResourceLoader;
import com.plan.gui.util.Styles;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Vector;
import java.util.stream.Collectors;

public class CourseSelectionList extends JPanel
{

  private final CourseService service;
  private final Vector<String> toValues;
  private final Vector<String> fromValues;
  private JList<String> toList;
  private JList<String> fromList;
  private JTextField toSearchField;
  private boolean hasDataBeenImported;

  private boolean scheduleVisible;
  private final JButton importScheduleButton;
  private JPanel fromActions;

  public CourseSelectionList(CourseService service)
  {
    this.service = service;
    this.toValues = new Vector<>();
    this.fromValues = new Vector<>();
    importScheduleButton = new JButton("Import Schedule");
    importScheduleButton.setVisible(false);
    scheduleVisible = false;
    buildList();
  }

  public void addToSelected(String s)
  {
    if (s == null || !toValues.contains(s))
      return;
    this.fromValues.add(s);
    this.toValues.remove(s);
    reloadLists();
  }

  public List<Course> getSelectedCourses()
  {
    if (fromValues.size() == 0)
      return null;
    return this.fromValues.stream().map(s -> this.service.get(s.split(":")[0]))
        .collect(Collectors.toList());
  }

  public void setSelectedCourses(List<Course> selectedCourses)
  {
    if (selectedCourses == null)
      return;
    selectedCourses.forEach(c -> {
      var v = c.getId() + ": " + c.getTitle();
      if (toValues.contains(v))
      {
        addToSelected(v);
      }
    });
    reloadLists();
  }

  public List<Course> getUnselectedCourses()
  {
    if (toValues.size() == 0)
      return new ArrayList();
    return this.toValues.stream().map(s -> this.service.get(s.split(":")[0]))
        .collect(Collectors.toList());
  }

  /**
   * @param selectedCourses
   */
  public void setUnselectedCourses(final List<Course> selectedCourses)
  {
    if (selectedCourses == null)
      return;
    selectedCourses.forEach(c -> {
      var v = c.getId() + ": " + c.getTitle();
      toValues.add(v);
    });
    reloadLists();
  }

  public void reset()
  {
    this.toValues.clear();
    this.service.getAll().forEach(c -> toValues.add(c.getId() + ": " + c.getTitle()));
    this.fromValues.clear();
    reloadLists();
  }

  /**
   * Sets the import schedule button visible.
   *
   * @param visible
   */
  public void setScheduleVisible(final boolean visible)
  {
    if (importScheduleButton != null)
    {
      scheduleVisible = visible;
      importScheduleButton.setVisible(visible);
    }
  }

  private void addAll()
  {
    if (toValues.size() == 0)
      return;
    this.fromValues.addAll(toValues);
    toValues.clear();
    reloadLists();
  }

  private void buildList()
  {
    setLayout(new BoxLayout(this, BoxLayout.X_AXIS));

    JPanel toContainer = new JPanel();
    toContainer.setBorder(BorderFactory.createTitledBorder(Styles.DEFAULT_BORDER, "Select From"));
    toContainer.setLayout(new BorderLayout());
    JPanel toActions = new JPanel();
    toActions.setLayout(new BoxLayout(toActions, BoxLayout.X_AXIS));
    toActions.setAlignmentX(LEFT_ALIGNMENT);
    toSearchField = new JTextField();
    toSearchField.addActionListener(l -> filter(toSearchField.getText()));
    toActions.add(toSearchField);
    JButton addButton = new JButton("Add");
    addButton.addActionListener(e -> addToSelected(toList.getSelectedValue()));

    JButton addAllBtn = new JButton("Add All");
    addAllBtn.addActionListener(e -> addAll());
    toActions.add(addButton);
    toActions.add(addAllBtn);
    toList = new JList<>();
    toList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    toContainer.add(toActions, BorderLayout.NORTH);
    toContainer.add(new JScrollPane(toList), BorderLayout.CENTER);

    JPanel fromContainer = new JPanel();
    fromContainer
        .setBorder(BorderFactory.createTitledBorder(Styles.DEFAULT_BORDER, "Selected Courses"));
    fromContainer.setLayout(new BorderLayout());
    fromActions = new JPanel();
    fromActions.setLayout(new BoxLayout(fromActions, BoxLayout.X_AXIS));
    fromActions.setAlignmentX(RIGHT_ALIGNMENT);
    JButton removeButton = new JButton("Remove");
    removeButton.addActionListener(e -> removeFromSelected(fromList.getSelectedValue()));
    fromActions.add(removeButton);

    // Add new import Schedule action.
    importScheduleButton
        .addActionListener(e -> XMLFileUtility.importScheduleXML(this, service, fromValues));
    fromActions.add(importScheduleButton);
    //

    fromList = new JList<>();
    fromList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    fromContainer.add(fromActions, BorderLayout.NORTH);
    fromContainer.add(new JScrollPane(fromList), BorderLayout.CENTER);

    JPanel arrow = new JPanel();
    arrow.setBorder(Styles.DEFAULT_PADDING);
    arrow.setLayout(new BoxLayout(arrow, BoxLayout.PAGE_AXIS));

    arrow.add(new JLabel(ResourceLoader.createInstance().getIcon(this, "icons/arrow_forward.png")),
        CENTER_ALIGNMENT);

    add(toContainer);
    add(arrow);
    add(fromContainer);
  }

  private void filter(String query)
  {
    if (query == null || query.length() == 0)
    {
      this.toList.setListData(this.toValues);
    }
    var fi =
        this.toValues.stream().filter(v -> v.toLowerCase().contains(query.toLowerCase(Locale.ROOT)))
            .collect(Collectors.toList());
    this.toList.setListData(new Vector<>(fi));
  }

  private void reloadLists()
  {
    this.fromList.setListData(this.fromValues);
    this.toList.setListData(this.toValues);
    this.toSearchField.setText("");
  }

  private void removeFromSelected(String s)
  {
    if (s == null || !fromValues.contains(s))
      return;
    this.toValues.add(s);
    this.fromValues.remove(s);
    reloadLists();
  }

}
