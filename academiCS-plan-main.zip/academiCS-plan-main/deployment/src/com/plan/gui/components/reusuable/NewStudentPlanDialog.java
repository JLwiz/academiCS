package com.plan.gui.components.reusuable;

import com.plan.core.models.FieldOfStudy;
import com.plan.core.models.StudentPlan;
import com.plan.core.services.FieldOfStudyService;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class NewStudentPlanDialog
{
  private final List<JComponent> components;

  private final String title;
  private final int messageType;
  private final Component rootPane;
  private final String[] options;
  private final JTextField nameField;
  private final JComboBox<FieldOfStudy> fieldOfStudyBox;
  private int optionIndex;

  public NewStudentPlanDialog(Component root, FieldOfStudyService fieldOfStudyService)
  {
    components = new ArrayList<>();

    title = "New Student Plan";
    messageType = JOptionPane.PLAIN_MESSAGE;
    rootPane = root;
    options = new String[] {"Create", "Cancel"};
    setOptionSelection(0);

    addComponent(new JLabel("Plan Name"));
    nameField = new JTextField();
    addComponent(nameField);

    addComponent(new JLabel("Field Of Study"));
    fieldOfStudyBox = new JComboBox<>();
    fieldOfStudyService.getAll().forEach(fos -> fieldOfStudyBox.addItem(fos));
    addComponent(fieldOfStudyBox);
  }

  public void addComponent(JComponent component)
  {
    components.add(component);
  }

  public StudentPlan get()
  {
    StudentPlan plan = new StudentPlan(UUID.randomUUID().toString(), System.currentTimeMillis());
    plan.setPlanName(nameField.getText());
    plan.setFieldOfStudy((FieldOfStudy) fieldOfStudyBox.getSelectedItem());
    return plan;
  }

  public void setOptionSelection(int optionIndex)
  {
    this.optionIndex = optionIndex;
  }

  public int show()
  {
    int optionType = JOptionPane.OK_CANCEL_OPTION;
    Object optionSelection = null;

    if (options.length != 0)
    {
      optionSelection = options[optionIndex];
    }

    return JOptionPane
        .showOptionDialog(rootPane, components.toArray(), title, optionType, messageType, null,
            options, optionSelection);
  }
}
