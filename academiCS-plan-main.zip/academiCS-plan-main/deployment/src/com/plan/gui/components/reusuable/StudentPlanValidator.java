package com.plan.gui.components.reusuable;

import com.plan.core.models.FieldOfStudy;
import com.plan.core.models.StudentPlan;
import com.plan.core.services.CourseGroupService;
import com.plan.core.services.CourseService;
import com.plan.core.services.FieldOfStudyService;
import com.plan.core.services.TermService;

import javax.swing.*;
import java.awt.*;

public class StudentPlanValidator
{

  private static final int MAX_ERRORS_DISPLAYED = 10;

  private final Component root;
  private final CourseService courseService;
  private final TermService termService;
  private final CourseGroupService courseGroupService;
  private final FieldOfStudyService fieldOfStudyService;
  private final StringBuilder errorMsg;
  private int errorCount;

  public StudentPlanValidator(final Component root, final CourseService courseService,
      final TermService termService, final CourseGroupService courseGroupService,
      final FieldOfStudyService fieldOfStudyService)
  {
    this.root = root;
    this.courseService = courseService;
    this.termService = termService;
    this.courseGroupService = courseGroupService;
    this.fieldOfStudyService = fieldOfStudyService;
    this.errorMsg = new StringBuilder();
  }

  public boolean validatePlan(StudentPlan plan)
  {
    if (plan == null || plan.getPlanName() == null || plan.getPlanName().trim().equals("")
        || plan.getFieldOfStudy() == null)
    {
      displayFormErrorDialog();
      return false;
    }
    errorMsg.setLength(0);
    errorCount = 0;

    if (!validateFieldOfStudy(plan) || !validateCourseMap(plan))
    {
      JLabel label = new JLabel("We think you forgot to import data first.");
      JTextArea textArea = new JTextArea();
      textArea.setText(getError());
      textArea.setEditable(false);
      JOptionPane.showOptionDialog(root, new Component[] {label, textArea}, "Resource Error",
          JOptionPane.OK_CANCEL_OPTION, JOptionPane.ERROR_MESSAGE, null, new String[] {"OK"}, null);
      return false;
    }

    return true;
  }

  private void appendErrorMessage(final String resourceTitle)
  {
    errorCount++;
    if (errorCount > MAX_ERRORS_DISPLAYED)
      return;
    errorMsg.append("[WARN] Resource named \"");
    errorMsg.append(resourceTitle);
    errorMsg.append("\" not imported.\n");
  }

  private void displayFormErrorDialog()
  {
    JOptionPane.showMessageDialog(root, "Invalid information, try again.", "Error",
        JOptionPane.ERROR_MESSAGE);
  }

  private String getError()
  {
    if (errorCount > 10)
      errorMsg.append("And ").append(errorCount - MAX_ERRORS_DISPLAYED).append(" other errors.\n");
    return errorMsg.toString();
  }

  private boolean validateCourseGroups(FieldOfStudy fieldOfStudy)
  {
    if (fieldOfStudy.getCourseGroups() == null || fieldOfStudy.getCourseGroups().isEmpty())
      return true;

    boolean valid = true;
    for (var cg : fieldOfStudy.getCourseGroups())
    {
      if (!this.courseGroupService.isIDTaken(cg.getId()))
      {
        appendErrorMessage(cg.getTitle());
        valid = false;
      }
      if (cg.getCourses() == null)
        continue;
      for (var c : cg.getCourses())
      {
        if (!this.courseService.isIDTaken(c.getId()))
        {
          appendErrorMessage(c.getTitle());
          valid = false;
        }
      }
    }
    return valid;
  }

  private boolean validateCourseMap(StudentPlan plan)
  {
    boolean valid = true;
    if (plan.getCourseMap() == null || plan.getCourseMap().isEmpty())
      return true;
    for (var entry : plan.getCourseMap().entrySet())
    {
      if (!termService.isIDTaken(entry.getKey().getId()))
      {
        appendErrorMessage(entry.getKey().getTitle());
        valid = false;
      }
      if (entry.getValue() == null)
        continue;
      for (var c : entry.getValue())
      {
        if (!courseService.isIDTaken(c.getId()))
        {
          appendErrorMessage(c.getTitle());
          valid = false;
        }
      }
    }
    return valid;
  }

  private boolean validateFieldOfStudy(StudentPlan plan)
  {
    boolean valid = true;
    if (!fieldOfStudyService.isIDTaken(plan.getFieldOfStudy().getId()))
    {
      appendErrorMessage(plan.getFieldOfStudy().getName());
      valid = false;
    }

    return validateCourseGroups(plan.getFieldOfStudy()) && valid;
  }
}
