package com.plan.gui.routing;

import com.plan.core.uimodels.IController;
import com.plan.core.uimodels.IGuard;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * {@code ComponentRouter} manages several controllers mapped to {@code String}
 * routes. This router does not swing components rather it prompts controllers
 * to begin setting up and notifies its listeners.
 * <p>
 * Routers can be nested provided there exists sub routes that are not shared
 * by the parent router.
 *
 * @author Ernest Tussey
 * @version 1.0
 * @see RouteChangeListener
 */
public class ComponentRouter
{

  private final Map<String, IController> componentMap;
  private final Map<String, List<IGuard>> guardMap;

  private final List<RouteChangeListener> listeners;

  private String activeRoute;
  private String[] activeParams;

  /**
   * Constructs an instance of ComponentRouter.
   */
  public ComponentRouter()
  {
    this.componentMap = new HashMap<>();
    this.guardMap = new HashMap<>();
    this.listeners = new ArrayList<>();
  }

  /**
   * Adds a listener that implements the {@code RouteChangeListener}
   * interface. If the listener is already registered or the passed value
   * is {@code null} the value is rejected.
   *
   * @param routeChangeListener an instance of {@code RouteChangeListener}
   */
  public void addRouteChangeListener(final RouteChangeListener routeChangeListener)
  {
    if (routeChangeListener == null)
      return;
    if (!listeners.contains(routeChangeListener))
    {
      this.listeners.add(routeChangeListener);
    }
  }

  /**
   * Attempts to change the current route of the router. If a route change
   * is allowed then all listeners are notified that a route change is
   * occurring.
   * <p>
   * A route change cannot occur if the passed parameters are {@code null},
   * the route is not known to the router, the new route is the current route,
   * or if the route is guarded.
   * <p>
   * If a route change occurs the controllers {@code onInit()} method is
   * invoked <b>after</b> the listeners are notified.
   *
   * @param newRoute the new route
   * @param params   optional parameters
   * @return {@code true} if the route change occurred
   */
  public boolean changeRoute(final String newRoute, final String... params)
  {
    if (newRoute == null || !this.componentMap.containsKey(newRoute) || (this.activeRoute != null
        && this.activeRoute.equals(newRoute)) || isGuarded())
      return false;

    this.activeRoute = newRoute;
    this.activeParams = params;

    IController controller = this.componentMap.get(newRoute);
    RouteEvent event = new RouteEvent(newRoute, controller);
    this.listeners.forEach(l -> l.onRouteChange(event));

    controller.onInit();
    return true;
  }

  /**
   * When a call is made to {@code changeRoute()} the user can passed optional
   * parameters to supply the active controller with more information.
   * For example you may passed a model's ID to to the route so that it may be
   * loaded on init.
   * <p>
   * If no active parameters where passed this will return {@code null}.
   *
   * @return the active parameters or {@code null}
   */
  public String[] getActiveParams()
  {
    return this.activeParams;
  }

  /**
   * Returns the active String route. If this router has not active
   * route this will return {@code null}.
   *
   * @return the active {@code String} route or {@code null}
   */
  public String getActiveRoute()
  {
    return this.activeRoute;
  }

  /**
   * Indexes a String route to an instance of {@code IController}. If either the
   * controller or route are null nothing occurs.
   *
   * @param route      the {@code String} route
   * @param controller the route's controller
   * @param guards     optional guards
   */
  public void putRoute(final String route, final IController controller, final IGuard... guards)
  {
    if (route == null || controller == null)
      return;
    this.componentMap.put(route, controller);
    if (guards != null)
      this.guardMap.put(route, List.of(guards));
  }

  /**
   * Removes a route from this router. If the passed route is null nothing
   * occurs.
   *
   * @param route the route to remove.
   */
  public void removeRoute(final String route)
  {
    if (route == null)
      return;
    this.componentMap.remove(route);
    this.guardMap.remove(route);
  }

  /**
   * Removes an listener. Once the listener is removed it will no longer be notified when
   * a route change occurs. If the passed listener is null nothing occurs.
   *
   * @param routeChangeListener the listener to remove.
   */
  public void removeRouteChangeListener(final RouteChangeListener routeChangeListener)
  {
    if (routeChangeListener == null)
      return;
    if (listeners.contains(routeChangeListener))
    {
      this.listeners.remove(routeChangeListener);
    }
  }

  /**
   * Utility method. Checks if the active route can deactivate. This method
   * will always return {@code false} if the active route does not exist
   * or their exists no guards.
   *
   * @return {@code true} if the active route can deactivate
   */
  private boolean isGuarded()
  {
    if (this.activeRoute == null)
      return false;

    for (IGuard g : this.guardMap.get(this.activeRoute))
    {
      if (!g.canDeactivate(this.componentMap.get(this.activeRoute)))
        return true;
    }
    return false;
  }
}
