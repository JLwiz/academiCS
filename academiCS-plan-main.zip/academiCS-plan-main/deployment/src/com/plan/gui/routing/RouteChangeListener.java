package com.plan.gui.routing;

/**
 * This interface can be registered with a {@code ComponentRouter} to be notified
 * when a route change occurs.
 *
 * @author Ernest Tussey
 * @version 1.0
 * @see ComponentRouter
 * @see RouteEvent
 */
public interface RouteChangeListener
{

  /**
   * When a successful route change occurs this method
   * is called passed a non-null RouteEvent.
   *
   * @param e the route event
   */
  void onRouteChange(final RouteEvent e);

}
