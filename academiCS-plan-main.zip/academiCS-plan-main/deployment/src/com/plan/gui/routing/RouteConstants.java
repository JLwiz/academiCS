package com.plan.gui.routing;

/**
 * This class holds all the route constants for Plan to maintain a stable
 * workflow.
 *
 * @author Ernest Tussey
 * @version 1.0
 */
public class RouteConstants
{

  public static final String AUTH = "auth";
  public static final String PLAN_EDITOR = "plane-editor";

  public static final String DASHBOARD_ROUTE = "dashboard";
  public static final String STUDENT_EDITOR = "student-editor";
  public static final String PRINT_CHECKLIST = "print-checklist";
  public static final String PRINT_PLAN = "print-plan";

  public static final String COURSE_SEARCH = "course-search";
  public static final String COURSE_EDIT = "course-edit";
  public static final String COURSE_VIEW = "course-view";

  public static final String TERM_SEARCH = "term-search";
  public static final String TERM_EDIT = "term-edit";
  public static final String TERM_VIEW = "term-view";

  public static final String COURSE_GROUP_SEARCH = "course-group-search";
  public static final String COURSE_GROUP_EDIT = "course-group-edit";
  public static final String COURSE_GROUP_VIEW = "course-group-view";

  public static final String STUDY_SEARCH = "study-search";
  public static final String STUDY_EDIT = "study-edit";
  public static final String STUDY_VIEW = "study-view";

  public static final String CLOSE_PLAN = "close-plan";
}
