package com.plan.gui.routing;

import com.plan.core.uimodels.IController;

/**
 * A {@code RouteEvent} is produced by a {@code ComponentRouter} and
 * passed to all {@code RouteChangeListeners}.
 *
 * @author Ernest Tussey
 * @version 1.0
 * @see ComponentRouter
 * @see RouteChangeListener
 */
public class RouteEvent
{

  private final String routeName;
  private final IController controller;

  /**
   * Construct's an instance {@code RouteEvent} provided a route name
   * and controller.
   *
   * @param routeName  the {@code String} name of the route
   * @param controller the active controller
   */
  public RouteEvent(final String routeName, final IController controller)
  {

    this.routeName = routeName;
    this.controller = controller;
  }

  /**
   * Returns the active controller.
   *
   * @return active controller
   */
  public IController getController()
  {
    return controller;
  }

  /**
   * Returns the active route.
   *
   * @return the active route
   */
  public String getRouteName()
  {
    return routeName;
  }

}
