package com.plan.gui.util;

import javax.swing.*;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

public class FormUtil
{

  public static boolean isValidText(JTextField field, int minLength)
  {
    if (field == null)
      return false;
    if (field.getText().trim().equals("") || field.getText().trim().length() < minLength)
    {
      field.setBorder(Styles.ERROR_BORDER);
      return false;
    }
    field.setBorder(Styles.GOOD_BORDER);
    return true;
  }

  public static boolean isValidInt(JTextField field, int min, int max)
  {
    if (field == null)
      return false;
    try
    {
      int i = Integer.parseInt(field.getText());
      if (i < min || i > max)
      {
        field.setBorder(Styles.ERROR_BORDER);
        return false;
      }
    }
    catch (NumberFormatException e)
    {
      field.setBorder(Styles.ERROR_BORDER);
      return false;
    }
    field.setBorder(Styles.GOOD_BORDER);
    return true;
  }

  public static String getDateString(long time)
  {
    Date date = new Date(time);
    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
    return format.format(date);
  }

  public static long getDateFromString(String dateString)
  {
    LocalDate date = LocalDate.parse(dateString);
    ZoneId zoneId = ZoneId.systemDefault();
    return
        LocalDateTime.of(date.getYear(), date.getMonth(), date.getDayOfMonth(), 0, 0).atZone(zoneId)
            .toEpochSecond() * 1000;
  }
}
