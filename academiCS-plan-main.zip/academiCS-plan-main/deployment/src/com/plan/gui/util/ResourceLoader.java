package com.plan.gui.util;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * A class for loading resources from the file system or a .jar file.
 *
 * @author Prof. David Bernstein, James Madison University
 */
public class ResourceLoader
{
  private static final ResourceLoader INSTANCE = new ResourceLoader();

  private final Map<String, Icon> icons;
  private final Map<String, Image> images;

  /**
   * Default Constructor.
   */
  private ResourceLoader()
  {
    icons = new HashMap<>();

    images = new HashMap<>();
  }

  /**
   * A factory method for constructing a ResourceLoader.
   *
   * @return A ResourceLoader
   */
  public static ResourceLoader createInstance()
  {

    return INSTANCE;
  }

  /**
   * Get an Icon.
   * <p>
   * Note: loadedObject will, most frequently, be a reference to the calling object (i.e., this)
   *
   * @param loadedObject An Object loaded by the appropriate ClassLoader
   * @param name         The name of the Icon
   * @return The Icon
   */
  public Icon getIcon(final Object loadedObject, final String name)
  {
    Icon icon = icons.get(name);

    if (icon == null)
    {
      Image image = getImage(loadedObject, name);
      if (image != null)
      {
        icon = new ImageIcon(image);
        icons.put(name, icon);
      }
    }
    return icon;
  }

  /**
   * Get an Image.
   * <p>
   * Note: loadedObject will, most frequently, be a reference to the calling object (i.e., this)
   *
   * @param loadedObject An Object loaded by the appropriate ClassLoader
   * @param name         The name of the Image
   * @return The Image
   */
  public Image getImage(final Object loadedObject, final String name)
  {
    Image image = images.get(name);

    if (image == null)
    {
      InputStream is = getInputStream(loadedObject, name);
      if (is != null)
      {
        try
        {
          image = ImageIO.read(is);
          if (image != null)
            images.put(name, image);
        }
        catch (IOException e)
        {
          e.printStackTrace();
        }
      }
    }

    return image;
  }

  /**
   * Get an InputStream.
   * <p>
   * Note: loadedObject will, most frequently, be a reference to the calling object (i.e., this)
   *
   * @param loadedObject An Object loaded by the appropriate ClassLoader
   * @param name         The name of the InputStream
   * @return The InputStream
   */
  public InputStream getInputStream(final Object loadedObject, final String name)
  {
    Class<?> c;

    c = loadedObject.getClass();

    return c.getClassLoader().getResourceAsStream(name);
  }

}
