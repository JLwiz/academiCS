package com.plan.gui.util;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;

public class Styles
{

  public static final int INCH = 96;
  public static final int LETTER_WIDTH = (int) (8.5 * INCH);
  public static final int LETTER_HEIGHT = 11 * INCH;

  public static final Border DEFAULT_PADDING = BorderFactory.createEmptyBorder(20, 20, 0, 20);

  public static final Font DEFAULT_TEXT_FIELD_SIZE = new Font("Arial", Font.PLAIN, 26);
  public static final Font DEFAULT_HEADER_SIZE = new Font("Arial", Font.BOLD, 26);

  public static final Dimension TEXT_FIELD_SIZE = new Dimension(Integer.MAX_VALUE, 50);

  public static final Color ERROR_COLOR = new Color(226, 44, 44);
  public static final Border ERROR_BORDER = BorderFactory.createLineBorder(ERROR_COLOR);
  public static final Border GOOD_BORDER = BorderFactory.createLineBorder(new Color(34, 197, 94));
  public static final Border DEFAULT_BORDER = BorderFactory.createLineBorder(Color.DARK_GRAY);

  public static final Border PAGE_MARGIN = BorderFactory.createEmptyBorder(INCH, INCH, INCH, INCH);
  public static final Dimension PAGE_SIZE = new Dimension(LETTER_WIDTH, LETTER_HEIGHT);

  public static final Font PAGE_FONT = new Font("Arial", Font.PLAIN, 14);
  public static final Font PAGE_FONT_BOLD = new Font("Arial", Font.BOLD, 14);
}
