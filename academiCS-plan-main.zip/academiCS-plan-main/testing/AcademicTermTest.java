package com.testing;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

import com.plan.core.models.AcademicTerm;
import com.plan.core.models.Course;
import com.plan.core.models.TermType;

class AcademicTermTest {

	@Test
	final void testAcademicTerm() {
		AcademicTerm term = new AcademicTerm("Fall", 2020);
		assertNotNull(term);
		
		ArrayList list = new ArrayList();
		list.add(new Course(null, 0));
		term.setActualCourses(list);
		assertEquals(list, term.getActualCourses());
		
		term.setIntendedCourses(list);
		assertEquals(list, term.getIntendedCourses());
		
		term.setEndDate(2021);
		assertEquals(2021, term.getEndDate());
		
		term.setStartDate(2020);
		assertEquals(2020, term.getStartDate());
		
		term.setTermType(TermType.SEMESTER);
		assertEquals(TermType.SEMESTER, term.getTermType());
		
		term.setTitle("Fall 2020");
		assertEquals("Fall 2020", term.getTitle());
		
		assertEquals("Fall 2020", term.toString());
		
		
	}


}
