package com.testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.plan.core.conf.Configuration;

class ConfigurationTest {

	@Test
	final void testGetInstance() {
		assertNotNull(Configuration.getInstance());
	}

	@Test
	final void testGetCurrentDirectory() {
		assertEquals(null, Configuration.getInstance().getCurrentDirectory());
	}

}
