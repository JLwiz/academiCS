package com.testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.plan.core.models.CourseGroup;
import com.plan.core.services.CourseGroupService;

class CourseGroupServiceTest {

	@Test
	final void testCourseGroupService() {
		CourseGroupService svc = new CourseGroupService();
		
		CourseGroup group = new CourseGroup("CS", 420);
		svc.create(group);
		svc.delete("69");
		svc.delete(null);
		assertEquals(group, svc.get("CS"));
		assertEquals(svc.getAll(), svc.getAll());
		assertEquals(true, svc.isIDTaken("CS"));
		svc.delete("CS");
		
		
	}

}
