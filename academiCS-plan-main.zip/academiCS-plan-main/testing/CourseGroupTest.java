package com.testing;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;
import com.plan.core.models.Course;
import com.plan.core.models.CourseGroup;


class CourseGroupTest {

	@Test
	final void testCourseGroup() {
		CourseGroup group = new CourseGroup("Fall", 2020);
		assertNotNull(group);
		
		ArrayList list = new ArrayList();
		list.add(new Course(null, 0));
		group.setCourses(list);
		assertEquals(list, group.getCourses());
		
		group.setRequiredCourses(1);
		assertEquals(1, group.getRequiredCourses());
		
		group.setTitle("Fall 2020");
		assertEquals("Fall 2020", group.getTitle());
		
		assertEquals("Fall 2020", group.toString());
	}

}
