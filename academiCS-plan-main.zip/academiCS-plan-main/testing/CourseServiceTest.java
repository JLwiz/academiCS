package com.testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.plan.core.models.Course;
import com.plan.core.services.CourseService;

class CourseServiceTest {

	@Test
	final void testCourseService() {
		CourseService svc = new CourseService();
		
		Course course = new Course("CS", 420);
		svc.create(course);
		svc.delete("69");
		svc.delete(null);
		assertEquals(course, svc.get("CS"));
		assertEquals(svc.getAll(), svc.getAll());
		assertEquals(true, svc.isIDTaken("CS"));
		svc.delete("CS");
		
		
	}

}
