package com.testing;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

import com.plan.core.models.Course;


class CourseTest {

	@Test
	final void testCourse() {
		Course course = new Course("CS149", 2020);
		assertNotNull(course);
		
		course.setAbbreviatedTitle("149");
		assertEquals("149", course.getAbbreviatedTitle());
		
		course.setCourseType(null);
		assertEquals(null, course.getCourseType());
		
		course.setDescription("Java for Dummies");
		assertEquals("Java for Dummies", course.getDescription());
		
		course.setUnits(0);
		assertEquals(0, course.getUnits());
		
		
		ArrayList list = new ArrayList();
		list.add(new Course(null, 0));
		course.setAltCorequisites(list);
		assertEquals(list, course.getAltCorequisites());
		
		
		course.setStrongPrerequisites(list);
		assertEquals(list, course.getStrongPrerequisites());
		
		course.setWeakPrerequisites(list);
		assertEquals(list, course.getWeakPrerequisites());
		
		course.setAltStrongPrerequisites(list);
		assertEquals(list, course.getAltStrongPrerequisites());
		
		course.setAltWeakPrerequisites(list);
		assertEquals(list, course.getAltWeakPrerequisites());
		
		course.setCorequisites(list);
		assertEquals(list, course.getCorequisites());
		
		course.setTitle("Fall 2020");
		assertEquals("Fall 2020", course.getTitle());
		
		assertEquals("149", course.toString());
	}

}
