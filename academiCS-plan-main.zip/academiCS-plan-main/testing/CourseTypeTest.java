package com.testing;

import com.plan.core.models.CourseType;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class CourseTypeTest
{

  @Test final void test()
  {
    assertEquals(CourseType.REQUIRED, CourseType.of(0));
    assertEquals(CourseType.ELECTIVE, CourseType.of(1));
    assertEquals(CourseType.GENERAL_EDUCATION, CourseType.of(2));

    assertThrows(IllegalStateException.class, () -> CourseType.of(69));
    assertThrows(IllegalStateException.class, () -> CourseType.of(69).toString());

    assertEquals("Required", CourseType.REQUIRED.toString());
    assertEquals("Elective", CourseType.ELECTIVE.toString());
    assertEquals("General Education", CourseType.GENERAL_EDUCATION.toString());

  }

}
