package com.testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.plan.core.models.FieldOfStudy;
import com.plan.core.services.FieldOfStudyService;

class FieldOfStudyServiceTest {

	@Test
	final void testFieldOfStudyService() {
		FieldOfStudyService svc = new FieldOfStudyService();
		
		FieldOfStudy field = new FieldOfStudy("CS", 420);
		svc.create(field);
		svc.delete("69");
		svc.delete(null);
		assertEquals(field, svc.get("CS"));
		assertEquals(svc.getAll(), svc.getAll());
		assertEquals(true, svc.isIDTaken("CS"));
		svc.delete("CS");
		
		
	}

}
