package com.testing;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;
import com.plan.core.models.CourseGroup;
import com.plan.core.models.FieldOfStudy;
import com.plan.core.models.StudyType;

class FieldOfStudyTest {

	@Test
	final void testFieldOfStudy() {
		FieldOfStudy study = new FieldOfStudy("CS", 1999);
		assertNotNull(study);
		
		ArrayList list = new ArrayList();
		list.add(new CourseGroup(null, 0));
		
		study.setCourseGroups(list);
		assertEquals(list, study.getCourseGroups());
		
		study.setName("CS");
		assertEquals("CS", study.getName());
		
		study.setStudyType(StudyType.MAJOR);
		assertEquals(StudyType.MAJOR, study.getStudyType());
		
		assertEquals("CS", study.toString());
		
	}

}
