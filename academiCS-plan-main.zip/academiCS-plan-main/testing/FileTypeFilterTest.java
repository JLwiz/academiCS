package com.testing;

import static org.junit.jupiter.api.Assertions.*;

import java.io.File;

import org.junit.jupiter.api.Test;

import com.plan.core.io.FileTypeFilter;

class FileTypeFilterTest {

	@Test
	final void testFileTypeFilter() {
		assertNotNull(new FileTypeFilter("test", "test"));
	}

	@Test
	final void testAcceptFile() {
		FileTypeFilter test = new FileTypeFilter(".ser", "Serialized Data");
		File f = new File("test.ser");
		File dir = new File("src");
		assertEquals(true, test.accept(f));
		assertEquals(true, test.accept(dir));
	}

	@Test
	final void testGetDescription() {
		FileTypeFilter test = new FileTypeFilter(".ser", "Serialized Data");
		assertEquals("Serialized Data (*.ser)", test.getDescription());
	}

}
