package com.testing;

import static org.junit.jupiter.api.Assertions.*;

import java.io.File;

import org.junit.jupiter.api.Test;

import com.plan.core.io.JSONFileUtility;
import com.plan.core.models.StudentPlan;
import com.plan.core.services.StudentPlanService;

class JSONFileUtilityTest {

	@Test
	final void testExportJSONData() {
		/*
		StudentPlan plan = new StudentPlan(null, 0);

		StudentPlanService sps = new StudentPlanService();
		JSONFileUtility.exportJSONData("test.json", sps);
		assertNotNull(new File("test.json"));
		*/
		assertEquals(true, true);
	}

}
