package com.testing;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;

import org.junit.jupiter.api.Test;

import com.plan.core.io.ModelSerializer;
import com.plan.core.services.CourseGroupService;
import com.plan.core.services.CourseService;
import com.plan.core.services.FieldOfStudyService;
import com.plan.core.services.TermService;

class ModelSerializerTest {

	@Test
	final void test() {
		try {
			ModelSerializer.importData("testplan.plan", new CourseService(), 
					new TermService(),
				      new CourseGroupService(), new FieldOfStudyService());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
