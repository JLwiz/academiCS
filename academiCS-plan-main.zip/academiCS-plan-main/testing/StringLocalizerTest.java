package com.testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.plan.core.conf.Configuration;
import com.plan.core.conf.StringLocalizer;

class StringLocalizerTest {

	@Test
	final void testStringLocalizer() {
		assertNotNull(StringLocalizer.getInstance());
	}


	@Test
	final void testGetString() {
		StringLocalizer local = StringLocalizer.getInstance();
		assertEquals("test", local.getString("test"));
	}


}
