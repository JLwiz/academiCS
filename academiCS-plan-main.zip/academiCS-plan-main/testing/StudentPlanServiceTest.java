package com.testing;

import com.plan.core.models.StudentPlan;
import com.plan.core.services.StudentPlanService;
import org.junit.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class StudentPlanServiceTest
{

  @Test final void testStudentPlanService()
  {
    StudentPlanService svc = new StudentPlanService();

    StudentPlan plan = new StudentPlan("Plan", 0);
    svc.setPlan(plan);
    assertEquals(plan, svc.getPlan());

  }

}
