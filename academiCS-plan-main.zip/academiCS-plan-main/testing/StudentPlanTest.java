package com.testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.plan.core.models.FieldOfStudy;
import com.plan.core.models.StudentPlan;

class StudentPlanTest {

	@Test
	final void testStudentPlan() {
		StudentPlan plan = new StudentPlan("CS", 0);
		assertNotNull(plan);
		
		assertNotNull(plan.getCourseMap());
		
		FieldOfStudy study = new FieldOfStudy(null, 0);
		plan.setFieldOfStudy(study);
		assertEquals(study, plan.getFieldOfStudy());
		
		plan.setPlanName("CS");
		assertEquals("CS", plan.getPlanName());
	}

}
