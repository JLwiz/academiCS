package com.testing;

import com.plan.core.models.StudyType;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class StudyTypeTest
{

  @Test final void test()
  {
    assertEquals(StudyType.MAJOR, StudyType.of(0));
    assertEquals(StudyType.MINOR, StudyType.of(1));
    assertEquals(StudyType.OTHER, StudyType.of(2));

    assertThrows(IllegalStateException.class, () -> StudyType.of(69));
    assertThrows(IllegalStateException.class, () -> StudyType.of(69).toString());

    assertEquals("Major", StudyType.MAJOR.toString());
    assertEquals("Minor", StudyType.MINOR.toString());
    assertEquals("Other", StudyType.OTHER.toString());

  }

}
