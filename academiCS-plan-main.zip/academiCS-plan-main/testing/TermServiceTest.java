package com.testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.plan.core.models.AcademicTerm;
import com.plan.core.services.TermService;

class TermServiceTest {

	@Test
	final void testTermService() {
		TermService svc = new TermService();
		
		AcademicTerm term = new AcademicTerm("CS", 420);
		svc.create(term);
		svc.delete("69");
		svc.delete(null);
		assertEquals(term, svc.get("CS"));
		assertEquals(svc.getAll(), svc.getAll());
		assertEquals(true, svc.isIDTaken("CS"));
		svc.delete("CS");
		
		
	}

}
