package com.testing;

import com.plan.core.models.TermType;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class TermTypeTest
{

  @Test final void test()
  {
    assertEquals(TermType.SEMESTER, TermType.of(0));
    assertEquals(TermType.TRIMESTER, TermType.of(1));
    assertEquals(TermType.QUARTER, TermType.of(2));
    assertEquals(TermType.SUMMER_SESSION, TermType.of(3));
    assertEquals(TermType.WINTER_SESSION, TermType.of(4));

    assertThrows(IllegalStateException.class, () -> TermType.of(69));
    assertThrows(IllegalStateException.class, () -> TermType.of(69).toString());

    assertEquals("Semester", TermType.SEMESTER.toString());
    assertEquals("Trimester", TermType.TRIMESTER.toString());
    assertEquals("Quarter", TermType.QUARTER.toString());
    assertEquals("Summer Session", TermType.SUMMER_SESSION.toString());
    assertEquals("Winter Session", TermType.WINTER_SESSION.toString());

  }

}
